import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'models.dart';
import 'store.dart';
import 'theme.dart';

// ---------------------------------------------------------------
//  ألوان وأيقونات الأقسام
// ---------------------------------------------------------------

Color categoryTint(String category) {
  final i = kCategories.indexWhere((c) => c.name == category);
  final idx = i < 0 ? 0 : i;
  return HSLColor.fromAHSL(1, ((idx * 47) % 360).toDouble(), 0.55, 0.91).toColor();
}

String categoryIcon(String category) {
  for (final c in kCategories) {
    if (c.name == category) return c.icon;
  }
  return '🛒';
}

// ---------------------------------------------------------------
//  صورة المنتج (إيموجي على خلفية ملونة)
// ---------------------------------------------------------------

class ProductThumb extends StatelessWidget {
  const ProductThumb({
    super.key,
    required this.product,
    this.width,
    this.height,
    this.fontSize = 40,
    this.radius = 16,
  });

  final Product product;
  final double? width;
  final double? height;
  final double fontSize;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final tint = categoryTint(product.category);
    return Container(
      width: width,
      height: height,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [tint, Color.alphaBlend(Colors.white70, tint)],
        ),
        borderRadius: BorderRadius.circular(radius),
      ),
      child: Text(categoryIcon(product.category), style: TextStyle(fontSize: fontSize)),
    );
  }
}

// ---------------------------------------------------------------
//  عدّاد الكمية  (−  3  +)
// ---------------------------------------------------------------

class QtyStepper extends StatelessWidget {
  const QtyStepper({
    super.key,
    required this.qty,
    required this.onMinus,
    required this.onPlus,
    this.trash = false,
  });

  final int qty;
  final VoidCallback onMinus;
  final VoidCallback onPlus;
  final bool trash;

  @override
  Widget build(BuildContext context) {
    final showTrash = trash && qty <= 1;
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE0E0E0)),
        boxShadow: const [BoxShadow(color: Color(0x1A000000), blurRadius: 6, offset: Offset(0, 2))],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _StepBtn(
            icon: showTrash ? Icons.delete_outline_rounded : Icons.remove_rounded,
            color: showTrash ? kRed : kGreen,
            onTap: onMinus,
          ),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 160),
            transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
            child: SizedBox(
              key: ValueKey(qty),
              width: 28,
              child: Text(
                '$qty',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          _StepBtn(icon: Icons.add_rounded, color: kGreen, onTap: onPlus),
        ],
      ),
    );
  }
}

class _StepBtn extends StatelessWidget {
  const _StepBtn({required this.icon, required this.color, required this.onTap});
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkResponse(
      radius: 22,
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Icon(icon, size: 20, color: color),
      ),
    );
  }
}

// ---------------------------------------------------------------
//  زر الإضافة: دائرة (+) تتحول إلى عدّاد
// ---------------------------------------------------------------

class AddControl extends StatelessWidget {
  const AddControl({super.key, required this.product});
  final Product product;

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final q = store.qtyOf(product);
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 220),
      switchInCurve: Curves.easeOutBack,
      transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
      child: q == 0
          ? Material(
              key: const ValueKey('add'),
              color: Colors.white,
              elevation: 3,
              shape: const CircleBorder(),
              child: InkWell(
                customBorder: const CircleBorder(),
                onTap: () {
                  HapticFeedback.lightImpact();
                  store.setQty(product, 1);
                },
                child: const Padding(
                  padding: EdgeInsets.all(8),
                  child: Icon(Icons.add_rounded, color: kGreen, size: 22),
                ),
              ),
            )
          : QtyStepper(
              key: const ValueKey('step'),
              qty: q,
              trash: true,
              onMinus: () => store.setQty(product, q - 1),
              onPlus: () => store.setQty(product, q + 1),
            ),
    );
  }
}

// ---------------------------------------------------------------
//  بطاقة المنتج (للشريط الأفقي والشبكة)
// ---------------------------------------------------------------

class ProductCard extends StatelessWidget {
  const ProductCard({super.key, required this.product, this.width, this.onTap});
  final Product product;
  final double? width;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    ProductThumb(product: product, width: double.infinity, height: 92, fontSize: 44),
                    PositionedDirectional(bottom: 4, end: 4, child: AddControl(product: product)),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  money(product.price),
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: kGreen),
                ),
                const SizedBox(height: 2),
                Text(
                  product.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 13, height: 1.3),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------
//  صف المنتج (نتائج البحث)
// ---------------------------------------------------------------

class ProductRow extends StatelessWidget {
  const ProductRow({super.key, required this.product, this.onTap});
  final Product product;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                ProductThumb(product: product, width: 64, height: 64, fontSize: 30, radius: 14),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(product.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 2),
                      Text(
                        money(product.price),
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: kGreen),
                      ),
                    ],
                  ),
                ),
                AddControl(product: product),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------
//  شريط السلة العائم (ينزلق من تحت)
// ---------------------------------------------------------------

class CartBar extends StatelessWidget {
  const CartBar({super.key, required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final show = s.cartCount > 0;
    return SafeArea(
      child: AnimatedSlide(
        duration: const Duration(milliseconds: 380),
        curve: Curves.easeOutBack,
        offset: show ? Offset.zero : const Offset(0, 1.8),
        child: AnimatedOpacity(
          duration: const Duration(milliseconds: 250),
          opacity: show ? 1 : 0,
          child: IgnorePointer(
            ignoring: !show,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
              child: GestureDetector(
                onTap: onTap,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [kMint, kGreen]),
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: const [
                      BoxShadow(color: Color(0x552E7D32), blurRadius: 18, offset: Offset(0, 6)),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.white24,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 180),
                          transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
                          child: Text(
                            '${s.cartCount}',
                            key: ValueKey(s.cartCount),
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        'عرض السلة',
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const Spacer(),
                      Text(
                        money(s.cartTotal),
                        style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(width: 8),
                      const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white, size: 15),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------
//  ظهور متدرج (fade + slide)
// ---------------------------------------------------------------

class FadeSlideIn extends StatefulWidget {
  const FadeSlideIn({super.key, required this.child, this.index = 0});
  final Widget child;
  final int index;

  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<FadeSlideIn> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 380));

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 45 * math.min(widget.index, 8)), () {
      if (mounted) _c.forward();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: CurvedAnimation(parent: _c, curve: Curves.easeOut),
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
            .animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic)),
        child: widget.child,
      ),
    );
  }
}

// ---------------------------------------------------------------
//  حالة فارغة
// ---------------------------------------------------------------

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.emoji, required this.text});
  final String emoji;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0.4, end: 1),
              duration: const Duration(milliseconds: 600),
              curve: Curves.elasticOut,
              builder: (_, v, child) => Transform.scale(scale: v, child: child),
              child: Text(emoji, style: const TextStyle(fontSize: 64)),
            ),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, color: kGray)),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------
//  مقبض سحب الـ bottom sheet
// ---------------------------------------------------------------

class SheetHandle extends StatelessWidget {
  const SheetHandle({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Container(
        width: 44,
        height: 5,
        decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(3)),
      ),
    );
  }
}

const BorderRadius kSheetRadius = BorderRadius.vertical(top: Radius.circular(28));
