"""يعدّل مشروع الأندرويد المولّد: الاسم، المعرّف، والتوقيع الثابت."""
import pathlib
import re
import shutil

app = pathlib.Path("android/app")
shutil.copy("tools/grocery.keystore", app / "grocery.keystore")

# اسم التطبيق
manifest = app / "src/main/AndroidManifest.xml"
m = manifest.read_text(encoding="utf-8")
m = re.sub(r'android:label="[^"]*"', 'android:label="متجري"', m, count=1)
manifest.write_text(m, encoding="utf-8")

kts = app / "build.gradle.kts"
groovy = app / "build.gradle"

if kts.exists():
    s = kts.read_text(encoding="utf-8")
    s = re.sub(r'applicationId\s*=\s*"[^"]*"', 'applicationId = "com.grocery.app"', s)
    signing = '''    signingConfigs {
        create("fixed") {
            storeFile = file("grocery.keystore")
            storePassword = "grocery123"
            keyAlias = "grocery"
            keyPassword = "grocery123"
        }
    }

'''
    s = s.replace("    buildTypes {", signing + "    buildTypes {", 1)
    s = re.sub(r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)',
               'signingConfig = signingConfigs.getByName("fixed")', s)
    assert 'getByName("fixed")' in s, "لم يتم ضبط التوقيع"
    kts.write_text(s, encoding="utf-8")
elif groovy.exists():
    s = groovy.read_text(encoding="utf-8")
    s = re.sub(r'applicationId\s*=?\s*"[^"]*"', 'applicationId "com.grocery.app"', s)
    signing = '''    signingConfigs {
        fixed {
            storeFile file("grocery.keystore")
            storePassword "grocery123"
            keyAlias "grocery"
            keyPassword "grocery123"
        }
    }

'''
    s = s.replace("    buildTypes {", signing + "    buildTypes {", 1)
    s = s.replace("signingConfig signingConfigs.debug", "signingConfig signingConfigs.fixed")
    assert "signingConfigs.fixed" in s, "لم يتم ضبط التوقيع"
    groovy.write_text(s, encoding="utf-8")
else:
    raise SystemExit("ما لقيت build.gradle")

print("Android configured OK")
