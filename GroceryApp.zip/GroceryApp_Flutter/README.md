# متجري - Flutter

## طريقة بناء الـ APK على GitHub
1. سوّي Repository جديد على GitHub.
2. فك ضغط الـ Zip وارفع **محتوياته** (مو الـ Zip نفسه) إلى الـ Repository، مع المجلد المخفي `.github`.
   - الأسهل: من الكمبيوتر `git init && git add . && git commit -m init && git push`.
3. اذهب إلى تبويب **Actions** → **Build APK** → **Run workflow** (أو يشتغل تلقائياً عند الـ push).
4. بعد ما يخلص (5-10 دقايق) افتح العملية ونزّل **GroceryApp-APK** من قسم Artifacts.

الرمز السري الافتراضي للمالك: 1234
