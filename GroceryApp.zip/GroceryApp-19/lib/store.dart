import 'dart:async';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart' hide Order;
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class Store extends ChangeNotifier {
  Store._(this._prefs);
  final SharedPreferences _prefs;
  FirebaseFirestore? get _db {
    try {
      if (Firebase.apps.isEmpty) return null;
      return FirebaseFirestore.instance;
    } catch (_) {
      return null;
    }
  }
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _productsSub;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _ordersSub;

  static const statuses = ['جديد', 'قيد التجهيز', 'بالطريق', 'تم التسليم'];

  final List<Product> products = [];
  final List<Order> orders = [];
  final List<CartLine> cart = [];

  static Future<Store> load() async {
    final s = Store._(await SharedPreferences.getInstance());
    // عرض فوري من آخر نسخة محفوظة محلياً، ثم يتزامن مع السحابة
    s._loadCachedProducts();
    s._loadCachedOrders();
    s._listenProducts();
    s._listenOrders();
    return s;
  }

  @override
  void dispose() {
    _productsSub?.cancel();
    _ordersSub?.cancel();
    super.dispose();
  }

  // ---------- الرمز السري والعنوان المحفوظ (محلي بهذا الجهاز) ----------
  String get pin => _prefs.getString('pin') ?? '1234';
  set pin(String v) => _prefs.setString('pin', v);

  String get savedName => _prefs.getString('saved_name') ?? '';
  set savedName(String v) => _prefs.setString('saved_name', v);
  String get savedPhone => _prefs.getString('saved_phone') ?? '';
  set savedPhone(String v) => _prefs.setString('saved_phone', v);
  String get savedAddress => _prefs.getString('saved_address') ?? '';
  set savedAddress(String v) => _prefs.setString('saved_address', v);

  // ---------- السلة ----------
  int get cartCount => cart.fold(0, (a, l) => a + l.qty);
  int get cartTotal => cart.fold(0, (a, l) => a + l.product.price * l.qty);

  CartLine? lineOf(Product p) {
    for (final l in cart) {
      if (l.product.id == p.id) return l;
    }
    return null;
  }

  int qtyOf(Product p) => lineOf(p)?.qty ?? 0;

  void setQty(Product p, int q) {
    final line = lineOf(p);
    if (q <= 0) {
      if (line != null) cart.remove(line);
    } else if (line != null) {
      line.qty = q;
    } else {
      cart.add(CartLine(p, q));
    }
    notifyListeners();
  }

  void setNote(Product p, String note) {
    lineOf(p)?.note = note;
    notifyListeners();
  }

  void changeQty(CartLine line, int delta) {
    line.qty += delta;
    if (line.qty <= 0) cart.remove(line);
    notifyListeners();
  }

  void clearCart() {
    cart.clear();
    notifyListeners();
  }

  // ---------- الطلبات (متزامنة مع Firestore) ----------
  void _listenOrders() {
    final db = _db;
    if (db == null) return;
    _ordersSub = db.collection('orders').snapshots().listen((snap) {
      final list = snap.docs.map((d) => Order.fromJson(d.data())).toList()
        ..sort((a, b) => a.no.compareTo(b.no));
      orders
        ..clear()
        ..addAll(list);
      _cacheOrders();
      notifyListeners();
    }, onError: (_) {});
  }

  Order placeOrder(String name, String phone, String address, {double? lat, double? lng}) {
    final no = orders.fold<int>(0, (m, o) => o.no > m ? o.no : m) + 1;
    final lines = cart.map((l) {
      final note = l.note.trim().isNotEmpty ? ' (${l.note.trim()})' : '';
      return '${l.product.name} × ${l.qty}$note';
    }).toList();
    final order = Order(
      no: no,
      name: name,
      phone: phone,
      address: address,
      lines: lines,
      total: cartTotal,
      status: statuses[0],
      time: DateTime.now().millisecondsSinceEpoch,
      lat: lat,
      lng: lng,
    );
    orders.add(order);
    cart.clear();
    _cacheOrders();
    notifyListeners();
    _db?.collection('orders').doc('$no').set(order.toJson()).catchError((_) {});
    return order;
  }

  void setOrderStatus(Order o, String status) {
    o.status = status;
    _cacheOrders();
    notifyListeners();
    _db?.collection('orders').doc('${o.no}').update({'status': status}).catchError((_) {});
  }

  void deleteOrder(Order o) {
    orders.remove(o);
    _cacheOrders();
    notifyListeners();
    _db?.collection('orders').doc('${o.no}').delete().catchError((_) {});
  }

  void _cacheOrders() {
    _prefs.setString('orders', jsonEncode(orders.map((o) => o.toJson()).toList()));
  }

  void _loadCachedOrders() {
    orders.clear();
    final s = _prefs.getString('orders');
    if (s == null) return;
    for (final e in jsonDecode(s) as List) {
      orders.add(Order.fromJson(e as Map<String, dynamic>));
    }
  }

  // ---------- المنتجات (متزامنة مع Firestore) ----------
  void _listenProducts() {
    final db = _db;
    if (db == null) return;
    _productsSub = db.collection('products').snapshots().listen((snap) async {
      if (snap.docs.isEmpty) {
        final seeded = await db.collection('meta').doc('seeded').get();
        if (!seeded.exists) {
          await _seedToCloud();
        }
        return;
      }
      final list = snap.docs
          .map((d) => Product.fromJson({...d.data(), 'id': int.tryParse(d.id) ?? 0}))
          .toList()
        ..sort((a, b) => a.id.compareTo(b.id));
      products
        ..clear()
        ..addAll(list);
      _cacheProducts();
      notifyListeners();
    }, onError: (_) {});
  }

  void saveProduct(Product? existing, String name, int price, String category) {
    Product p;
    if (existing == null) {
      final id = products.fold<int>(0, (m, x) => x.id > m ? x.id : m) + 1;
      p = Product(id: id, name: name, price: price, category: category);
      products.add(p);
    } else {
      existing.name = name;
      existing.price = price;
      existing.category = category;
      p = existing;
    }
    _cacheProducts();
    notifyListeners();
    _db?.collection('products').doc('${p.id}').set(p.toJson()).catchError((_) {});
  }

  void deleteProduct(Product p) {
    products.remove(p);
    cart.removeWhere((l) => l.product.id == p.id);
    _cacheProducts();
    notifyListeners();
    _db?.collection('products').doc('${p.id}').delete().catchError((_) {});
  }

  void _cacheProducts() {
    _prefs.setString('products_v2', jsonEncode(products.map((p) => p.toJson()).toList()));
  }

  void _loadCachedProducts() {
    products.clear();
    final s = _prefs.getString('products_v2');
    if (s == null) return;
    for (final e in jsonDecode(s) as List) {
      products.add(Product.fromJson(e as Map<String, dynamic>));
    }
  }

  // منتجات تجريبية أول مرة تشتغل فيها قاعدة البيانات، ترفع للسحابة مرة وحدة فقط
  Future<void> _seedToCloud() async {
    final db = _db;
    if (db == null) return;
    var id = 1;
    final batch = db.batch();
    void add(String name, int price, String cat) {
      final p = Product(id: id, name: name, price: price, category: cat);
      batch.set(db.collection('products').doc('$id'), p.toJson());
      id++;
    }

    add('طماطم 1 كغم', 1500, 'بقالة');
    add('خيار 1 كغم', 1250, 'بقالة');
    add('بطاطا 1 كغم', 1000, 'بقالة');
    add('موز 1 كغم', 2500, 'بقالة');
    add('تفاح 1 كغم', 3000, 'بقالة');
    add('سكر 1 كغم', 1250, 'بقالة');
    add('صمون', 500, 'مخبوزات');
    add('حليب 1 لتر', 1500, 'منتجات الألبان والبيض');
    add('لبن 1 لتر', 1250, 'منتجات الألبان والبيض');
    add('جبن أبيض 500 غم', 4000, 'منتجات الألبان والبيض');
    add('بيض 30 حبة', 5500, 'منتجات الألبان والبيض');
    add('شاي 400 غم', 3500, 'القهوة والشاي');
    add('زيت طبخ 1.5 لتر', 4500, 'حبوب ومنتجات الدهن');
    add('رز عنبر 5 كغم', 8000, 'الباستا والطعام المعلب');
    add('معكرونة 500 غم', 1000, 'الباستا والطعام المعلب');
    add('عصير 1 لتر', 1750, 'المشروبات');
    add('بيبسي 2.25 لتر', 1500, 'المشروبات');
    add('ماء 1.5 لتر', 500, 'المياه');
    add('صابون سائل', 4000, 'العناية الشخصية');
    add('مسحوق غسيل 2 كغم', 5500, 'مستلزمات الغسيل والمنظفات');
    add('مناديل ورقية', 1500, 'مستلزمات المنزل');

    batch.set(db.collection('meta').doc('seeded'), {'done': true});
    await batch.commit().catchError((_) {});
  }
}
