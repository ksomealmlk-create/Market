import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'auth.dart';
import 'models.dart';
import 'store.dart';
import 'theme.dart';
import 'tracking.dart';
import 'widgets.dart';

// =====================================================
//  أدوات الاتصال والواتساب
// =====================================================

String _latinDigits(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  final b = StringBuffer();
  for (final ch in s.split('')) {
    final i = ar.indexOf(ch);
    b.write(i >= 0 ? '$i' : ch);
  }
  return b.toString();
}

String _onlyDigits(String s) => _latinDigits(s).replaceAll(RegExp(r'[^0-9]'), '');

/// يحوّل 0770xxxxxxx إلى 964770xxxxxxx حتى يفتح واتساب
String waNumber(String phone) {
  var d = _onlyDigits(phone);
  if (d.startsWith('00')) d = d.substring(2);
  if (d.startsWith('0')) d = '964${d.substring(1)}';
  return d;
}

Future<void> _open(BuildContext context, Uri uri, String failMsg) async {
  var ok = false;
  try {
    ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (_) {}
  if (!ok && context.mounted) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(failMsg)));
  }
}

Future<void> callPhone(BuildContext context, String phone) {
  final p = _latinDigits(phone).replaceAll(RegExp(r'[^0-9+]'), '');
  return _open(context, Uri.parse('tel:$p'), 'تعذر فتح تطبيق الاتصال');
}

Future<void> whatsappPhone(BuildContext context, String phone, [String text = '']) {
  final q = text.isEmpty ? '' : '?text=${Uri.encodeComponent(text)}';
  return _open(context, Uri.parse('https://wa.me/${waNumber(phone)}$q'), 'تعذر فتح واتساب');
}

Future<void> openMap(BuildContext context, double lat, double lng) {
  return _open(
    context,
    Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lng'),
    'تعذر فتح الخريطة',
  );
}

/// زرّا اتصال + واتساب لرقم معيّن
class ContactButtons extends StatelessWidget {
  const ContactButtons({super.key, required this.phone, this.message = ''});
  final String phone;
  final String message;

  @override
  Widget build(BuildContext context) {
    if (phone.trim().isEmpty) {
      return const Text('رقم التواصل غير متوفر حالياً', style: TextStyle(color: kGray));
    }
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(minimumSize: const Size(64, 44)),
            onPressed: () => callPhone(context, phone),
            icon: const Icon(Icons.call_rounded),
            label: const Text('اتصال'),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(64, 44),
              foregroundColor: const Color(0xFF1B8F4D),
            ),
            onPressed: () => whatsappPhone(context, phone, message),
            icon: const Icon(Icons.chat_rounded),
            label: const Text('واتساب'),
          ),
        ),
      ],
    );
  }
}

/// نافذة "تواصل مع المتجر" للزبون
void showContactSheet(BuildContext context) {
  final phone = context.read<Store>().storePhone;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: Colors.transparent,
    builder: (ctx) => Container(
      decoration: const BoxDecoration(color: kBg, borderRadius: kSheetRadius),
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SheetHandle(),
            const Text('📞', style: TextStyle(fontSize: 40)),
            const SizedBox(height: 6),
            const Text('تواصل مع المتجر', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ContactButtons(phone: phone, message: 'السلام عليكم، عندي استفسار'),
          ],
        ),
      ),
    ),
  );
}

// =====================================================
//  تتبّع الطلب للزبون
// =====================================================

void openMyOrders(BuildContext context) {
  Navigator.push(context, MaterialPageRoute(builder: (_) => const MyOrdersScreen()));
}

class MyOrdersScreen extends StatelessWidget {
  const MyOrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final list = store.orders.reversed.toList(); // الـ Store يجلب طلبات هذا الزبون فقط
    return Scaffold(
      appBar: AppBar(title: const Text('طلباتي')),
      body: list.isEmpty
          ? const EmptyState(emoji: '🧾', text: 'ما عندك طلبات بعد')
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: list.length,
              itemBuilder: (_, i) => FadeSlideIn(index: i, child: _TrackCard(order: list[i])),
            ),
    );
  }
}

class _TrackCard extends StatelessWidget {
  const _TrackCard({required this.order});
  final Order order;

  static const _icons = [
    Icons.receipt_long_rounded,
    Icons.inventory_2_rounded,
    Icons.delivery_dining_rounded,
    Icons.check_circle_rounded,
  ];

  @override
  Widget build(BuildContext context) {
    final store = context.read<Store>();
    final o = order;
    final idx = Store.statuses.indexOf(o.status);
    final color = statusColor(o.status);

    final steps = <Widget>[];
    for (var i = 0; i < Store.statuses.length; i++) {
      final done = i <= idx;
      steps.add(SizedBox(
        width: 62,
        child: Column(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: done ? color : const Color(0xFFE6E8E6),
              ),
              child: Icon(_icons[i], size: 20, color: done ? Colors.white : kGray),
            ),
            const SizedBox(height: 4),
            Text(
              Store.statuses[i],
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 11,
                fontWeight: i == idx ? FontWeight.bold : FontWeight.normal,
                color: done ? kDark : kGray,
              ),
            ),
          ],
        ),
      ));
      if (i < Store.statuses.length - 1) {
        steps.add(Expanded(
          child: Container(
            height: 4,
            margin: const EdgeInsets.only(bottom: 22),
            decoration: BoxDecoration(
              color: i < idx ? color : const Color(0xFFE6E8E6),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ));
      }
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text('طلب #${o.no}  •  ${formatTime(o.time)}',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(o.status, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: steps),
          if (o.driver != null && o.driver!.isNotEmpty && o.status != 'تم التسليم') ...[
            const SizedBox(height: 4),
            Text('🛵 السائق: ${o.driver}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
            if ((o.driverPhone ?? '').isNotEmpty) ...[
              const SizedBox(height: 8),
              ContactButtons(phone: o.driverPhone!, message: 'السلام عليكم، بخصوص طلبي #${o.no}'),
            ],
          ],
          if (o.status == 'بالطريق') ...[
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => LiveMapScreen(order: o)),
                ),
                icon: const Icon(Icons.map_rounded),
                label: const Text('تتبع الدراجة على الخريطة'),
              ),
            ),
          ],
          const Divider(height: 24),
          for (final l in o.lines)
            Padding(padding: const EdgeInsets.only(bottom: 2), child: Text('• $l', style: const TextStyle(fontSize: 14))),
          const SizedBox(height: 8),
          Text('المجموع: ${money(o.total)}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ContactButtons(phone: store.storePhone, message: 'السلام عليكم، بخصوص طلبي #${o.no}'),
        ],
      ),
    );
  }
}

// =====================================================
//  شاشة السائق
// =====================================================

class DriverScreen extends StatelessWidget {
  const DriverScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final auth = context.watch<AuthService>();
    final me = auth.uid;
    final all = store.orders.reversed.toList();
    final ready = all.where((o) => o.status == 'قيد التجهيز').toList();
    final onWay = all.where((o) => o.status == 'بالطريق' && o.driverUid == me).toList();
    final done = all.where((o) => o.status == 'تم التسليم' && o.driverUid == me).toList();

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text('🛵 ${auth.displayName}'),
          actions: [
            IconButton(
              tooltip: 'تسجيل الخروج',
              icon: const Icon(Icons.logout_rounded),
              onPressed: () async {
                final nav = Navigator.of(context);
                await AuthService.instance.signOut();
                nav.popUntil((r) => r.isFirst);
              },
            ),
          ],
          bottom: TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            tabs: [
              Tab(text: 'جاهزة (${ready.length})'),
              Tab(text: 'بالطريق (${onWay.length})'),
              Tab(text: 'مسلّمة (${done.length})'),
            ],
          ),
        ),
        body: Column(
          children: [
            const TrackBanner(),
            Expanded(
              child: TabBarView(
                children: [
                  _DriverList(orders: ready, empty: 'لا توجد طلبات جاهزة للتوصيل', mode: 0),
                  _DriverList(orders: onWay, empty: 'ما عندك طلبات بالطريق', mode: 1),
                  _DriverList(orders: done, empty: 'ما سلّمت طلبات بعد', mode: 2),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DriverList extends StatelessWidget {
  const _DriverList({required this.orders, required this.empty, required this.mode});
  final List<Order> orders;
  final String empty;
  final int mode; // 0 جاهزة، 1 بالطريق، 2 مسلّمة

  @override
  Widget build(BuildContext context) {
    if (orders.isEmpty) return EmptyState(emoji: '🛵', text: empty);
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: orders.length,
      itemBuilder: (_, i) => FadeSlideIn(index: i, child: _DriverCard(order: orders[i], mode: mode)),
    );
  }
}

class _DriverCard extends StatelessWidget {
  const _DriverCard({required this.order, required this.mode});
  final Order order;
  final int mode;

  Future<void> _deliver(BuildContext context) async {
    final store = context.read<Store>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('تأكيد تسليم الطلب #${order.no}؟'),
        content: Text('استلمت المبلغ: ${money(order.total)}'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تم التسليم')),
        ],
      ),
    );
    if (ok == true) store.setOrderStatus(order, 'تم التسليم');
  }

  @override
  Widget build(BuildContext context) {
    final store = context.read<Store>();
    final o = order;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('طلب #${o.no}  •  ${formatTime(o.time)}',
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('👤 ${o.name}', style: const TextStyle(fontSize: 15)),
          Text('📞 ${o.phone}', style: const TextStyle(fontSize: 15)),
          Text('📍 ${o.address}', style: const TextStyle(fontSize: 15, height: 1.4)),
          const SizedBox(height: 8),
          ContactButtons(phone: o.phone, message: 'السلام عليكم، أنا سائق طلبك #${o.no}'),
          if (o.lat != null && o.lng != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(minimumSize: const Size(64, 44)),
                  icon: const Icon(Icons.map_outlined),
                  label: const Text('موقع الزبون بالخريطة'),
                  onPressed: () => openMap(context, o.lat!, o.lng!),
                ),
              ),
            ),
          const Divider(height: 24),
          for (final l in o.lines)
            Padding(padding: const EdgeInsets.only(bottom: 2), child: Text('• $l', style: const TextStyle(fontSize: 15))),
          const SizedBox(height: 8),
          Text('المبلغ المطلوب: ${money(o.total)}',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          if (mode == 0) ...[
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () {
                  final a = AuthService.instance;
                  store.takeOrder(o, a.name, a.phone);
                },
                icon: const Icon(Icons.delivery_dining_rounded),
                label: const Text('استلمت الطلب'),
              ),
            ),
          ] else if (mode == 1) ...[
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => _deliver(context),
                icon: const Icon(Icons.check_circle_rounded),
                label: const Text('تم التسليم'),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// =====================================================
//  التقارير والمبيعات (تبويب في لوحة صاحب المتجر)
// =====================================================

class ReportsTab extends StatelessWidget {
  const ReportsTab({super.key});

  static final _lineRe = RegExp(r'^(.*?) × (\d+)');
  static const _days = ['الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final orders = store.orders;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final weekStart = DateTime(now.year, now.month, now.day - 6);
    final monthStart = DateTime(now.year, now.month, 1);

    int sum(Iterable<Order> l) => l.fold(0, (a, o) => a + o.total);
    bool deliveredFrom(Order o, DateTime from) =>
        o.status == 'تم التسليم' && DateTime.fromMillisecondsSinceEpoch(o.time).isAfter(from.subtract(const Duration(milliseconds: 1)));

    final delivered = orders.where((o) => o.status == 'تم التسليم').toList();
    final pending = orders.where((o) => o.status != 'تم التسليم').toList();
    final dToday = orders.where((o) => deliveredFrom(o, today)).toList();
    final dWeek = orders.where((o) => deliveredFrom(o, weekStart)).toList();
    final dMonth = orders.where((o) => deliveredFrom(o, monthStart)).toList();
    final avg = delivered.isEmpty ? 0 : (sum(delivered) / delivered.length).round();

    // آخر 7 أيام
    final bars = <MapEntry<DateTime, int>>[];
    for (var i = 6; i >= 0; i--) {
      final d = DateTime(now.year, now.month, now.day - i);
      final next = DateTime(now.year, now.month, now.day - i + 1);
      final v = sum(delivered.where((o) {
        final t = DateTime.fromMillisecondsSinceEpoch(o.time);
        return !t.isBefore(d) && t.isBefore(next);
      }));
      bars.add(MapEntry(d, v));
    }
    final maxBar = bars.fold<int>(0, (m, e) => e.value > m ? e.value : m);

    // الأكثر طلباً
    final counts = <String, int>{};
    for (final o in orders) {
      for (final l in o.lines) {
        final m = _lineRe.firstMatch(l);
        if (m == null) continue;
        final n = m.group(1)!.trim();
        counts[n] = (counts[n] ?? 0) + (int.tryParse(m.group(2)!) ?? 0);
      }
    }
    final top = counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    Widget stat(String title, String value, String sub, Color c) => Expanded(
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 13, color: kGray)),
                const SizedBox(height: 6),
                Text(value, style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: c)),
                const SizedBox(height: 2),
                Text(sub, style: const TextStyle(fontSize: 12, color: kGray)),
              ],
            ),
          ),
        );

    if (orders.isEmpty) return const EmptyState(emoji: '📊', text: 'لا توجد بيانات بعد');

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('المبيعات (الطلبات المسلّمة)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Row(children: [
          stat('اليوم', money(sum(dToday)), '${dToday.length} طلب', kGreen),
          const SizedBox(width: 10),
          stat('آخر 7 أيام', money(sum(dWeek)), '${dWeek.length} طلب', kGreen),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          stat('هذا الشهر', money(sum(dMonth)), '${dMonth.length} طلب', kGreen),
          const SizedBox(width: 10),
          stat('الكل', money(sum(delivered)), '${delivered.length} طلب', kGreen),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          stat('قيد التنفيذ', money(sum(pending)), '${pending.length} طلب', const Color(0xFFE65100)),
          const SizedBox(width: 10),
          stat('متوسط الطلب', money(avg), 'للمسلّمة', kDark),
        ]),
        const SizedBox(height: 20),
        const Text('آخر 7 أيام', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.fromLTRB(12, 16, 12, 10),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
          child: SizedBox(
            height: 150,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final e in bars)
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        if (e.value > 0)
                          Text(
                            e.value >= 1000 ? '${(e.value / 1000).toStringAsFixed(e.value % 1000 == 0 ? 0 : 1)}k' : '${e.value}',
                            style: const TextStyle(fontSize: 10, color: kGray),
                          ),
                        const SizedBox(height: 2),
                        Container(
                          height: maxBar == 0 ? 3 : (e.value / maxBar * 90).clamp(3, 90).toDouble(),
                          margin: const EdgeInsets.symmetric(horizontal: 5),
                          decoration: BoxDecoration(
                            color: e.value > 0 ? kMint : const Color(0xFFE6E8E6),
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(_days[e.key.weekday - 1], style: const TextStyle(fontSize: 10)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        const Text('الأكثر طلباً', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        if (top.isEmpty)
          const Text('لا توجد بيانات', style: TextStyle(color: kGray))
        else
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
            child: Column(
              children: [
                for (var i = 0; i < top.length && i < 8; i++)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      children: [
                        SizedBox(width: 26, child: Text('${i + 1}', style: const TextStyle(color: kGray))),
                        Expanded(child: Text(top[i].key, style: const TextStyle(fontSize: 15))),
                        Text('${top[i].value}', style: const TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        const SizedBox(height: 24),
      ],
    );
  }
}
