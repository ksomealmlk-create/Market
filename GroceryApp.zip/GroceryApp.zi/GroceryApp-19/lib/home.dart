import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'auth.dart';
import 'cart.dart';
import 'category.dart';
import 'features.dart';
import 'models.dart';
import 'product_sheet.dart';
import 'store.dart';
import 'theme.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _ctl = TextEditingController();
  String _q = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _askLocationPermission());
  }

  // يطلب صلاحية الموقع أول ما يفتح الزبون التطبيق
  Future<void> _askLocationPermission() async {
    try {
      final p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) await Geolocator.requestPermission();
    } catch (_) {}
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  void _openCategory(Category c) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryScreen(category: c)));
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final q = _q.trim();
    final found = q.isEmpty
        ? <Product>[]
        : store.products.where((p) => p.name.toLowerCase().contains(q.toLowerCase())).toList();

    return Scaffold(
      body: Stack(
        children: [
          CustomScrollView(
            slivers: [
              _header(store),
              if (q.isEmpty) ..._browse(store) else ..._results(found),
              const SliverToBoxAdapter(child: SizedBox(height: 110)),
            ],
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: CartBar(onTap: () => openCart(context)),
          ),
        ],
      ),
    );
  }

  Widget _header(Store store) {
    final auth = context.watch<AuthService>();
    return SliverAppBar(
      pinned: true,
      expandedHeight: 190,
      backgroundColor: kGreen,
      foregroundColor: Colors.white,
      title: const Text('حرير'),
      actions: [
        IconButton(
          tooltip: auth.isDriver ? 'شاشة السائق' : 'المتجر',
          icon: Icon(auth.isDriver ? Icons.delivery_dining_rounded : Icons.storefront_rounded),
          onPressed: () => openStore(context),
        ),
        IconButton(
          tooltip: 'تواصل معنا',
          icon: const Icon(Icons.support_agent_outlined),
          onPressed: () => showContactSheet(context),
        ),
        if (!auth.isOwner && !auth.isDriver)
          IconButton(
            tooltip: 'طلباتي',
            icon: const Icon(Icons.receipt_long_outlined),
            onPressed: () => openMyOrders(context),
          ),
        IconButton(
          tooltip: 'السلة',
          icon: Badge(
            isLabelVisible: store.cartCount > 0,
            label: Text('${store.cartCount}'),
            child: const Icon(Icons.shopping_bag_outlined),
          ),
          onPressed: () => openCart(context),
        ),
        const SizedBox(width: 4),
      ],
      flexibleSpace: FlexibleSpaceBar(
        collapseMode: CollapseMode.parallax,
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [kMint, kGreen],
            ),
          ),
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 78),
          alignment: AlignmentDirectional.bottomStart,
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('أهلاً بيك 👋', style: TextStyle(color: Colors.white70, fontSize: 14)),
              SizedBox(height: 2),
              Text(
                'شنو تحب تطلب اليوم؟',
                style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(68),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: TextField(
            controller: _ctl,
            onChanged: (v) => setState(() => _q = v),
            decoration: InputDecoration(
              hintText: 'ابحث عن منتج',
              fillColor: Colors.white,
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: _q.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () {
                        _ctl.clear();
                        setState(() => _q = '');
                      },
                    ),
            ),
          ),
        ),
      ),
    );
  }

  /// بانر يظهر للزبون إذا عنده طلب جاري (غير مسلّم) ويفتح شاشة التتبع
  Widget _activeOrdersBanner(Store store) {
    final auth = context.watch<AuthService>();
    if (auth.isOwner || auth.isDriver) return const SizedBox.shrink();
    final active = store.orders.where((o) => o.status != 'تم التسليم').toList()
      ..sort((a, b) => b.time.compareTo(a.time));
    if (active.isEmpty) return const SizedBox.shrink();
    final o = active.first;
    final color = statusColor(o.status);
    final title = active.length == 1 ? 'طلبك #${o.no}  •  ${o.status}' : '${active.length} طلبات حالية';
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => openMyOrders(context),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: color.withOpacity(0.5), width: 1.5),
            ),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.14)),
                  child: Icon(
                    o.status == 'بالطريق' ? Icons.delivery_dining_rounded : Icons.inventory_2_rounded,
                    color: color,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('طلباتي الحالية', style: TextStyle(fontSize: 13, color: kGray)),
                      Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                Text('تتبع', style: TextStyle(color: color, fontWeight: FontWeight.bold)),
                Icon(Icons.chevron_left_rounded, color: color),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _browse(Store store) {
    final out = <Widget>[
      SliverToBoxAdapter(child: _activeOrdersBanner(store)),
      const SliverToBoxAdapter(
        child: Padding(
          padding: EdgeInsets.fromLTRB(16, 18, 16, 10),
          child: Text('الأقسام', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ),
      ),
      SliverToBoxAdapter(
        child: SizedBox(
          height: 112,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: kCategories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) => _CategoryTile(category: kCategories[i], onTap: () => _openCategory(kCategories[i])),
          ),
        ),
      ),
    ];

    var idx = 0;
    for (final c in kCategories) {
      final items = store.products.where((p) => p.category == c.name).toList();
      if (items.isEmpty) continue;
      out.add(SliverToBoxAdapter(
        child: FadeSlideIn(
          index: idx++,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InkWell(
                onTap: () => _openCategory(c),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text('${c.icon} ${c.name}',
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      ),
                      const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: kGreen),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 206,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (ctx, i) => ProductCard(
                    product: items[i],
                    width: 144,
                    onTap: () => showProductSheet(ctx, items[i]),
                  ),
                ),
              ),
            ],
          ),
        ),
      ));
    }
    return out;
  }

  List<Widget> _results(List<Product> found) {
    if (found.isEmpty) {
      return const [
        SliverFillRemaining(
          hasScrollBody: false,
          child: EmptyState(emoji: '😕', text: 'ما لقينا منتج بهذا الاسم'),
        ),
      ];
    }
    return [
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
        sliver: SliverList(
          delegate: SliverChildBuilderDelegate(
            (ctx, i) => FadeSlideIn(
              index: i,
              child: ProductRow(product: found[i], onTap: () => showProductSheet(ctx, found[i])),
            ),
            childCount: found.length,
          ),
        ),
      ),
    ];
  }
}

class _CategoryTile extends StatelessWidget {
  const _CategoryTile({required this.category, required this.onTap});
  final Category category;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: SizedBox(
        width: 78,
        child: Column(
          children: [
            Container(
              width: 68,
              height: 68,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: categoryTint(category.name),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Text(category.icon, style: const TextStyle(fontSize: 32)),
            ),
            const SizedBox(height: 6),
            Text(
              category.name,
              maxLines: 2,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, height: 1.2),
            ),
          ],
        ),
      ),
    );
  }
}
