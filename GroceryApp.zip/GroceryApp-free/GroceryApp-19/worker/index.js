// =====================================================================
//  سيرفر الإشعارات المجاني (Cloudflare Worker) - بدل Cloud Functions
//  التطبيق يرسل له طلب بعد كل طلب جديد / تغيّر حالة، وهو يرسل إشعار FCM
//  (FCM مجاني، وما يحتاج خطة Blaze).
//
//  المتغيرات (Settings > Variables في Cloudflare):
//    PROJECT_ID           = matjari-app-c26db
//    SERVICE_ACCOUNT_JSON = محتوى ملف مفتاح حساب الخدمة (Secret)
// =====================================================================

const enc = new TextEncoder();
const dec = new TextDecoder();

const b64u = (buf) =>
  btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const b64uToBytes = (s) => {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
};

// ---------- توكن حساب الخدمة (للقراءة من Firestore وإرسال FCM) ----------
let saCache = { value: null, exp: 0 };
async function accessToken(env) {
  const now = Math.floor(Date.now() / 1000);
  if (saCache.value && saCache.exp - 60 > now) return saCache.value;
  const sa = JSON.parse(env.SERVICE_ACCOUNT_JSON);
  const head = b64u(enc.encode(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const claim = b64u(
    enc.encode(
      JSON.stringify({
        iss: sa.client_email,
        scope: 'https://www.googleapis.com/auth/datastore https://www.googleapis.com/auth/firebase.messaging',
        aud: 'https://oauth2.googleapis.com/token',
        iat: now,
        exp: now + 3600,
      })
    )
  );
  const pem = sa.private_key.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '');
  const key = await crypto.subtle.importKey(
    'pkcs8',
    b64uToBytes(pem),
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, enc.encode(`${head}.${claim}`));
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${head}.${claim}.${b64u(sig)}`,
  });
  const j = await res.json();
  if (!j.access_token) throw new Error('sa token failed: ' + JSON.stringify(j));
  saCache = { value: j.access_token, exp: now + (j.expires_in || 3600) };
  return saCache.value;
}

// ---------- التحقق من توكن المستخدم (Firebase ID token) ----------
let jwksCache = { keys: null, exp: 0 };
async function verifyIdToken(token, projectId) {
  const [h, p, s] = token.split('.');
  if (!h || !p || !s) throw new Error('bad token');
  const header = JSON.parse(dec.decode(b64uToBytes(h)));
  const payload = JSON.parse(dec.decode(b64uToBytes(p)));
  if (header.alg !== 'RS256') throw new Error('bad alg');
  const now = Math.floor(Date.now() / 1000);
  if (!jwksCache.keys || jwksCache.exp < now) {
    const r = await fetch('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com');
    jwksCache = { keys: (await r.json()).keys, exp: now + 3600 };
  }
  const jwk = jwksCache.keys.find((k) => k.kid === header.kid);
  if (!jwk) throw new Error('unknown key');
  const key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
  const ok = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, b64uToBytes(s), enc.encode(`${h}.${p}`));
  if (!ok) throw new Error('bad signature');
  if (payload.aud !== projectId || payload.iss !== `https://securetoken.google.com/${projectId}`) throw new Error('bad claims');
  if (payload.exp < now || !payload.sub) throw new Error('expired');
  return payload.sub;
}

// ---------- Firestore REST ----------
const fsBase = (env) => `https://firestore.googleapis.com/v1/projects/${env.PROJECT_ID}/databases/(default)/documents`;

function fromValue(v) {
  if ('stringValue' in v) return v.stringValue;
  if ('integerValue' in v) return Number(v.integerValue);
  if ('doubleValue' in v) return v.doubleValue;
  if ('booleanValue' in v) return v.booleanValue;
  if ('arrayValue' in v) return (v.arrayValue.values || []).map(fromValue);
  if ('mapValue' in v) return fromFields(v.mapValue.fields || {});
  return null;
}
const fromFields = (f) => Object.fromEntries(Object.entries(f).map(([k, v]) => [k, fromValue(v)]));
const toValue = (x) => (typeof x === 'boolean' ? { booleanValue: x } : { stringValue: String(x) });

async function fsGet(env, path) {
  const r = await fetch(`${fsBase(env)}/${path}`, { headers: { Authorization: `Bearer ${await accessToken(env)}` } });
  if (r.status === 404) return null;
  if (!r.ok) throw new Error(`firestore get ${path}: ${r.status}`);
  return fromFields((await r.json()).fields || {});
}

async function fsListIds(env, collection) {
  const r = await fetch(`${fsBase(env)}/${collection}?pageSize=100`, {
    headers: { Authorization: `Bearer ${await accessToken(env)}` },
  });
  if (!r.ok) return [];
  return ((await r.json()).documents || []).map((d) => d.name.split('/').pop());
}

async function fsPatch(env, path, data) {
  const mask = Object.keys(data).map((k) => `updateMask.fieldPaths=${encodeURIComponent(k)}`).join('&');
  const fields = Object.fromEntries(Object.entries(data).map(([k, v]) => [k, toValue(v)]));
  await fetch(`${fsBase(env)}/${path}?${mask}`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${await accessToken(env)}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ fields }),
  });
}

async function removeToken(env, uid, token) {
  await fetch(`https://firestore.googleapis.com/v1/projects/${env.PROJECT_ID}/databases/(default)/documents:commit`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${await accessToken(env)}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      writes: [
        {
          transform: {
            document: `projects/${env.PROJECT_ID}/databases/(default)/documents/users/${uid}`,
            fieldTransforms: [{ fieldPath: 'tokens', removeAllFromArray: { values: [{ stringValue: token }] } }],
          },
        },
      ],
    }),
  });
}

async function tokensOf(env, uids) {
  const out = [];
  await Promise.all(
    uids.map(async (uid) => {
      const u = await fsGet(env, `users/${uid}`);
      ((u && u.tokens) || []).forEach((t) => out.push({ uid, token: t }));
    })
  );
  return out;
}

// ---------- إرسال FCM ----------
async function sendAll(env, targets, title, body, urgent, orderNo) {
  const at = await accessToken(env);
  await Promise.all(
    targets.map(async ({ uid, token }) => {
      const r = await fetch(`https://fcm.googleapis.com/v1/projects/${env.PROJECT_ID}/messages:send`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${at}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: {
            token,
            notification: { title, body },
            data: { channel: urgent ? 'new_orders' : 'order_updates', orderNo: String(orderNo) },
            android: {
              priority: 'HIGH',
              ttl: '3600s',
              notification: urgent
                ? { channelId: 'new_orders', sound: 'order_alert', notificationPriority: 'PRIORITY_MAX', defaultVibrateTimings: true }
                : { channelId: 'order_updates', notificationPriority: 'PRIORITY_HIGH' },
            },
          },
        }),
      });
      if (r.status === 404 || r.status === 400) {
        const t = await r.text();
        if (t.includes('UNREGISTERED') || t.includes('INVALID_ARGUMENT')) await removeToken(env, uid, token);
      }
    })
  );
}

const money = (n) => `${Number(n || 0).toLocaleString('en-US')} د.ع`;
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'Content-Type': 'application/json' } });

export default {
  async fetch(req, env) {
    if (req.method !== 'POST') return json({ ok: true, service: 'matjari-notify' });
    try {
      const idToken = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
      const uid = await verifyIdToken(idToken, env.PROJECT_ID);
      const { type, no } = await req.json();
      const order = await fsGet(env, `orders/${no}`);
      if (!order) return json({ error: 'no order' }, 404);

      // ----- طلب جديد: الزبون صاحب الطلب -> تنبيه صاحب المتجر -----
      if (type === 'new_order') {
        if (order.uid !== uid || order.status !== 'جديد' || order.notifiedNew) return json({ skipped: true });
        if (Date.now() - Number(order.time || 0) > 10 * 60 * 1000) return json({ skipped: 'old' });
        await fsPatch(env, `orders/${no}`, { notifiedNew: true });
        const targets = await tokensOf(env, await fsListIds(env, 'admins'));
        await sendAll(env, targets, `🛒 طلب جديد #${order.no}`, `${order.name} • ${(order.lines || []).length} منتج • ${money(order.total)}`, true, order.no);
        return json({ sent: targets.length });
      }

      // ----- تغيّر الحالة: صاحب المتجر أو السائق -----
      if (type === 'status') {
        const isOwner = !!(await fsGet(env, `admins/${uid}`));
        const isDriver = !!(await fsGet(env, `drivers/${uid}`)) && (order.driverUid === uid || order.status === 'قيد التجهيز');
        if (!isOwner && !isDriver) return json({ error: 'forbidden' }, 403);
        if (order.lastNotifiedStatus === order.status) return json({ skipped: true });
        await fsPatch(env, `orders/${no}`, { lastNotifiedStatus: order.status });

        if (order.status === 'قيد التجهيز') {
          const drivers = await tokensOf(env, await fsListIds(env, 'drivers'));
          await sendAll(env, drivers, `📦 طلب جاهز للتوصيل #${order.no}`, `${order.name} • ${money(order.total)}`, true, order.no);
        }
        const texts = {
          'قيد التجهيز': 'جاري تجهيز طلبك 📦',
          'بالطريق': `طلبك بالطريق إليك 🛵${order.driver ? ' مع ' + order.driver : ''}`,
          'تم التسليم': 'تم تسليم طلبك، بالهناء والعافية ✅',
        };
        if (texts[order.status] && order.uid) {
          await sendAll(env, await tokensOf(env, [order.uid]), `طلب #${order.no}`, texts[order.status], false, order.no);
        }
        return json({ ok: true });
      }
      return json({ error: 'bad type' }, 400);
    } catch (e) {
      return json({ error: String(e.message || e) }, 401);
    }
  },
};
