# خطوات التشغيل (نسخة مجانية بدون Blaze)

كل الخطوات تنعمل من المتصفح، بدون كمبيوتر.

## 1) تفعيل الدخول
Firebase Console ← Build ← Authentication ← Get started ← Sign-in method ← **Email/Password** فعّلها.

## 2) قواعد الحماية
Firestore Database ← تبويب **Rules** ← امسح الموجود والصق محتوى ملف `firestore.rules` ← **Publish**.

## 3) مفتاح حساب الخدمة (يستعمله سيرفر الإشعارات)
Project settings (أيقونة الترس) ← **Service accounts** ← **Generate new private key** ← ينزل ملف JSON.
⚠️ هذا الملف سري. لا ترفعه على GitHub ولا ترسله لأحد.

## 4) سيرفر الإشعارات (Cloudflare Worker - مجاني بدون بطاقة)
1. سجّل حساب مجاني على dash.cloudflare.com.
2. **Workers & Pages ← Create ← Create Worker** ← سمّه `matjari-notify` ← **Deploy**.
3. **Edit code** ← امسح كل شي والصق محتوى ملف `worker/index.js` ← **Deploy**.
4. **Settings ← Variables and Secrets ← Add**:
   - `PROJECT_ID` (نوع Text) = `matjari-app-c26db`
   - `SERVICE_ACCOUNT_JSON` (نوع **Secret**) = افتح ملف JSON من الخطوة 3 والصق كل محتواه.
   - Deploy.
5. انسخ رابط الـ Worker (يشبه `https://matjari-notify.xxxx.workers.dev`).

## 5) ربط التطبيق
افتح `lib/config.dart` وحط الرابط مكان `https://YOUR-WORKER.workers.dev`، وابنِ التطبيق من جديد.

## 6) حساب صاحب المتجر
1. بالتطبيق: أيقونة الدخول ← **إنشاء حساب** (اكتب إيميلك الحقيقي بخانة الرقم + كلمة سر).
2. أيقونة الحساب ← **نسخ معرّف الحساب (UID)**.
3. Firestore ← **Start collection** باسم `admins` ← **Document ID = الـ UID** ← أضف أي حقل (مثلاً `role` = `owner`).
4. سجّل خروج ودخول ← تظهر **لوحة صاحب المتجر**.

## 7) السائقون
لوحة المتجر ← الإعدادات ← **إضافة سائق** (اسم + رقم + كلمة سر).

## 8) حتى يوصل التنبيه والتطبيق مقفل
- سجّل دخول صاحب المتجر (وكل سائق) مرة وحدة وافق على إذن الإشعارات.
- إعدادات التطبيق ← البطارية ← **Unrestricted / بدون قيود**.
- لا تكتم قناة "الطلبات الجديدة" من إعدادات الإشعارات.

## 9) صور المنتجات
لوحة المتجر ← المنتجات ← قسم ← تعديل ← من المعرض أو الكاميرا ← حفظ.
الصور تنضغط وتنحفظ داخل Firestore (مجاناً).
