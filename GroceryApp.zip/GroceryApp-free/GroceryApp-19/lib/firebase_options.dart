// إعدادات Firebase لمشروع matjari-app (مستخرجة من google-services.json)
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyC9kwtJbCnUyYR3EhgWtxsJajevMgM8CWo',
    appId: '1:442190025523:android:3a108dfa3489691c626446',
    messagingSenderId: '442190025523',
    projectId: 'matjari-app-c26db',
    storageBucket: 'matjari-app-c26db.firebasestorage.app',
  );
}
