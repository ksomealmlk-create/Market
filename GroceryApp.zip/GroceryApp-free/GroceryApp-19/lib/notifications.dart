import 'dart:async';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart' hide Order;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'auth.dart';
import 'config.dart';

// =====================================================
//  الإشعارات
//  - قناة "new_orders": صوت تنبيه قوي (res/raw/order_alert.wav) للطلبات الجديدة
//    (صاحب المتجر + السائقين). تشتغل حتى لو التطبيق مقفل أو بالخلفية.
//  - قناة "order_updates": إشعار عادي للزبون لما تتغير حالة طلبه.
//  الإرسال يتم من سيرفر مجاني (Cloudflare Worker - مجلد worker/) بدون خطة Blaze.
// =====================================================

const String kOrdersChannelId = 'new_orders';
const String kUpdatesChannelId = 'order_updates';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _local = FlutterLocalNotificationsPlugin();
  bool _started = false;
  String? _token;
  String? _tokenUid; // الحساب الذي سجّلنا له التوكن
  StreamSubscription<String>? _refreshSub;

  FirebaseMessaging? get _fcm {
    try {
      if (Firebase.apps.isEmpty) return null;
      return FirebaseMessaging.instance;
    } catch (_) {
      return null;
    }
  }

  /// يُستدعى مرة وحدة عند تشغيل التطبيق
  Future<void> init() async {
    if (_started) return;
    _started = true;
    try {
      await _local.initialize(
        const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
      );
      final android = _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

      // لازم القناة تنعمل من قبل حتى لو التطبيق مقفل لما يوصل الإشعار
      await android?.createNotificationChannel(const AndroidNotificationChannel(
        kOrdersChannelId,
        'الطلبات الجديدة',
        description: 'تنبيه صوتي عند وصول طلب جديد',
        importance: Importance.max,
        playSound: true,
        sound: RawResourceAndroidNotificationSound('order_alert'),
        enableVibration: true,
        audioAttributesUsage: AudioAttributesUsage.alarm,
      ));
      await android?.createNotificationChannel(const AndroidNotificationChannel(
        kUpdatesChannelId,
        'تحديثات الطلب',
        description: 'إشعار عند تغيّر حالة طلبك',
        importance: Importance.high,
      ));

      // الإشعارات والتطبيق مفتوح (FCM ما يعرضها لحاله بالواجهة)
      FirebaseMessaging.onMessage.listen(_showForeground);
    } catch (e) {
      debugPrint('notifications init failed: $e');
    }
  }

  Future<void> _showForeground(RemoteMessage m) async {
    final n = m.notification;
    final title = n?.title ?? m.data['title'];
    final body = n?.body ?? m.data['body'];
    if (title == null && body == null) return;
    final urgent = (m.data['channel'] ?? kUpdatesChannelId) == kOrdersChannelId;
    await _local.show(
      m.hashCode,
      title,
      body,
      NotificationDetails(
        android: urgent
            ? const AndroidNotificationDetails(
                kOrdersChannelId,
                'الطلبات الجديدة',
                importance: Importance.max,
                priority: Priority.max,
                playSound: true,
                sound: RawResourceAndroidNotificationSound('order_alert'),
                audioAttributesUsage: AudioAttributesUsage.alarm,
                enableVibration: true,
              )
            : const AndroidNotificationDetails(
                kUpdatesChannelId,
                'تحديثات الطلب',
                importance: Importance.high,
                priority: Priority.high,
              ),
      ),
    );
  }

  /// عند تغيّر الحساب: نطلب الإذن ونسجّل توكن الجهاز لهذا الحساب
  Future<void> onAuthChanged(AuthService auth) async {
    final fcm = _fcm;
    if (fcm == null) return;
    if (!auth.isLoggedIn) {
      _tokenUid = null;
      return;
    }
    try {
      final android = _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      await android?.requestNotificationsPermission();
      await fcm.requestPermission(alert: true, badge: true, sound: true);
      final token = await fcm.getToken();
      if (token == null) return;
      _token = token;
      await _saveToken(auth.uid!, token);
      _refreshSub ??= fcm.onTokenRefresh.listen((t) {
        _token = t;
        final uid = AuthService.instance.uid;
        if (uid != null) _saveToken(uid, t);
      });
    } catch (e) {
      debugPrint('push register failed: $e');
    }
  }

  Future<void> _saveToken(String uid, String token) async {
    _tokenUid = uid;
    try {
      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'tokens': FieldValue.arrayUnion([token]),
      }, SetOptions(merge: true));
    } catch (e) {
      debugPrint('save token failed: $e');
    }
  }

  /// قبل تسجيل الخروج: نشيل توكن هذا الجهاز حتى ما توصله إشعارات الحساب
  Future<void> onBeforeSignOut(AuthService auth) async {
    final uid = auth.uid;
    final token = _token;
    if (uid == null || token == null) return;
    try {
      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'tokens': FieldValue.arrayRemove([token]),
      }, SetOptions(merge: true));
    } catch (_) {}
    _tokenUid = null;
  }

  /// يبلّغ سيرفر الإشعارات بحدث (طلب جديد / تغيّر حالة). السيرفر يتأكد من هويتك ثم يرسل FCM.
  Future<void> notifyServer(String type, int no) async {
    if (kNotifyUrl.contains('YOUR-WORKER')) return; // لسا ما انضبط الرابط
    try {
      final idToken = await FirebaseAuth.instance.currentUser?.getIdToken();
      if (idToken == null) return;
      final r = await http
          .post(
            Uri.parse(kNotifyUrl),
            headers: {'Authorization': 'Bearer $idToken', 'Content-Type': 'application/json'},
            body: jsonEncode({'type': type, 'no': no}),
          )
          .timeout(const Duration(seconds: 20));
      if (r.statusCode >= 400) debugPrint('notify failed: ${r.statusCode} ${r.body}');
    } catch (e) {
      debugPrint('notify error: $e');
    }
  }
}
