import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart' hide Order;
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'auth.dart';
import 'models.dart';
import 'notifications.dart';

class Store extends ChangeNotifier {
  Store._(this._prefs);
  final SharedPreferences _prefs;
  FirebaseFirestore? get _db {
    try {
      if (Firebase.apps.isEmpty) return null;
      return FirebaseFirestore.instance;
    } catch (_) {
      return null;
    }
  }

  AuthService get _auth => AuthService.instance;

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _productsSub;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _settingsSub;
  final List<StreamSubscription<QuerySnapshot<Map<String, dynamic>>>> _orderSubs = [];
  final Map<int, Map<int, Order>> _bySource = {};
  String _authKey = '';
  bool _seeding = false;
  bool _counterChecked = false;

  // إعدادات المتجر (تتزامن من السحابة)
  String storePhone = '';

  static const statuses = ['جديد', 'قيد التجهيز', 'بالطريق', 'تم التسليم'];

  final List<Product> products = [];
  final List<Order> orders = [];
  final List<CartLine> cart = [];

  static Future<Store> load() async {
    final s = Store._(await SharedPreferences.getInstance());
    // عرض فوري من آخر نسخة محفوظة محلياً، ثم يتزامن مع السحابة
    s._loadCachedProducts();
    s.storePhone = s._prefs.getString('store_phone') ?? '';
    s._listenSettings();
    s._listenProducts();
    s._auth.addListener(s._onAuth);
    s._onAuth();
    return s;
  }

  @override
  void dispose() {
    _auth.removeListener(_onAuth);
    _productsSub?.cancel();
    _settingsSub?.cancel();
    for (final s in _orderSubs) {
      s.cancel();
    }
    super.dispose();
  }

  // ---------- العنوان المحفوظ (محلي بهذا الجهاز) ----------
  String get savedName => _prefs.getString('saved_name') ?? '';
  set savedName(String v) => _prefs.setString('saved_name', v);
  String get savedPhone => _prefs.getString('saved_phone') ?? '';
  set savedPhone(String v) => _prefs.setString('saved_phone', v);
  String get savedAddress => _prefs.getString('saved_address') ?? '';
  set savedAddress(String v) => _prefs.setString('saved_address', v);

  // ---------- تغيّر الحساب (دخول / خروج) ----------
  void _onAuth() {
    final a = _auth;
    final key = '${a.uid}|${a.role.name}';
    if (key == _authKey) return;
    _authKey = key;
    _counterChecked = false;
    _restartOrders();
    _maybeSeed();
  }

  void _listenSettings() {
    final db = _db;
    if (db == null) return;
    _settingsSub = db.collection('meta').doc('settings').snapshots().listen((d) {
      final m = d.data();
      if (m == null) return;
      storePhone = (m['phone'] as String?) ?? storePhone;
      _prefs.setString('store_phone', storePhone);
      notifyListeners();
    }, onError: (_) {});
  }

  void saveSettings({required String phone}) {
    storePhone = phone;
    _prefs.setString('store_phone', storePhone);
    notifyListeners();
    _db
        ?.collection('meta')
        .doc('settings')
        .set({'phone': phone}, SetOptions(merge: true))
        .catchError((_) {});
  }

  // ---------- السلة ----------
  int get cartCount => cart.fold(0, (a, l) => a + l.qty);
  int get cartTotal => cart.fold(0, (a, l) => a + l.product.price * l.qty);

  CartLine? lineOf(Product p) {
    for (final l in cart) {
      if (l.product.id == p.id) return l;
    }
    return null;
  }

  int qtyOf(Product p) => lineOf(p)?.qty ?? 0;

  void setQty(Product p, int q) {
    final line = lineOf(p);
    if (q <= 0) {
      if (line != null) cart.remove(line);
    } else if (line != null) {
      line.qty = q;
    } else {
      cart.add(CartLine(p, q));
    }
    notifyListeners();
  }

  void setNote(Product p, String note) {
    lineOf(p)?.note = note;
    notifyListeners();
  }

  void changeQty(CartLine line, int delta) {
    line.qty += delta;
    if (line.qty <= 0) cart.remove(line);
    notifyListeners();
  }

  void clearCart() {
    cart.clear();
    notifyListeners();
  }

  // ---------- الطلبات (متزامنة مع Firestore حسب دور المستخدم) ----------
  // صاحب المتجر: كل الطلبات
  // السائق: الطلبات الجاهزة للتوصيل + طلباته هو
  // الزبون: طلباته فقط
  void _restartOrders() {
    for (final s in _orderSubs) {
      s.cancel();
    }
    _orderSubs.clear();
    _bySource.clear();
    orders.clear();
    notifyListeners();

    final db = _db;
    final a = _auth;
    if (db == null || !a.isLoggedIn) return;

    final queries = <Query<Map<String, dynamic>>>[];
    switch (a.role) {
      case Role.owner:
        queries.add(db.collection('orders'));
        break;
      case Role.driver:
        queries.add(db.collection('orders').where('status', isEqualTo: statuses[1]));
        queries.add(db.collection('orders').where('driverUid', isEqualTo: a.uid));
        break;
      case Role.customer:
        queries.add(db.collection('orders').where('uid', isEqualTo: a.uid));
        break;
      case Role.guest:
        return;
    }

    for (var i = 0; i < queries.length; i++) {
      final idx = i;
      _orderSubs.add(queries[i].snapshots().listen((snap) {
        final m = <int, Order>{};
        for (final d in snap.docs) {
          try {
            final o = Order.fromJson(d.data());
            m[o.no] = o;
          } catch (_) {}
        }
        _bySource[idx] = m;
        _rebuildOrders();
        if (a.role == Role.owner) _ensureCounter();
      }, onError: (e) => debugPrint('orders listen error: $e')));
    }
  }

  void _rebuildOrders() {
    final merged = <int, Order>{};
    for (final m in _bySource.values) {
      merged.addAll(m);
    }
    orders
      ..clear()
      ..addAll(merged.values.toList()..sort((a, b) => a.no.compareTo(b.no)));
    notifyListeners();
  }

  /// أول مرة يفتح فيها صاحب المتجر بعد التحديث: نضبط عدّاد أرقام الطلبات
  /// على آخر رقم موجود حتى ما يتكرر رقم طلب قديم.
  Future<void> _ensureCounter() async {
    if (_counterChecked) return;
    _counterChecked = true;
    final db = _db;
    if (db == null) return;
    try {
      final ref = db.collection('meta').doc('counter');
      final snap = await ref.get();
      if (snap.exists) return;
      final maxNo = orders.fold<int>(0, (m, o) => o.no > m ? o.no : m);
      await ref.set({'last': maxNo});
    } catch (e) {
      debugPrint('ensure counter failed: $e');
    }
  }

  /// يرسل الطلب. رقم الطلب يُحجز بمعاملة (transaction) حتى ما يتكرر بين الزبائن.
  Future<Order> placeOrder(String name, String phone, String address, {double? lat, double? lng}) async {
    final db = _db;
    final uid = _auth.uid;
    if (db == null || uid == null) throw 'سجّل دخول أولاً';
    final lines = cart.map((l) {
      final note = l.note.trim().isNotEmpty ? ' (${l.note.trim()})' : '';
      return '${l.product.name} × ${l.qty}$note';
    }).toList();
    final total = cartTotal;
    final counter = db.collection('meta').doc('counter');
    late Order order;
    await db.runTransaction((tx) async {
      final snap = await tx.get(counter);
      final last = snap.exists ? ((snap.data()?['last'] as num?)?.toInt() ?? 0) : 0;
      final no = last + 1;
      order = Order(
        no: no,
        uid: uid,
        name: name,
        phone: phone,
        address: address,
        lines: lines,
        total: total,
        status: statuses[0],
        time: DateTime.now().millisecondsSinceEpoch,
        lat: lat,
        lng: lng,
      );
      tx.set(counter, {'last': no});
      tx.set(db.collection('orders').doc('$no'), order.toJson());
    });
    cart.clear();
    notifyListeners();
    // نبلّغ سيرفر الإشعارات حتى يوصل صاحب المتجر تنبيه صوتي (لا ننتظره)
    NotificationService.instance.notifyServer('new_order', order.no);
    return order;
  }

  void setOrderStatus(Order o, String status) {
    o.status = status;
    notifyListeners();
    _db
        ?.collection('orders')
        .doc('${o.no}')
        .update({'status': status})
        .then((_) => NotificationService.instance.notifyServer('status', o.no))
        .catchError((_) {});
  }

  // السائق يستلم الطلب: يتحول إلى "بالطريق" ويظهر اسمه للزبون
  void takeOrder(Order o, String name, String phone) {
    final uid = _auth.uid;
    if (uid == null) return;
    o.status = 'بالطريق';
    o.driver = name;
    o.driverPhone = phone;
    o.driverUid = uid;
    notifyListeners();
    _db?.collection('orders').doc('${o.no}').update({
      'status': o.status,
      'driver': name,
      'driverPhone': phone,
      'driverUid': uid,
    }).then((_) => NotificationService.instance.notifyServer('status', o.no)).catchError((_) {});
  }

  void deleteOrder(Order o) {
    orders.remove(o);
    notifyListeners();
    _db?.collection('orders').doc('${o.no}').delete().catchError((_) {});
  }

  // ---------- المنتجات (متزامنة مع Firestore) ----------
  void _listenProducts() {
    final db = _db;
    if (db == null) return;
    _productsSub = db.collection('products').snapshots().listen((snap) async {
      if (snap.docs.isEmpty) {
        await _maybeSeed();
        return;
      }
      final list = snap.docs
          .map((d) => Product.fromJson({...d.data(), 'id': int.tryParse(d.id) ?? 0}))
          .toList()
        ..sort((a, b) => a.id.compareTo(b.id));
      products
        ..clear()
        ..addAll(list);
      _cacheProducts();
      notifyListeners();
    }, onError: (_) {});
  }

  int nextProductId() => products.fold<int>(0, (m, x) => x.id > m ? x.id : m) + 1;

  Future<void> saveProduct(Product? existing, String name, int price, String category,
      {String? imageB64, int? newId}) async {
    Product p;
    if (existing == null) {
      final id = newId ?? nextProductId();
      p = Product(id: id, name: name, price: price, category: category, imageB64: imageB64 ?? '');
      products.add(p);
    } else {
      existing.name = name;
      existing.price = price;
      existing.category = category;
      if (imageB64 != null) existing.imageB64 = imageB64;
      p = existing;
    }
    _cacheProducts();
    notifyListeners();
    await _db?.collection('products').doc('${p.id}').set(p.toJson());
  }

  void deleteProduct(Product p) {
    products.remove(p);
    cart.removeWhere((l) => l.product.id == p.id);
    _cacheProducts();
    notifyListeners();
    _db?.collection('products').doc('${p.id}').delete().catchError((_) {});
  }

  void _cacheProducts() {
    _prefs.setString('products_v2', jsonEncode(products.map((p) => p.toJson(withImage: false)).toList()));
  }

  void _loadCachedProducts() {
    products.clear();
    final s = _prefs.getString('products_v2');
    if (s == null) return;
    for (final e in jsonDecode(s) as List) {
      products.add(Product.fromJson(e as Map<String, dynamic>));
    }
  }

  // منتجات تجريبية أول مرة (صاحب المتجر فقط يقدر يكتب بقاعدة البيانات)
  Future<void> _maybeSeed() async {
    final db = _db;
    if (db == null || _seeding || !_auth.isOwner || products.isNotEmpty) return;
    _seeding = true;
    try {
      final seeded = await db.collection('meta').doc('seeded').get();
      if (!seeded.exists) await _seedToCloud();
    } catch (_) {
    } finally {
      _seeding = false;
    }
  }

  Future<void> _seedToCloud() async {
    final db = _db;
    if (db == null) return;
    var id = 1;
    final batch = db.batch();
    void add(String name, int price, String cat) {
      final p = Product(id: id, name: name, price: price, category: cat);
      batch.set(db.collection('products').doc('$id'), p.toJson());
      id++;
    }

    add('طماطم 1 كغم', 1500, 'بقالة');
    add('خيار 1 كغم', 1250, 'بقالة');
    add('بطاطا 1 كغم', 1000, 'بقالة');
    add('موز 1 كغم', 2500, 'بقالة');
    add('تفاح 1 كغم', 3000, 'بقالة');
    add('سكر 1 كغم', 1250, 'بقالة');
    add('صمون', 500, 'مخبوزات');
    add('حليب 1 لتر', 1500, 'منتجات الألبان والبيض');
    add('لبن 1 لتر', 1250, 'منتجات الألبان والبيض');
    add('جبن أبيض 500 غم', 4000, 'منتجات الألبان والبيض');
    add('بيض 30 حبة', 5500, 'منتجات الألبان والبيض');
    add('شاي 400 غم', 3500, 'القهوة والشاي');
    add('زيت طبخ 1.5 لتر', 4500, 'حبوب ومنتجات الدهن');
    add('رز عنبر 5 كغم', 8000, 'الباستا والطعام المعلب');
    add('معكرونة 500 غم', 1000, 'الباستا والطعام المعلب');
    add('عصير 1 لتر', 1750, 'المشروبات');
    add('بيبسي 2.25 لتر', 1500, 'المشروبات');
    add('ماء 1.5 لتر', 500, 'المياه');
    add('صابون سائل', 4000, 'العناية الشخصية');
    add('مسحوق غسيل 2 كغم', 5500, 'مستلزمات الغسيل والمنظفات');
    add('مناديل ورقية', 1500, 'مستلزمات المنزل');

    batch.set(db.collection('meta').doc('seeded'), {'done': true});
    await batch.commit().catchError((_) {});
  }
}
