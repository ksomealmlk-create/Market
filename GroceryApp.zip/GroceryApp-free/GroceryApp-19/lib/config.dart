// رابط سيرفر الإشعارات (Cloudflare Worker) - تلقاه بعد نشر الـ Worker.
// مثال: https://matjari-notify.اسمك.workers.dev
const String kNotifyUrl = 'https://YOUR-WORKER.workers.dev';
