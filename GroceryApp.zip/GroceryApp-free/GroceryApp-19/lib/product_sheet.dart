import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'models.dart';
import 'store.dart';
import 'theme.dart';
import 'widgets.dart';

/// يفتح صفحة المنتج كـ bottom sheet قابل للسحب
Future<void> showProductSheet(BuildContext context, Product product) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
      child: DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.86,
        minChildSize: 0.5,
        maxChildSize: 0.96,
        builder: (ctx, controller) => _ProductSheet(product: product, scroll: controller),
      ),
    ),
  );
}

class _ProductSheet extends StatefulWidget {
  const _ProductSheet({required this.product, required this.scroll});
  final Product product;
  final ScrollController scroll;

  @override
  State<_ProductSheet> createState() => _ProductSheetState();
}

class _ProductSheetState extends State<_ProductSheet> {
  late Product p;
  late int qty;
  late bool existing;
  final _note = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load(widget.product);
  }

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  void _load(Product np) {
    final line = context.read<Store>().lineOf(np);
    p = np;
    existing = line != null;
    qty = line?.qty ?? 1;
    _note.text = line?.note ?? '';
  }

  void _commit() {
    final store = context.read<Store>();
    final messenger = ScaffoldMessenger.of(context);
    HapticFeedback.mediumImpact();
    store.setQty(p, qty);
    store.setNote(p, _note.text.trim());
    Navigator.pop(context);
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text('تمت إضافة ${p.name} للسلة 🛒'),
        duration: const Duration(milliseconds: 1600),
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 90),
      ));
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final similar =
        store.products.where((x) => x.category == p.category && x.id != p.id).take(12).toList();

    return Container(
      decoration: const BoxDecoration(color: kBg, borderRadius: kSheetRadius),
      child: Column(
        children: [
          const SheetHandle(),
          Expanded(
            child: ListView(
              controller: widget.scroll,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              children: [
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 260),
                  child: Column(
                    key: ValueKey(p.id),
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TweenAnimationBuilder<double>(
                        tween: Tween(begin: 0.85, end: 1),
                        duration: const Duration(milliseconds: 500),
                        curve: Curves.elasticOut,
                        builder: (_, v, child) => Transform.scale(scale: v, child: child),
                        child: ProductThumb(
                          product: p,
                          width: double.infinity,
                          height: 190,
                          fontSize: 96,
                          radius: 26,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(p.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(
                        money(p.price),
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: kGreen),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE3F2E4),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Text(
                          '${categoryIcon(p.category)}  ${p.category}',
                          style: const TextStyle(color: kGreen, fontSize: 14, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
                  clipBehavior: Clip.antiAlias,
                  child: ExpansionTile(
                    key: ValueKey('note${p.id}'),
                    initiallyExpanded: _note.text.isNotEmpty,
                    shape: const Border(),
                    collapsedShape: const Border(),
                    leading: const Icon(Icons.edit_note_rounded, color: kGreen),
                    title: const Text('أي تعليمات خاصة؟', style: TextStyle(fontWeight: FontWeight.bold)),
                    childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                    children: [
                      TextField(
                        controller: _note,
                        maxLines: 2,
                        decoration: const InputDecoration(hintText: 'مثال: بدون أكياس، أنضج، قطّع...'),
                      ),
                    ],
                  ),
                ),
                if (similar.isNotEmpty) ...[
                  const SizedBox(height: 20),
                  const Text('منتجات مشابهة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 206,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: similar.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 10),
                      itemBuilder: (ctx, i) => ProductCard(
                        product: similar[i],
                        width: 144,
                        onTap: () {
                          setState(() => _load(similar[i]));
                          if (widget.scroll.hasClients) {
                            widget.scroll.animateTo(0,
                                duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
                          }
                        },
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          // الشريط السفلي: العدّاد + زر الإضافة
          Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Color(0x22000000), blurRadius: 12, offset: Offset(0, -3))],
            ),
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  QtyStepper(
                    qty: qty,
                    onMinus: () {
                      if (qty > 1) setState(() => qty--);
                    },
                    onPlus: () => setState(() => qty++),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: _commit,
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 150),
                        child: Text(
                          '${existing ? 'تحديث السلة' : 'أضف للسلة'}   •   ${money(p.price * qty)}',
                          key: ValueKey('$existing-$qty-${p.id}'),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
