import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'auth.dart';
import 'features.dart';
import 'models.dart';
import 'store.dart';
import 'tracking.dart';
import 'theme.dart';
import 'widgets.dart';

// =====================================================
//  لوحة صاحب المتجر
// =====================================================

class OwnerScreen extends StatelessWidget {
  const OwnerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('لوحة صاحب المتجر'),
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            tabs: [Tab(text: 'الطلبات'), Tab(text: 'المنتجات'), Tab(text: 'التقارير'), Tab(text: 'الإعدادات')],
          ),
        ),
        body: const TabBarView(children: [_OrdersTab(), _ProductsTab(), ReportsTab(), _PinTab()]),
      ),
    );
  }
}

// ---------- الطلبات ----------

class _OrdersTab extends StatelessWidget {
  const _OrdersTab();

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final list = store.orders.reversed.toList();
    if (list.isEmpty) return const EmptyState(emoji: '📭', text: 'لا توجد طلبات بعد');
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: list.length,
      itemBuilder: (_, i) => FadeSlideIn(index: i, child: _OrderCard(order: list[i])),
    );
  }
}

class _OrderCard extends StatelessWidget {
  const _OrderCard({required this.order});
  final Order order;

  Future<void> _delete(BuildContext context) async {
    final store = context.read<Store>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('حذف الطلب #${order.no}؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف', style: TextStyle(color: kRed)),
          ),
        ],
      ),
    );
    if (ok == true) store.deleteOrder(order);
  }

  @override
  Widget build(BuildContext context) {
    final store = context.read<Store>();
    final o = order;
    final idx = Store.statuses.indexOf(o.status);
    final color = statusColor(o.status);
    final next = (idx >= 0 && idx < Store.statuses.length - 1) ? Store.statuses[idx + 1] : null;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text('طلب #${o.no}  •  ${formatTime(o.time)}',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(o.status, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: (idx + 1) / Store.statuses.length,
              minHeight: 6,
              color: color,
              backgroundColor: const Color(0xFFEAEAEA),
            ),
          ),
          const SizedBox(height: 12),
          Text('👤 ${o.name}', style: const TextStyle(fontSize: 15)),
          Row(
            children: [
              Expanded(child: Text('📞 ${o.phone}', style: const TextStyle(fontSize: 15))),
              IconButton(
                visualDensity: VisualDensity.compact,
                tooltip: 'نسخ الرقم',
                icon: const Icon(Icons.copy_rounded, size: 18, color: kGray),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: o.phone));
                  ScaffoldMessenger.of(context)
                    ..hideCurrentSnackBar()
                    ..showSnackBar(const SnackBar(content: Text('تم نسخ الرقم')));
                },
              ),
            ],
          ),
          Text('📍 ${o.address}', style: const TextStyle(fontSize: 15, height: 1.4)),
          if (o.driver != null && o.driver!.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('🛵 السائق: ${o.driver}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
            ),
          const SizedBox(height: 8),
          ContactButtons(phone: o.phone, message: 'السلام عليكم، بخصوص طلبك #${o.no} من ماركت حراير'),
          if (o.status == 'بالطريق')
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(minimumSize: const Size(64, 44)),
                  icon: const Icon(Icons.map_rounded),
                  label: const Text('تتبع السائق على الخريطة'),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => LiveMapScreen(order: o)),
                  ),
                ),
              ),
            ),
          if (o.lat != null && o.lng != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size(64, 44)),
                icon: const Icon(Icons.map_outlined),
                label: const Text('فتح موقع الزبون بالخريطة'),
                onPressed: () async {
                  final uri = Uri.parse(
                      'https://www.google.com/maps/search/?api=1&query=${o.lat},${o.lng}');
                  final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
                  if (!ok && context.mounted) {
                    ScaffoldMessenger.of(context)
                        .showSnackBar(const SnackBar(content: Text('تعذر فتح الخريطة')));
                  }
                },
              ),
            ),
          const Divider(height: 24),
          for (final l in o.lines)
            Padding(padding: const EdgeInsets.only(bottom: 2), child: Text('• $l', style: const TextStyle(fontSize: 15))),
          const SizedBox(height: 8),
          Text('المجموع: ${money(o.total)}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Row(
            children: [
              if (next != null)
                Expanded(
                  child: FilledButton(
                    style: FilledButton.styleFrom(minimumSize: const Size(64, 44)),
                    onPressed: () => store.setOrderStatus(o, next),
                    child: Text('تحويل إلى: $next'),
                  ),
                )
              else
                const Expanded(child: SizedBox()),
              const SizedBox(width: 8),
              IconButton.filled(
                style: IconButton.styleFrom(backgroundColor: kRed, foregroundColor: Colors.white),
                tooltip: 'حذف الطلب',
                icon: const Icon(Icons.delete_outline_rounded),
                onPressed: () => _delete(context),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ---------- المنتجات ----------

class _ProductsTab extends StatelessWidget {
  const _ProductsTab();

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => showProductEditor(context),
                icon: const Icon(Icons.add_rounded),
                label: const Text('إضافة منتج'),
              ),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Text('اختر القسم', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.82,
            ),
            delegate: SliverChildBuilderDelegate(
              (ctx, i) {
                final c = kCategories[i];
                final n = store.products.where((p) => p.category == c.name).length;
                return InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => Navigator.push(
                    ctx,
                    MaterialPageRoute(builder: (_) => OwnerCategoryScreen(category: c)),
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(color: categoryTint(c.name), borderRadius: BorderRadius.circular(18)),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(c.icon, style: const TextStyle(fontSize: 32)),
                        const SizedBox(height: 6),
                        Text(c.name,
                            maxLines: 2,
                            textAlign: TextAlign.center,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                        Text('$n منتج', style: const TextStyle(fontSize: 11, color: kGray)),
                      ],
                    ),
                  ),
                );
              },
              childCount: kCategories.length,
            ),
          ),
        ),
      ],
    );
  }
}

class OwnerCategoryScreen extends StatelessWidget {
  const OwnerCategoryScreen({super.key, required this.category});
  final Category category;

  Future<void> _delete(BuildContext context, Product p) async {
    final store = context.read<Store>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('حذف ${p.name}؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف', style: TextStyle(color: kRed)),
          ),
        ],
      ),
    );
    if (ok == true) store.deleteProduct(p);
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final items = store.products.where((p) => p.category == category.name).toList();
    return Scaffold(
      appBar: AppBar(title: Text('${category.icon}  ${category.name}')),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: kGreen,
        foregroundColor: Colors.white,
        onPressed: () => showProductEditor(context, defaultCat: category.name),
        icon: const Icon(Icons.add_rounded),
        label: const Text('إضافة منتج'),
      ),
      body: items.isEmpty
          ? const EmptyState(emoji: '🫙', text: 'لا توجد منتجات بهذا القسم بعد')
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
              itemCount: items.length,
              itemBuilder: (ctx, i) {
                final p = items[i];
                return FadeSlideIn(
                  index: i,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
                    child: Row(
                      children: [
                        ProductThumb(product: p, width: 52, height: 52, fontSize: 24, radius: 14),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                              Text(money(p.price), style: const TextStyle(fontSize: 14, color: kGray)),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.edit_outlined, color: kGreen),
                          onPressed: () => showProductEditor(ctx, product: p),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline_rounded, color: kRed),
                          onPressed: () => _delete(ctx, p),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

/// إضافة / تعديل منتج (bottom sheet) مع صورة حقيقية
void showProductEditor(BuildContext context, {Product? product, String? defaultCat}) {
  final store = context.read<Store>();
  final name = TextEditingController(text: product?.name ?? '');
  final price = TextEditingController(text: product?.price.toString() ?? '');
  var chosen = product?.category ?? defaultCat ?? kCategories.first.name;
  String? error;
  Uint8List? picked; // صورة جديدة اخترناها ولسا ما انرفعت
  var removeImage = false;
  var saving = false;
  final newId = product == null ? store.nextProductId() : null;

  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    isDismissible: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) {
        Future<void> pick(ImageSource src) async {
          try {
            final x = await ImagePicker().pickImage(source: src, maxWidth: 600, maxHeight: 600, imageQuality: 60);
            if (x == null) return;
            final bytes = await x.readAsBytes();
            if (bytes.length > 450 * 1024) {
              setS(() => error = 'الصورة كبيرة، اختر صورة ثانية أو صغّرها');
              return;
            }
            setS(() {
              picked = bytes;
              removeImage = false;
              error = null;
            });
          } catch (_) {
            setS(() => error = 'تعذر فتح الصور');
          }
        }

        final hasOld = (product?.imageB64 ?? '').isNotEmpty && !removeImage;
        Widget preview;
        if (picked != null) {
          preview = Image.memory(picked!, fit: BoxFit.cover);
        } else if (hasOld) {
          preview = Image.memory(base64Decode(product!.imageB64), fit: BoxFit.cover);
        } else {
          preview = Center(child: Text(categoryIcon(chosen), style: const TextStyle(fontSize: 56)));
        }

        return Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: Container(
            decoration: const BoxDecoration(color: kBg, borderRadius: kSheetRadius),
            child: SafeArea(
              top: false,
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Center(child: SheetHandle()),
                    Text(product == null ? 'إضافة منتج' : 'تعديل المنتج',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 14),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        height: 170,
                        width: double.infinity,
                        color: categoryTint(chosen),
                        child: preview,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: saving ? null : () => pick(ImageSource.gallery),
                            icon: const Icon(Icons.photo_library_outlined),
                            label: const Text('من المعرض'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: saving ? null : () => pick(ImageSource.camera),
                            icon: const Icon(Icons.photo_camera_outlined),
                            label: const Text('الكاميرا'),
                          ),
                        ),
                        if (picked != null || hasOld)
                          IconButton(
                            tooltip: 'حذف الصورة',
                            onPressed: saving
                                ? null
                                : () => setS(() {
                                      picked = null;
                                      removeImage = true;
                                    }),
                            icon: const Icon(Icons.delete_outline_rounded, color: kRed),
                          ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    TextField(controller: name, decoration: const InputDecoration(hintText: 'اسم المنتج')),
                    const SizedBox(height: 10),
                    TextField(
                      controller: price,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: const InputDecoration(hintText: 'السعر (دينار)'),
                    ),
                    const SizedBox(height: 14),
                    const Text('القسم', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        for (final c in kCategories)
                          ChoiceChip(
                            label: Text('${c.icon} ${c.name}'),
                            selected: chosen == c.name,
                            showCheckmark: false,
                            selectedColor: const Color(0xFFD7EFD9),
                            onSelected: (_) => setS(() => chosen = c.name),
                          ),
                      ],
                    ),
                    if (error != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(error!, style: const TextStyle(color: kRed)),
                      ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: saving
                            ? null
                            : () async {
                                final n = name.text.trim();
                                final pr = int.tryParse(price.text.trim());
                                if (n.isEmpty || pr == null) {
                                  setS(() => error = 'البيانات ناقصة');
                                  return;
                                }
                                setS(() {
                                  saving = true;
                                  error = null;
                                });
                                try {
                                  String? img;
                                  if (picked != null) {
                                    img = base64Encode(picked!);
                                  } else if (removeImage) {
                                    img = '';
                                  }
                                  await store.saveProduct(product, n, pr, chosen, imageB64: img, newId: newId);
                                  if (ctx.mounted) Navigator.pop(ctx);
                                } catch (e) {
                                  setS(() {
                                    saving = false;
                                    error = 'ما انحفظ المنتج. تأكد من الإنترنت وحاول مرة ثانية.';
                                  });
                                }
                              },
                        child: saving
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                            : const Text('حفظ'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    ),
  ).whenComplete(() {
    name.dispose();
    price.dispose();
  });
}

// ---------- الإعدادات ----------

class _PinTab extends StatefulWidget {
  const _PinTab();

  @override
  State<_PinTab> createState() => _PinTabState();
}

class _PinTabState extends State<_PinTab> {
  late final TextEditingController _phone;

  @override
  void initState() {
    super.initState();
    _phone = TextEditingController(text: context.read<Store>().storePhone);
  }

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  Widget _card(String title, List<Widget> children) => Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ...children,
          ],
        ),
      );

  Future<void> _addDriver() async {
    final name = TextEditingController();
    final phone = TextEditingController();
    final pass = TextEditingController();
    String? error;
    var busy = false;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('إضافة سائق'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: name, decoration: const InputDecoration(hintText: 'اسم السائق')),
                const SizedBox(height: 8),
                TextField(
                  controller: phone,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(hintText: 'رقم هاتف السائق (يدخل به)'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: pass,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(hintText: 'كلمة السر (6 رموز على الأقل)'),
                ),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(error!, style: const TextStyle(color: kRed)),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: busy ? null : () => Navigator.pop(ctx), child: const Text('إلغاء')),
            TextButton(
              onPressed: busy
                  ? null
                  : () async {
                      if (name.text.trim().isEmpty || phone.text.trim().isEmpty || pass.text.length < 6) {
                        setS(() => error = 'عبّي كل الحقول وكلمة السر 6 رموز على الأقل');
                        return;
                      }
                      setS(() {
                        busy = true;
                        error = null;
                      });
                      try {
                        await AuthService.instance.createDriver(
                          name: name.text.trim(),
                          phone: phone.text.trim(),
                          password: pass.text,
                        );
                        if (ctx.mounted) Navigator.pop(ctx);
                      } catch (e) {
                        setS(() {
                          busy = false;
                          error = AuthService.errorText(e);
                        });
                      }
                    },
              child: const Text('إضافة'),
            ),
          ],
        ),
      ),
    );
    name.dispose();
    phone.dispose();
    pass.dispose();
  }

  Future<void> _removeDriver(Driver d) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('إزالة ${d.name}؟'),
        content: const Text('ما راح يقدر يدخل كسائق بعد الآن.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إزالة', style: TextStyle(color: kRed))),
        ],
      ),
    );
    if (ok == true) await AuthService.instance.removeDriver(d.uid);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _card('بيانات المتجر', [
          TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(hintText: 'رقم هاتف المتجر (للاتصال والواتساب)'),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () {
                context.read<Store>().saveSettings(phone: _phone.text.trim());
                ScaffoldMessenger.of(context)
                  ..hideCurrentSnackBar()
                  ..showSnackBar(const SnackBar(content: Text('تم الحفظ ✅')));
              },
              child: const Text('حفظ'),
            ),
          ),
        ]),
        _card('السائقون', [
          StreamBuilder<List<Driver>>(
            stream: AuthService.instance.driversStream(),
            builder: (_, snap) {
              final list = snap.data ?? const <Driver>[];
              if (list.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.only(bottom: 8),
                  child: Text('ما أضفت سائقين بعد', style: TextStyle(color: kGray)),
                );
              }
              return Column(
                children: [
                  for (final d in list)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Text('🛵', style: TextStyle(fontSize: 26)),
                      title: Text(d.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(d.phone),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline_rounded, color: kRed),
                        onPressed: () => _removeDriver(d),
                      ),
                    ),
                ],
              );
            },
          ),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _addDriver,
              icon: const Icon(Icons.person_add_alt_1_rounded),
              label: const Text('إضافة سائق'),
            ),
          ),
        ]),
        _card('الحساب', [
          Text(AuthService.instance.displayName, style: const TextStyle(fontSize: 15)),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(foregroundColor: kRed),
              icon: const Icon(Icons.logout_rounded),
              label: const Text('تسجيل الخروج'),
              onPressed: () async {
                final nav = Navigator.of(context);
                await AuthService.instance.signOut();
                nav.popUntil((r) => r.isFirst);
              },
            ),
          ),
        ]),
      ],
    );
  }
}
