import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cart.dart';
import 'models.dart';
import 'product_sheet.dart';
import 'store.dart';
import 'widgets.dart';

class CategoryScreen extends StatelessWidget {
  const CategoryScreen({super.key, required this.category});
  final Category category;

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final items = store.products.where((p) => p.category == category.name).toList();

    return Scaffold(
      appBar: AppBar(title: Text('${category.icon}  ${category.name}')),
      body: Stack(
        children: [
          items.isEmpty
              ? const EmptyState(emoji: '🫙', text: 'لا توجد منتجات بهذا القسم بعد')
              : GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 110),
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 200,
                    mainAxisExtent: 206,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                  ),
                  itemCount: items.length,
                  itemBuilder: (ctx, i) => FadeSlideIn(
                    index: i,
                    child: ProductCard(
                      product: items[i],
                      onTap: () => showProductSheet(ctx, items[i]),
                    ),
                  ),
                ),
          Align(
            alignment: Alignment.bottomCenter,
            child: CartBar(onTap: () => openCart(context)),
          ),
        ],
      ),
    );
  }
}
