import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart' hide Order;
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart'
    show
        CameraFit,
        FlutterMap,
        MapController,
        MapOptions,
        Marker,
        MarkerLayer,
        AttributionAlignment,
        RichAttributionWidget,
        TextSourceAttribution,
        TileLayer;
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart' show LatLng;
import 'package:provider/provider.dart';
import 'auth.dart';
import 'models.dart';
import 'store.dart';
import 'theme.dart';

FirebaseFirestore? _firestore() {
  try {
    if (Firebase.apps.isEmpty) return null;
    return FirebaseFirestore.instance;
  } catch (_) {
    return null;
  }
}

// =====================================================
//  إرسال موقع السائق (يشتغل حتى لو الشاشة مقفلة)
// =====================================================

enum TrackState { off, on, noPermission }

class DriverTracker extends ChangeNotifier {
  DriverTracker._();
  static final DriverTracker instance = DriverTracker._();

  Store? _store;
  StreamSubscription<Position>? _sub;
  Set<int> _active = {};
  bool _starting = false;
  bool _blocked = false;
  TrackState state = TrackState.off;

  /// يربط المتتبّع بالمتجر: يبدأ لما السائق يستلم طلب، ويوقف لما يسلّمه
  void attach(Store store) {
    if (!identical(_store, store)) {
      _store?.removeListener(_sync);
      _store = store;
      store.addListener(_sync);
    }
    _sync();
  }

  void retry() {
    _blocked = false;
    _sync();
  }

  void _set(TrackState s) {
    state = s;
    notifyListeners();
  }

  Future<void> _sync() async {
    final st = _store;
    if (st == null) return;
    final me = AuthService.instance.uid;
    final now = st.orders
        .where((o) => o.status == 'بالطريق' && me != null && o.driverUid == me)
        .map((o) => o.no)
        .toSet();
    for (final n in _active.difference(now)) {
      _firestore()?.collection('tracking').doc('$n').delete().catchError((_) {});
    }
    _active = now;
    if (now.isEmpty) {
      await _stop();
    } else if (_sub == null && !_blocked) {
      await _start();
    }
  }

  Future<void> _start() async {
    if (_starting) return;
    _starting = true;
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        _blocked = true;
        _set(TrackState.noPermission);
        return;
      }
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
      if (p == LocationPermission.denied || p == LocationPermission.deniedForever) {
        _blocked = true;
        _set(TrackState.noPermission);
        return;
      }
      final settings = AndroidSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 15,
        intervalDuration: const Duration(seconds: 8),
        foregroundNotificationConfig: const ForegroundNotificationConfig(
          notificationTitle: 'ماركت حراير',
          notificationText: 'جاري مشاركة موقعك مع الزبون أثناء التوصيل',
          enableWakeLock: true,
          setOngoing: true,
        ),
      );
      _sub = Geolocator.getPositionStream(locationSettings: settings).listen(
        _onPos,
        onError: (_) {
          _blocked = true;
          _set(TrackState.noPermission);
        },
      );
      _set(TrackState.on);
      // أول موقع فوراً بدون انتظار الحركة
      try {
        final cur = await Geolocator.getCurrentPosition(
          locationSettings: AndroidSettings(accuracy: LocationAccuracy.high, timeLimit: const Duration(seconds: 12)),
        );
        _onPos(cur);
      } catch (_) {}
    } catch (_) {
      _blocked = true;
      _set(TrackState.noPermission);
    } finally {
      _starting = false;
    }
  }

  void _onPos(Position pos) {
    final db = _firestore();
    if (db == null) return;
    final data = {
      'lat': pos.latitude,
      'lng': pos.longitude,
      't': DateTime.now().millisecondsSinceEpoch,
    };
    for (final n in _active) {
      db.collection('tracking').doc('$n').set(data).catchError((_) {});
    }
  }

  Future<void> _stop() async {
    await _sub?.cancel();
    _sub = null;
    if (state != TrackState.off) _set(TrackState.off);
  }
}

/// شريط حالة التتبع في شاشة السائق
class TrackBanner extends StatelessWidget {
  const TrackBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final t = DriverTracker.instance;
    return ListenableBuilder(
      listenable: t,
      builder: (_, __) {
        if (t.state == TrackState.off) return const SizedBox.shrink();
        final ok = t.state == TrackState.on;
        return Container(
          width: double.infinity,
          color: ok ? const Color(0xFFE3F4E6) : const Color(0xFFFFEBEE),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  ok
                      ? '📡 الزبون يشوف موقعك الآن'
                      : '⚠️ فعّل الموقع وأعطِ التطبيق صلاحية الموقع حتى يشوفك الزبون',
                  style: TextStyle(fontWeight: FontWeight.bold, color: ok ? kGreen : kRed),
                ),
              ),
              if (!ok) TextButton(onPressed: t.retry, child: const Text('إعادة المحاولة')),
            ],
          ),
        );
      },
    );
  }
}

class _TileSrc {
  const _TileSrc(this.url, this.attribution, [this.subdomains = const ['a', 'b', 'c']]);
  final String url;
  final String attribution;
  final List<String> subdomains;
}

// إذا فشل مصدر الخرائط ننتقل تلقائياً للي بعده
const _tileSources = [
  _TileSrc('https://tile.openstreetmap.org/{z}/{x}/{y}.png', '© OpenStreetMap contributors'),
  _TileSrc('https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', '© OpenStreetMap contributors, HOT'),
  _TileSrc('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png',
      '© OpenStreetMap contributors © CARTO', ['a', 'b', 'c', 'd']),
];

// =====================================================
//  الخريطة الحيّة (للزبون ولصاحب المتجر)
// =====================================================

class LiveMapScreen extends StatefulWidget {
  const LiveMapScreen({super.key, required this.order});
  final Order order;

  @override
  State<LiveMapScreen> createState() => _LiveMapScreenState();
}

class _LiveMapScreenState extends State<LiveMapScreen> {
  final _map = MapController();
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _sub;
  Timer? _tick;
  LatLng? _driver;
  int? _t;
  bool _ready = false;
  int _src = 0;
  int _errs = 0;
  bool _mapFailed = false;
  String _lastErr = '';

  LatLng? get _home {
    final o = widget.order;
    if (o.lat == null || o.lng == null) return null;
    return LatLng(o.lat!, o.lng!);
  }

  @override
  void initState() {
    super.initState();
    _sub = _firestore()?.collection('tracking').doc('${widget.order.no}').snapshots().listen((d) {
      final m = d.data();
      if (!mounted) return;
      if (m == null) {
        setState(() => _driver = null);
        return;
      }
      setState(() {
        _driver = LatLng((m['lat'] as num).toDouble(), (m['lng'] as num).toDouble());
        _t = (m['t'] as num?)?.toInt();
      });
      _fit();
    }, onError: (_) {});
    _tick = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _tick?.cancel();
    _map.dispose();
    super.dispose();
  }

  void _fit() {
    if (!_ready) return;
    final pts = <LatLng>[];
    if (_driver != null) pts.add(_driver!);
    if (_home != null) pts.add(_home!);
    if (pts.isEmpty) return;
    if (pts.length == 1) {
      _map.move(pts.first, 16);
    } else {
      _map.fitCamera(CameraFit.coordinates(
        coordinates: pts,
        padding: const EdgeInsets.fromLTRB(60, 60, 60, 200),
        maxZoom: 17,
      ));
    }
  }

  Widget _pin(String emoji, Color c) => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(color: c, width: 3),
          boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 6)],
        ),
        alignment: Alignment.center,
        child: Text(emoji, style: const TextStyle(fontSize: 24)),
      );

  String _info(Order o) {
    if (o.status == 'تم التسليم') return 'تم تسليم الطلب ✅';
    if (o.status != 'بالطريق') return 'الطلب لسا ما طلع للتوصيل (${o.status})';
    if (_driver == null) return 'بانتظار موقع السائق…\nيظهر بعد ما السائق يستلم الطلب من تطبيقه ويفعّل الموقع';
    final parts = <String>[];
    final h = _home;
    if (h != null) {
      final m = Geolocator.distanceBetween(_driver!.latitude, _driver!.longitude, h.latitude, h.longitude);
      final dist = m >= 1000 ? '${(m / 1000).toStringAsFixed(1)} كم' : '${m.round()} متر';
      final mins = (m / (25000 / 60)).ceil().clamp(1, 999);
      parts.add('يبعد عنك $dist  •  يوصلك تقريباً خلال $mins دقيقة');
    }
    if (_t != null) {
      final s = ((DateTime.now().millisecondsSinceEpoch - _t!) / 1000).round();
      parts.add(s < 60 ? 'آخر تحديث قبل ${s < 0 ? 0 : s} ثانية' : 'آخر تحديث قبل ${(s / 60).round()} دقيقة');
    }
    return parts.join('\n');
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    var o = widget.order;
    for (final x in store.orders) {
      if (x.no == o.no) o = x;
    }
    final markers = <Marker>[];
    if (_home != null) {
      markers.add(Marker(point: _home!, width: 44, height: 44, child: _pin('🏠', kRed)));
    }
    if (_driver != null) {
      markers.add(Marker(point: _driver!, width: 48, height: 48, child: _pin('🛵', kGreen)));
    }

    return Scaffold(
      appBar: AppBar(title: Text('تتبع الطلب #${o.no}')),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _map,
            options: MapOptions(
              initialCenter: _home ?? const LatLng(33.3152, 44.3661),
              initialZoom: 14,
              onMapReady: () {
                _ready = true;
                _fit();
              },
            ),
            children: [
              TileLayer(
                key: ValueKey(_src),
                urlTemplate: _tileSources[_src].url,
                subdomains: _tileSources[_src].subdomains,
                userAgentPackageName: 'com.grocery.app',
                errorTileCallback: (tile, error, stack) {
                  _errs++;
                  _lastErr = '$error';
                  if (_errs < 8) return;
                  _errs = 0;
                  Future.microtask(() {
                    if (!mounted) return;
                    setState(() {
                      if (_src < _tileSources.length - 1) {
                        _src++;
                      } else {
                        _mapFailed = true;
                      }
                    });
                  });
                },
              ),
              MarkerLayer(markers: markers),
              RichAttributionWidget(
                alignment: AttributionAlignment.bottomLeft,
                attributions: [TextSourceAttribution(_tileSources[_src].attribution)],
              ),
            ],
          ),
          if (_mapFailed)
            Positioned(
              top: 12,
              left: 12,
              right: 12,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: const Color(0xFFFFEBEE), borderRadius: BorderRadius.circular(14)),
                child: Text(
                    'تعذر تحميل صور الخريطة. تأكد من الإنترنت وحاول مرة ثانية.\n${_lastErr.length > 160 ? _lastErr.substring(0, 160) : _lastErr}',
                    style: const TextStyle(color: kRed, fontWeight: FontWeight.bold, fontSize: 12)),
              ),
            ),
          Positioned(
            left: 12,
            right: 12,
            bottom: 40,
            child: SafeArea(
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10)],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (o.driver != null && o.driver!.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 4),
                              child: Text('🛵 ${o.driver}',
                                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                            ),
                          Text(_info(o), style: const TextStyle(fontSize: 14, height: 1.5)),
                        ],
                      ),
                    ),
                    IconButton.filledTonal(
                      tooltip: 'توسيط الخريطة',
                      onPressed: _fit,
                      icon: const Icon(Icons.my_location_rounded),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
