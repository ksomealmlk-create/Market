class Product {
  final int id;
  String name;
  int price;
  String category;
  String imageB64; // الصورة الحقيقية مضغوطة (base64) داخل Firestore - فارغ = نعرض الإيموجي

  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.category,
    this.imageB64 = '',
  });

  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['id'] as int,
        name: j['name'] as String,
        price: j['price'] as int,
        category: j['category'] as String,
        imageB64: (j['imageB64'] as String?) ?? '',
      );

  Map<String, dynamic> toJson({bool withImage = true}) => {
        'id': id,
        'name': name,
        'price': price,
        'category': category,
        if (withImage) 'imageB64': imageB64,
      };
}

class Category {
  final String name;
  final String icon;
  const Category(this.name, this.icon);
}

const List<Category> kCategories = [
  Category('بقالة', '🥬'),
  Category('جاهزة للأكل', '🥪'),
  Category('مخبوزات', '🍞'),
  Category('مخبوزات منزلية', '🧁'),
  Category('منتجات الألبان والبيض', '🥛'),
  Category('اللحوم', '🥩'),
  Category('اللحوم الباردة', '🥓'),
  Category('القهوة والشاي', '☕'),
  Category('حبوب ومنتجات الدهن', '🥣'),
  Category('الباستا والطعام المعلب', '🍝'),
  Category('المعلبات', '🥫'),
  Category('الصلصات والتتبيلات', '🍅'),
  Category('الأعشاب والبهارات', '🌿'),
  Category('المنتجات المثلجة', '🧊'),
  Category('ايس كريم', '🍦'),
  Category('السكاكر والحلويات', '🍫'),
  Category('التشيبس والمكسرات', '🥜'),
  Category('المشروبات', '🥤'),
  Category('المياه', '💧'),
  Category('العناية الشخصية', '🧴'),
  Category('العناية بالبشرة', '✨'),
  Category('العناية بالأطفال والرضع', '🍼'),
  Category('مستلزمات الغسيل والمنظفات', '🧺'),
  Category('أدوات التنظيف', '🧹'),
  Category('مستلزمات المطبخ', '🍽️'),
  Category('مستلزمات المنزل', '🏠'),
  Category('التبغ', '🚬'),
];

class CartLine {
  final Product product;
  int qty;
  String note;
  CartLine(this.product, this.qty, [this.note = '']);
}

class Order {
  final int no;
  final String uid; // معرّف حساب الزبون
  final String name;
  final String phone;
  final String address;
  final List<String> lines;
  final int total;
  String status;
  final int time;
  final double? lat;
  final double? lng;
  String? driver;
  String? driverPhone;
  String? driverUid;

  Order({
    required this.no,
    required this.uid,
    required this.name,
    required this.phone,
    required this.address,
    required this.lines,
    required this.total,
    required this.status,
    required this.time,
    this.lat,
    this.lng,
    this.driver,
    this.driverPhone,
    this.driverUid,
  });

  factory Order.fromJson(Map<String, dynamic> j) => Order(
        no: j['no'] as int,
        uid: (j['uid'] as String?) ?? '',
        name: j['name'] as String,
        phone: j['phone'] as String,
        address: j['address'] as String,
        lines: (j['lines'] as List).map((e) => e.toString()).toList(),
        total: j['total'] as int,
        status: j['status'] as String,
        time: j['time'] as int,
        lat: (j['lat'] as num?)?.toDouble(),
        lng: (j['lng'] as num?)?.toDouble(),
        driver: j['driver'] as String?,
        driverPhone: j['driverPhone'] as String?,
        driverUid: j['driverUid'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'no': no,
        'uid': uid,
        'name': name,
        'phone': phone,
        'address': address,
        'lines': lines,
        'total': total,
        'status': status,
        'time': time,
        'lat': lat,
        'lng': lng,
        'driver': driver,
        'driverPhone': driverPhone,
        'driverUid': driverUid,
      };
}

/// سائق مسجّل (يضيفه صاحب المتجر)
class Driver {
  final String uid;
  final String name;
  final String phone;
  const Driver(this.uid, this.name, this.phone);
}
