package com.grocery.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Product(val id: Int, var name: String, var price: Int, var category: String)

class CartLine(val product: Product, var qty: Int)

class Order(
    val no: Int,
    val name: String,
    val phone: String,
    val address: String,
    val lines: List<String>,
    val total: Int,
    var status: String,
    val time: Long
)

class Store(context: Context) {

    private val prefs = context.getSharedPreferences("grocery_store", Context.MODE_PRIVATE)

    val products = mutableListOf<Product>()
    val orders = mutableListOf<Order>()
    val cart = mutableListOf<CartLine>()

    val statuses = listOf("جديد", "قيد التجهيز", "بالطريق", "تم التسليم")

    var pin: String
        get() = prefs.getString("pin", "1234") ?: "1234"
        set(value) {
            prefs.edit().putString("pin", value).apply()
        }

    init {
        loadProducts()
        loadOrders()
    }

    // ---------- السلة ----------

    fun cartCount(): Int = cart.sumOf { it.qty }

    fun cartTotal(): Int = cart.sumOf { it.product.price * it.qty }

    fun addToCart(p: Product) {
        val line = cart.firstOrNull { it.product.id == p.id }
        if (line != null) line.qty += 1 else cart.add(CartLine(p, 1))
    }

    fun changeQty(line: CartLine, delta: Int) {
        line.qty += delta
        if (line.qty <= 0) cart.remove(line)
    }

    // ---------- الطلبات ----------

    fun placeOrder(name: String, phone: String, address: String) {
        val no = (orders.maxOfOrNull { it.no } ?: 0) + 1
        val lines = cart.map { "${it.product.name} × ${it.qty}" }
        orders.add(Order(no, name, phone, address, lines, cartTotal(), statuses[0], System.currentTimeMillis()))
        cart.clear()
        saveOrders()
    }

    fun saveOrders() {
        val arr = JSONArray()
        for (o in orders) {
            val j = JSONObject()
            j.put("no", o.no)
            j.put("name", o.name)
            j.put("phone", o.phone)
            j.put("address", o.address)
            j.put("lines", JSONArray(o.lines))
            j.put("total", o.total)
            j.put("status", o.status)
            j.put("time", o.time)
            arr.put(j)
        }
        prefs.edit().putString("orders", arr.toString()).apply()
    }

    private fun loadOrders() {
        orders.clear()
        val s = prefs.getString("orders", null) ?: return
        val arr = JSONArray(s)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val l = o.getJSONArray("lines")
            val lines = mutableListOf<String>()
            for (k in 0 until l.length()) lines.add(l.getString(k))
            orders.add(
                Order(
                    o.getInt("no"),
                    o.getString("name"),
                    o.getString("phone"),
                    o.getString("address"),
                    lines,
                    o.getInt("total"),
                    o.getString("status"),
                    o.getLong("time")
                )
            )
        }
    }

    // ---------- المنتجات ----------

    fun saveProduct(existing: Product?, name: String, price: Int, category: String) {
        if (existing == null) {
            val id = (products.maxOfOrNull { it.id } ?: 0) + 1
            products.add(Product(id, name, price, category))
        } else {
            existing.name = name
            existing.price = price
            existing.category = category
        }
        saveProducts()
    }

    fun deleteProduct(p: Product) {
        products.remove(p)
        cart.removeAll { it.product.id == p.id }
        saveProducts()
    }

    private fun saveProducts() {
        val arr = JSONArray()
        for (p in products) {
            val j = JSONObject()
            j.put("id", p.id)
            j.put("name", p.name)
            j.put("price", p.price)
            j.put("category", p.category)
            arr.put(j)
        }
        prefs.edit().putString("products", arr.toString()).apply()
    }

    private fun loadProducts() {
        products.clear()
        val s = prefs.getString("products", null)
        if (s == null) {
            seedProducts()
            saveProducts()
            return
        }
        val arr = JSONArray(s)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            products.add(Product(o.getInt("id"), o.getString("name"), o.getInt("price"), o.getString("category")))
        }
    }

    // منتجات تجريبية: صاحب المتجر يعدّلها من داخل التطبيق
    private fun seedProducts() {
        var id = 1
        fun add(name: String, price: Int, cat: String) {
            products.add(Product(id++, name, price, cat))
        }
        add("طماطم 1 كغم", 1500, "خضار وفواكه")
        add("خيار 1 كغم", 1250, "خضار وفواكه")
        add("بطاطا 1 كغم", 1000, "خضار وفواكه")
        add("موز 1 كغم", 2500, "خضار وفواكه")
        add("تفاح 1 كغم", 3000, "خضار وفواكه")
        add("حليب 1 لتر", 1500, "ألبان وبيض")
        add("لبن 1 لتر", 1250, "ألبان وبيض")
        add("جبن أبيض 500 غم", 4000, "ألبان وبيض")
        add("بيض 30 حبة", 5500, "ألبان وبيض")
        add("رز عنبر 5 كغم", 8000, "مواد أساسية")
        add("سكر 1 كغم", 1250, "مواد أساسية")
        add("زيت طبخ 1.5 لتر", 4500, "مواد أساسية")
        add("شاي 400 غم", 3500, "مواد أساسية")
        add("معكرونة 500 غم", 1000, "مواد أساسية")
        add("ماء 1.5 لتر", 500, "مشروبات")
        add("بيبسي 2.25 لتر", 1500, "مشروبات")
        add("عصير 1 لتر", 1750, "مشروبات")
        add("صابون سائل", 4000, "مواد تنظيف")
        add("مسحوق غسيل 2 كغم", 5500, "مواد تنظيف")
        add("مناديل ورقية", 1500, "مواد تنظيف")
    }
}
