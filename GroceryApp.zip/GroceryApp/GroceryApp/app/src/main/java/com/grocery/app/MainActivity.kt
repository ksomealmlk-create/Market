package com.grocery.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var store: Store
    private var screen = "home"
    private var selectedCategory = "الكل"
    private var cartLabel: TextView? = null

    private val green = Color.parseColor("#2E7D32")
    private val red = Color.parseColor("#C62828")
    private val gray = Color.parseColor("#757575")
    private val dark = Color.parseColor("#212121")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        window.statusBarColor = green
        home()
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (screen == "home") super.onBackPressed() else home()
    }

    // =====================================================
    //  شاشات الزبون
    // =====================================================

    private fun home() {
        screen = "home"
        val categories = listOf("الكل") + store.products.map { it.category }.distinct()
        if (selectedCategory !in categories) selectedCategory = "الكل"

        val col = column()

        val chipsScroll = HorizontalScrollView(this)
        chipsScroll.isHorizontalScrollBarEnabled = false
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        for (c in categories) {
            val selected = c == selectedCategory
            val chip = text(c, 15f, true, if (selected) Color.WHITE else green)
            chip.background = round(if (selected) green else Color.WHITE, 20)
            chip.setPadding(dp(16), dp(8), dp(16), dp(8))
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.marginEnd = dp(8)
            chip.layoutParams = lp
            chip.setOnClickListener {
                selectedCategory = c
                home()
            }
            chips.addView(chip)
        }
        chipsScroll.addView(chips)
        val chipsLp = LinearLayout.LayoutParams(MATCH, WRAP)
        chipsLp.bottomMargin = dp(12)
        col.addView(chipsScroll, chipsLp)

        val shown = store.products.filter { selectedCategory == "الكل" || it.category == selectedCategory }
        if (shown.isEmpty()) col.addView(text("لا توجد منتجات", 17f, false, gray))

        for (p in shown) {
            val card = card()
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL

            val info = LinearLayout(this)
            info.orientation = LinearLayout.VERTICAL
            info.addView(text(p.name, 17f, true))
            info.addView(text(money(p.price), 14f, false, gray))
            line.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))

            line.addView(smallButton("+ أضف", green) {
                store.addToCart(p)
                updateCartLabel()
                toast("أضيفت: ${p.name}")
            })
            card.addView(line)
            col.addView(card)
        }

        val cart = text("🛒 ${store.cartCount()}", 18f, true, Color.WHITE)
        cart.setPadding(dp(10), dp(4), dp(10), dp(4))
        cart.setOnClickListener { cartScreen() }
        cartLabel = cart

        val owner = text("⚙️", 20f, false, Color.WHITE)
        owner.setPadding(dp(10), dp(4), dp(10), dp(4))
        owner.setOnClickListener { ownerLogin() }

        page("متجري", null, listOf(cart, owner), scroll(col))
    }

    private fun updateCartLabel() {
        cartLabel?.text = "🛒 ${store.cartCount()}"
    }

    private fun cartScreen() {
        screen = "cart"
        val col = column()

        if (store.cart.isEmpty()) {
            col.addView(text("السلة فارغة", 18f, false, gray))
        } else {
            for (l in store.cart.toList()) {
                val card = card()
                card.addView(text(l.product.name, 17f, true))
                card.addView(text(money(l.product.price * l.qty), 14f, false, gray))

                val ctr = LinearLayout(this)
                ctr.orientation = LinearLayout.HORIZONTAL
                ctr.gravity = Gravity.CENTER_VERTICAL
                ctr.addView(smallButton("−", green) {
                    store.changeQty(l, -1)
                    cartScreen()
                })
                val q = text("${l.qty}", 18f, true)
                q.setPadding(dp(16), 0, dp(16), 0)
                ctr.addView(q)
                ctr.addView(smallButton("+", green) {
                    store.changeQty(l, 1)
                    cartScreen()
                })
                card.addView(full(ctr, 8))
                col.addView(card)
            }

            val totalCard = card()
            totalCard.addView(text("المجموع: ${money(store.cartTotal())}", 20f, true, green))
            col.addView(totalCard)
            col.addView(button("متابعة الطلب", green) { checkoutScreen() })
        }

        page("السلة", { home() }, emptyList(), scroll(col))
    }

    private fun checkoutScreen() {
        screen = "checkout"
        val col = column()

        col.addView(text("معلومات التوصيل", 18f, true))
        col.addView(space(8))
        val name = input("الاسم")
        val phone = input("رقم الهاتف", InputType.TYPE_CLASS_PHONE)
        val address = input("العنوان (المنطقة، الشارع، أقرب نقطة دالة)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
        col.addView(name)
        col.addView(phone)
        col.addView(address)

        col.addView(text("المجموع: ${money(store.cartTotal())}", 18f, true, green))
        col.addView(text("الدفع عند الاستلام", 15f, false, gray))
        col.addView(space(12))

        col.addView(button("إرسال الطلب", green) {
            val n = name.text.toString().trim()
            val ph = phone.text.toString().trim()
            val ad = address.text.toString().trim()
            if (n.isEmpty() || ph.isEmpty() || ad.isEmpty()) {
                toast("عبّي كل الحقول")
                return@button
            }
            if (store.cart.isEmpty()) {
                toast("السلة فارغة")
                return@button
            }
            store.placeOrder(n, ph, ad)
            toast("تم إرسال الطلب ✅")
            home()
        })

        page("إتمام الطلب", { cartScreen() }, emptyList(), scroll(col))
    }

    // =====================================================
    //  شاشات صاحب المتجر
    // =====================================================

    private fun ownerLogin() {
        screen = "ownerLogin"
        val col = column()
        col.addView(text("دخول صاحب المتجر", 18f, true))
        col.addView(space(8))
        val pin = input("الرمز السري", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        col.addView(pin)
        col.addView(text("الرمز الافتراضي: 1234 (غيّره بعد الدخول)", 13f, false, gray))
        col.addView(space(8))
        col.addView(button("دخول", green) {
            if (pin.text.toString() == store.pin) ownerOrders() else toast("الرمز غير صحيح")
        })
        page("صاحب المتجر", { home() }, emptyList(), scroll(col))
    }

    private fun ownerTabs(col: LinearLayout, active: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL

        val items = listOf("orders" to "الطلبات", "products" to "المنتجات", "pin" to "🔑 الرمز")
        for ((key, label) in items) {
            val selected = key == active
            val chip = text(label, 15f, true, if (selected) Color.WHITE else green)
            chip.background = round(if (selected) green else Color.WHITE, 20)
            chip.setPadding(dp(16), dp(8), dp(16), dp(8))
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.marginEnd = dp(8)
            chip.layoutParams = lp
            chip.setOnClickListener {
                when (key) {
                    "orders" -> ownerOrders()
                    "products" -> ownerProducts()
                    else -> changePinDialog()
                }
            }
            row.addView(chip)
        }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(12)
        col.addView(row, lp)
    }

    private fun ownerOrders() {
        screen = "owner"
        val col = column()
        ownerTabs(col, "orders")

        if (store.orders.isEmpty()) col.addView(text("لا توجد طلبات بعد", 17f, false, gray))

        for (o in store.orders.reversed()) {
            val c = card()
            c.addView(text("طلب #${o.no}  •  ${formatTime(o.time)}", 16f, true))
            c.addView(text("👤 ${o.name}", 15f))
            c.addView(text("📞 ${o.phone}", 15f))
            c.addView(text("📍 ${o.address}", 15f))
            c.addView(space(6))
            for (ln in o.lines) c.addView(text("• $ln", 15f))
            c.addView(space(6))
            c.addView(text("المجموع: ${money(o.total)}", 16f, true))
            c.addView(text("الحالة: ${o.status}", 16f, true, statusColor(o.status)))

            val idx = store.statuses.indexOf(o.status)
            if (idx >= 0 && idx < store.statuses.size - 1) {
                val next = store.statuses[idx + 1]
                c.addView(full(button("تحويل إلى: $next", green) {
                    o.status = next
                    store.saveOrders()
                    ownerOrders()
                }, 8))
            }
            c.addView(full(button("حذف الطلب", red) {
                AlertDialog.Builder(this)
                    .setMessage("حذف الطلب #${o.no}؟")
                    .setPositiveButton("حذف") { _, _ ->
                        store.orders.remove(o)
                        store.saveOrders()
                        ownerOrders()
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            }, 6))
            col.addView(c)
        }

        page("لوحة صاحب المتجر", { home() }, emptyList(), scroll(col))
    }

    private fun ownerProducts() {
        screen = "owner"
        val col = column()
        ownerTabs(col, "products")

        col.addView(button("+ إضافة منتج", green) { productDialog(null) })
        col.addView(space(10))

        for (p in store.products) {
            val c = card()
            c.addView(text(p.name, 17f, true))
            c.addView(text("${money(p.price)}  •  ${p.category}", 14f, false, gray))

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(smallButton("تعديل", green) { productDialog(p) })
            val sp = View(this)
            row.addView(sp, LinearLayout.LayoutParams(dp(8), 1))
            row.addView(smallButton("حذف", red) {
                AlertDialog.Builder(this)
                    .setMessage("حذف ${p.name}؟")
                    .setPositiveButton("حذف") { _, _ ->
                        store.deleteProduct(p)
                        ownerProducts()
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            })
            c.addView(full(row, 8))
            col.addView(c)
        }

        page("لوحة صاحب المتجر", { home() }, emptyList(), scroll(col))
    }

    private fun productDialog(p: Product?) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(10), dp(20), 0)

        val name = input("اسم المنتج")
        val price = input("السعر (دينار)", InputType.TYPE_CLASS_NUMBER)
        val cat = input("القسم")
        if (p != null) {
            name.setText(p.name)
            price.setText(p.price.toString())
            cat.setText(p.category)
        }
        box.addView(name)
        box.addView(price)
        box.addView(cat)

        AlertDialog.Builder(this)
            .setTitle(if (p == null) "إضافة منتج" else "تعديل المنتج")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim()
                val pr = price.text.toString().trim().toIntOrNull()
                val c = cat.text.toString().trim()
                if (n.isEmpty() || pr == null || c.isEmpty()) {
                    toast("البيانات ناقصة")
                } else {
                    store.saveProduct(p, n, pr, c)
                    ownerProducts()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun changePinDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        val pin = input("الرمز الجديد (4 أرقام أو أكثر)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        box.addView(pin)

        AlertDialog.Builder(this)
            .setTitle("تغيير الرمز السري")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val v = pin.text.toString()
                if (v.length < 4) {
                    toast("الرمز قصير")
                } else {
                    store.pin = v
                    toast("تم تغيير الرمز")
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // =====================================================
    //  أدوات مساعدة للواجهة
    // =====================================================

    private fun page(title: String, back: (() -> Unit)?, actions: List<View>, content: View) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(Color.parseColor("#F5F5F5"))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(green)
        bar.setPadding(dp(12), dp(12), dp(12), dp(12))

        if (back != null) {
            val b = text("→", 24f, true, Color.WHITE)
            b.setPadding(dp(8), 0, dp(16), 0)
            b.setOnClickListener { back() }
            bar.addView(b)
        }
        bar.addView(text(title, 20f, true, Color.WHITE), LinearLayout.LayoutParams(0, WRAP, 1f))
        for (a in actions) bar.addView(a)

        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun column(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(12), dp(12), dp(12), dp(24))
        return c
    }

    private fun scroll(content: View): ScrollView {
        val s = ScrollView(this)
        s.addView(content)
        return s
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        c.background = round(Color.WHITE, 14)
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(10)
        c.layoutParams = lp
        return c
    }

    private fun text(s: String, size: Float = 16f, bold: Boolean = false, color: Int = dark): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        t.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        return t
    }

    private fun button(s: String, bg: Int = green, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setTextColor(Color.WHITE)
        b.isAllCaps = false
        b.textSize = 16f
        b.background = round(bg, 12)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun smallButton(s: String, bg: Int = green, onClick: () -> Unit): Button {
        val b = button(s, bg, onClick)
        b.minWidth = 0
        b.minimumWidth = dp(56)
        b.minHeight = 0
        b.minimumHeight = dp(40)
        return b
    }

    private fun input(hint: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
        val e = EditText(this)
        e.hint = hint
        e.inputType = type
        e.setTextColor(dark)
        e.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        e.background = round(Color.parseColor("#EEEEEE"), 10)
        e.setPadding(dp(12), dp(12), dp(12), dp(12))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(10)
        e.layoutParams = lp
        return e
    }

    private fun space(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(MATCH, dp(h))
        return v
    }

    private fun <T : View> full(v: T, top: Int = 8): T {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(top)
        v.layoutParams = lp
        return v
    }

    private fun round(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun money(n: Int): String = String.format(Locale.US, "%,d", n) + " د.ع"

    private fun formatTime(t: Long): String =
        SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(t))

    private fun statusColor(status: String): Int = when (status) {
        "جديد" -> Color.parseColor("#E65100")
        "قيد التجهيز" -> Color.parseColor("#1565C0")
        "بالطريق" -> Color.parseColor("#6A1B9A")
        else -> green
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}
