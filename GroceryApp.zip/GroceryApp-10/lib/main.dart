import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';
import 'home.dart';
import 'store.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // لا نسمح لأي خلل بتهيئة Firebase (نت بطيء، مشكلة إعداد...) بمنع فتح التطبيق
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.android);
  } catch (_) {
    // يفتح التطبيق بالبيانات المحلية ويحاول الاتصال بالسحابة لاحقاً
  }
  final store = await Store.load();
  runApp(ChangeNotifierProvider<Store>.value(value: store, child: const GroceryApp()));
}

class GroceryApp extends StatelessWidget {
  const GroceryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'متجري',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const HomeScreen(),
    );
  }
}
