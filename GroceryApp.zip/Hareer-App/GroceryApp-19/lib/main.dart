import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'auth.dart';
import 'firebase_options.dart';
import 'home.dart';
import 'notifications.dart';
import 'store.dart';
import 'theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // نرسم شاشة تحميل فوراً، وبعدها نحاول نهيئ فايربيس ونحمّل البيانات.
  // هيك إذا صار أي خطأ، تطلع رسالة واضحة بدل شاشة بيضة فارغة.
  runApp(const _Bootstrap());
}

class _Bootstrap extends StatefulWidget {
  const _Bootstrap({super.key});

  @override
  State<_Bootstrap> createState() => _BootstrapState();
}

class _BootstrapState extends State<_Bootstrap> {
  Store? _store;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      await Firebase.initializeApp(options: DefaultFirebaseOptions.android);
    } catch (e) {
      // نكمل بدون فايربيس، التطبيق يشتغل محلياً
      debugPrint('Firebase init failed: $e');
    }
    // الإشعارات (قنوات الصوت) وحالة تسجيل الدخول لازم يجهزوا قبل المتجر
    await NotificationService.instance.init();
    await AuthService.instance.init();
    try {
      final store = await Store.load();
      if (!mounted) return;
      setState(() => _store = store);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          backgroundColor: Colors.white,
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('صار خطأ عند تشغيل التطبيق:',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    SelectableText(_error!, style: const TextStyle(color: kRed, fontSize: 13)),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    }
    if (_store == null) {
      return const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          backgroundColor: kGreen,
          body: Center(child: CircularProgressIndicator(color: Colors.white)),
        ),
      );
    }
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<Store>.value(value: _store!),
        ChangeNotifierProvider<AuthService>.value(value: AuthService.instance),
      ],
      child: const GroceryApp(),
    );
  }
}

class GroceryApp extends StatelessWidget {
  const GroceryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'حرير',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const HomeScreen(),
    );
  }
}
