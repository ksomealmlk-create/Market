import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart' hide Order;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'features.dart';
import 'models.dart';
import 'notifications.dart';
import 'owner.dart';
import 'store.dart';
import 'theme.dart';
import 'tracking.dart';
import 'widgets.dart';

// =====================================================
//  الأدوار: زائر / زبون / سائق / صاحب المتجر
//  - صاحب المتجر = وجود مستند admins/{uid} في Firestore
//  - السائق      = وجود مستند drivers/{uid} (يضيفه صاحب المتجر من الإعدادات)
//  - غير ذلك    = زبون (بدون تسجيل دخول: حساب مجهول تلقائي + معلوماته تنحفظ بالجهاز)
// =====================================================

enum Role { guest, customer, driver, owner }

class AuthService extends ChangeNotifier {
  AuthService._();
  static final AuthService instance = AuthService._();

  FirebaseAuth? get _auth {
    try {
      if (Firebase.apps.isEmpty) return null;
      return FirebaseAuth.instance;
    } catch (_) {
      return null;
    }
  }

  FirebaseFirestore? get _db {
    try {
      if (Firebase.apps.isEmpty) return null;
      return FirebaseFirestore.instance;
    } catch (_) {
      return null;
    }
  }

  StreamSubscription<User?>? _sub;
  User? user;
  Role role = Role.guest;
  String name = '';
  String phone = '';
  bool ready = false; // خلصنا أول تحميل لحالة الدخول

  String? get uid => user?.uid;
  bool get isLoggedIn => user != null;
  bool get isOwner => role == Role.owner;
  bool get isDriver => role == Role.driver;

  /// الزبون العادي يشتغل بحساب مجهول (بدون رقم سري). الموظف = حساب بإيميل/رقم + كلمة سر.
  bool get isStaffSession => user != null && !(user!.isAnonymous);

  // ---------- معلومات الزبون المحفوظة بالجهاز ----------
  static const _kName = 'saved_name';
  static const _kPhone = 'saved_phone';
  String _localName = '';
  String _localPhone = '';
  bool get hasSavedProfile => _localName.isNotEmpty && _localPhone.isNotEmpty;

  Future<void> _loadLocal() async {
    try {
      final p = await SharedPreferences.getInstance();
      _localName = p.getString(_kName) ?? '';
      _localPhone = p.getString(_kPhone) ?? '';
    } catch (_) {}
  }

  /// نص يظهر بالقائمة (اسم المستخدم أو رقمه)
  String get displayName => name.isNotEmpty ? name : (phone.isNotEmpty ? phone : 'حسابي');

  Future<void> init() async {
    await _loadLocal();
    final a = _auth;
    if (a == null) {
      ready = true;
      notifyListeners();
      return;
    }
    final first = Completer<void>();
    _sub = a.authStateChanges().listen((u) async {
      await _resolve(u);
      if (!first.isCompleted) first.complete();
    });
    await first.future.timeout(const Duration(seconds: 8), onTimeout: () {});
    // زبون سبق وسجّل معلوماته (مثلاً بعد خروج موظف) → نرجّعه تلقائياً بدون أي شاشة
    if (a.currentUser == null && hasSavedProfile) {
      await ensureCustomer();
    }
  }

  /// يتأكد أن عند الزبون حساب شغّال (مجهول) بدون ما يشوف أي شاشة تسجيل.
  /// يرجع true إذا نجح.
  Future<bool> ensureCustomer() async {
    final a = _auth;
    if (a == null) return false;
    if (a.currentUser != null) return true;
    try {
      await a.signInAnonymously();
      // authStateChanges يحمّل الدور؛ ننتظر لحظة حتى يستقر
      await _resolve(a.currentUser);
      return true;
    } catch (e) {
      debugPrint('anonymous sign-in failed: $e');
      return false;
    }
  }

  /// يحفظ معلومات الزبون (بالجهاز + بملفه بالسحابة) حتى تنكتب تلقائياً المرة الجاية
  Future<void> saveProfile({required String name, required String phone}) async {
    _localName = name;
    _localPhone = phone;
    this.name = name;
    this.phone = phone;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_kName, name);
      await p.setString(_kPhone, phone);
    } catch (_) {}
    final u = user;
    if (u != null) {
      try {
        await _db?.collection('users').doc(u.uid).set({
          'name': name,
          'phone': phone,
          'createdAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      } catch (e) {
        debugPrint('save profile failed: $e');
      }
    }
    notifyListeners();
  }

  Future<void> _resolve(User? u) async {
    user = u;
    role = Role.guest;
    name = '';
    phone = '';
    if (u != null) {
      role = Role.customer;
      final db = _db;
      try {
        if (db != null) {
          final results = await Future.wait([
            db.collection('admins').doc(u.uid).get(),
            db.collection('drivers').doc(u.uid).get(),
            db.collection('users').doc(u.uid).get(),
          ]);
          final admin = results[0], driver = results[1], profile = results[2];
          if (admin.exists) {
            role = Role.owner;
          } else if (driver.exists) {
            role = Role.driver;
          }
          final m = (driver.exists ? driver.data() : profile.data()) ?? {};
          name = (m['name'] as String?) ?? u.displayName ?? '';
          phone = (m['phone'] as String?) ?? '';
        }
      } catch (e) {
        debugPrint('resolve role failed: $e');
        name = u.displayName ?? '';
      }
      // الزبون: إذا ما لقينا معلوماته بالسحابة نستعمل المحفوظ بالجهاز
      if (role == Role.customer) {
        if (name.isEmpty) name = _localName;
        if (phone.isEmpty) phone = _localPhone;
      }
    }
    ready = true;
    notifyListeners();
    // نسجّل توكن الإشعارات لهذا الحساب
    NotificationService.instance.onAuthChanged(this);
  }

  // ---------- تحويل رقم الهاتف إلى "إيميل" داخلي ----------
  // الزبون يسجّل برقم هاتفه + كلمة سر (بدون رسائل SMS وبدون تكلفة).
  // إذا كتب إيميل حقيقي (مثل صاحب المتجر) نستعمله كما هو.
  static String toEmail(String input) {
    var t = input.trim();
    if (t.contains('@')) return t.toLowerCase();
    const ar = '٠١٢٣٤٥٦٧٨٩';
    final b = StringBuffer();
    for (final ch in t.split('')) {
      final i = ar.indexOf(ch);
      b.write(i >= 0 ? '$i' : ch);
    }
    var d = b.toString().replaceAll(RegExp(r'[^0-9]'), '');
    if (d.startsWith('00')) d = d.substring(2);
    if (d.startsWith('0')) d = '964${d.substring(1)}';
    if (d.length == 10 && d.startsWith('7')) d = '964$d';
    return '$d@phone.matjari.app';
  }

  static String errorText(Object e) {
    if (e is FirebaseAuthException) {
      switch (e.code) {
        case 'invalid-credential':
        case 'wrong-password':
        case 'user-not-found':
        case 'invalid-login-credentials':
          return 'الرقم أو كلمة السر غير صحيحة';
        case 'email-already-in-use':
          return 'هذا الرقم مسجّل من قبل، سجّل دخول';
        case 'weak-password':
          return 'كلمة السر ضعيفة (6 رموز على الأقل)';
        case 'invalid-email':
          return 'الرقم أو الإيميل غير صالح';
        case 'network-request-failed':
          return 'تأكد من الإنترنت وحاول مرة ثانية';
        case 'too-many-requests':
          return 'محاولات كثيرة، انتظر شوي وحاول مرة ثانية';
        case 'operation-not-allowed':
          return 'فعّل تسجيل الدخول بالإيميل/كلمة السر من Firebase Console';
        case 'user-disabled':
          return 'هذا الحساب موقوف';
      }
      return 'خطأ: ${e.code}';
    }
    return 'صار خطأ، حاول مرة ثانية';
  }

  Future<void> signIn(String idInput, String password) async {
    await _auth!.signInWithEmailAndPassword(email: toEmail(idInput), password: password);
  }

  Future<void> resetPassword(String email) => _auth!.sendPasswordResetEmail(email: email.trim());

  Future<void> signOut() async {
    await NotificationService.instance.onBeforeSignOut(this);
    await _auth?.signOut();
    if (hasSavedProfile) await ensureCustomer();
  }

  // ---------- السائقين (من جهة صاحب المتجر) ----------

  /// ينشئ حساب سائق جديد بدون ما يطلع صاحب المتجر من حسابه
  /// (نستعمل نسخة فايربيس ثانوية للإنشاء فقط).
  Future<void> createDriver({required String name, required String phone, required String password}) async {
    final db = _db;
    if (db == null) throw 'لا يوجد اتصال بقاعدة البيانات';
    final email = toEmail(phone);
    FirebaseApp app;
    try {
      app = Firebase.app('driver-create');
    } catch (_) {
      app = await Firebase.initializeApp(name: 'driver-create', options: Firebase.app().options);
    }
    final secondary = FirebaseAuth.instanceFor(app: app);
    final cred = await secondary.createUserWithEmailAndPassword(email: email, password: password);
    final newUid = cred.user!.uid;
    await secondary.signOut();
    await db.collection('drivers').doc(newUid).set({
      'name': name,
      'phone': phone,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<List<Driver>> driversStream() {
    final db = _db;
    if (db == null) return const Stream.empty();
    return db.collection('drivers').snapshots().map((s) => s.docs
        .map((d) => Driver(d.id, (d.data()['name'] as String?) ?? '', (d.data()['phone'] as String?) ?? ''))
        .toList());
  }

  Future<void> removeDriver(String driverUid) async {
    await _db?.collection('drivers').doc(driverUid).delete();
  }
}

// =====================================================
//  شاشة تسجيل الدخول / إنشاء حساب
// =====================================================

/// الزبون ما عنده تسجيل دخول: نفتح له حساب مجهول بالخلفية بدون أي شاشة.
/// يرجع true إذا الحساب جاهز.
Future<bool> requireLogin(BuildContext context, {String? reason}) async {
  final auth = AuthService.instance;
  if (auth.isLoggedIn) return true;
  final ok = await auth.ensureCustomer();
  if (!ok && context.mounted) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(const SnackBar(content: Text('تعذر الاتصال، تأكد من الإنترنت وحاول مرة ثانية')));
  }
  return ok;
}

/// دخول الموظفين فقط (صاحب المتجر / السائق)
Future<bool> openStaffLogin(BuildContext context) async {
  final ok = await Navigator.push<bool>(
    context,
    MaterialPageRoute(builder: (_) => const LoginScreen()),
  );
  return ok == true;
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _id = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false;
  bool _hide = true;
  String? _error;

  @override
  void dispose() {
    _id.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final id = _id.text.trim();
    final pass = _pass.text;
    if (id.isEmpty || pass.isEmpty) {
      setState(() => _error = 'عبّي كل الحقول');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await AuthService.instance.signIn(id, pass);
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = AuthService.errorText(e);
      });
    }
  }

  Future<void> _forgot() async {
    final id = _id.text.trim();
    if (!id.contains('@')) {
      setState(() => _error = 'استعادة كلمة السر تشتغل للحسابات المسجّلة بإيميل فقط.');
      return;
    }
    try {
      await AuthService.instance.resetPassword(id);
      if (!mounted) return;
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('أرسلنا رابط تغيير كلمة السر لإيميلك')));
    } catch (e) {
      if (mounted) setState(() => _error = AuthService.errorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('دخول الموظفين')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 8),
            const Center(child: Text('🔐', style: TextStyle(fontSize: 56))),
            const SizedBox(height: 8),
            const Center(
              child: Text(
                'خاص بصاحب المتجر والسائقين',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: kGray),
              ),
            ),
            const SizedBox(height: 22),
            TextField(
              controller: _id,
              keyboardType: TextInputType.emailAddress,
              textDirection: TextDirection.ltr,
              textAlign: TextAlign.start,
              decoration: const InputDecoration(hintText: 'رقم الهاتف أو الإيميل'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _pass,
              obscureText: _hide,
              textDirection: TextDirection.ltr,
              textAlign: TextAlign.start,
              onSubmitted: (_) => _busy ? null : _submit(),
              decoration: InputDecoration(
                hintText: 'كلمة السر',
                suffixIcon: IconButton(
                  icon: Icon(_hide ? Icons.visibility_off_outlined : Icons.visibility_outlined),
                  onPressed: () => setState(() => _hide = !_hide),
                ),
              ),
            ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(_error!, style: const TextStyle(color: kRed, fontWeight: FontWeight.bold)),
              ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _busy ? null : _submit,
                child: _busy
                    ? const SizedBox(
                        width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('دخول'),
              ),
            ),
            TextButton(onPressed: _busy ? null : _forgot, child: const Text('نسيت كلمة السر؟')),
          ],
        ),
      ),
    );
  }
}

// =====================================================
//  نافذة الحساب (من القائمة بالصفحة الرئيسية)
// =====================================================

void showAccountSheet(BuildContext context) {
  final auth = AuthService.instance;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: Colors.transparent,
    builder: (ctx) => ListenableBuilder(
      listenable: auth,
      builder: (_, __) => Container(
        decoration: const BoxDecoration(color: kBg, borderRadius: kSheetRadius),
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SheetHandle(),
              Text(auth.isOwner ? '🔐' : auth.isDriver ? '🛵' : '👤', style: const TextStyle(fontSize: 40)),
              const SizedBox(height: 6),
              Text(auth.displayName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              if (auth.phone.isNotEmpty) Text(auth.phone, style: const TextStyle(color: kGray)),
              Text(
                auth.isOwner ? 'صاحب المتجر' : auth.isDriver ? 'سائق' : 'زبون',
                style: const TextStyle(color: kGray, fontSize: 13),
              ),
              if (!auth.isStaffSession && !auth.hasSavedProfile)
                const Padding(
                  padding: EdgeInsets.only(top: 6),
                  child: Text('معلوماتك تنحفظ تلقائياً بأول طلب',
                      style: TextStyle(color: kGray, fontSize: 13)),
                ),
              const SizedBox(height: 16),
              if (auth.isOwner)
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    icon: const Icon(Icons.storefront_rounded),
                    label: const Text('لوحة صاحب المتجر'),
                    onPressed: () {
                      Navigator.pop(ctx);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const OwnerScreen()));
                    },
                  ),
                ),
              if (auth.isDriver)
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    icon: const Icon(Icons.delivery_dining_rounded),
                    label: const Text('شاشة السائق'),
                    onPressed: () {
                      Navigator.pop(ctx);
                      DriverTracker.instance.attach(context.read<Store>());
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const DriverScreen()));
                    },
                  ),
                ),
              if (!auth.isOwner && !auth.isDriver)
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    icon: const Icon(Icons.receipt_long_rounded),
                    label: const Text('طلباتي'),
                    onPressed: () {
                      Navigator.pop(ctx);
                      openMyOrders(context);
                    },
                  ),
                ),
              if (!auth.isStaffSession) ...[
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.badge_outlined),
                    label: const Text('دخول الموظفين'),
                    onPressed: () {
                      Navigator.pop(ctx);
                      openStaffLogin(context);
                    },
                  ),
                ),
              ] else ...[
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.copy_rounded, size: 18),
                    label: const Text('نسخ معرّف الحساب (UID)'),
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: auth.uid ?? ''));
                      ScaffoldMessenger.of(context)
                        ..hideCurrentSnackBar()
                        ..showSnackBar(const SnackBar(content: Text('تم نسخ المعرّف')));
                    },
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(foregroundColor: kRed),
                    icon: const Icon(Icons.logout_rounded),
                    label: const Text('تسجيل الخروج'),
                    onPressed: () async {
                      Navigator.pop(ctx);
                      await auth.signOut();
                    },
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    ),
  );
}
