plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.grocery.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.grocery.app"
        minSdk = 24
        targetSdk = 34
        // رقم الإصدار يزيد تلقائياً مع كل بناء على GitHub حتى يقبل التثبيت فوق القديم
        val run = (System.getenv("GITHUB_RUN_NUMBER") ?: "0").toInt()
        versionCode = 10 + run
        versionName = "1.$run"
    }

    // توقيع ثابت: نفس المفتاح كل مرة => التحديث فوق التطبيق القديم بدون حذف
    signingConfigs {
        create("fixed") {
            storeFile = file("grocery.keystore")
            storePassword = "grocery123"
            keyAlias = "grocery"
            keyPassword = "grocery123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
