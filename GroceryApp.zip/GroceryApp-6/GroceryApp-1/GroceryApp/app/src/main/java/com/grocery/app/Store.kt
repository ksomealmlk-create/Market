package com.grocery.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Product(val id: Int, var name: String, var price: Int, var category: String)

data class Category(val name: String, val icon: String)

val CATEGORIES = listOf(
    Category("بقالة", "🥬"),
    Category("جاهزة للأكل", "🥪"),
    Category("مخبوزات", "🍞"),
    Category("مخبوزات منزلية", "🧁"),
    Category("منتجات الألبان والبيض", "🥛"),
    Category("اللحوم", "🥩"),
    Category("اللحوم الباردة", "🥓"),
    Category("القهوة والشاي", "☕"),
    Category("حبوب ومنتجات الدهن", "🥣"),
    Category("الباستا والطعام المعلب", "🍝"),
    Category("المعلبات", "🥫"),
    Category("الصلصات والتتبيلات", "🍅"),
    Category("الأعشاب والبهارات", "🌿"),
    Category("المنتجات المثلجة", "🧊"),
    Category("ايس كريم", "🍦"),
    Category("السكاكر والحلويات", "🍫"),
    Category("التشيبس والمكسرات", "🥜"),
    Category("المشروبات", "🥤"),
    Category("المياه", "💧"),
    Category("العناية الشخصية", "🧴"),
    Category("العناية بالبشرة", "✨"),
    Category("العناية بالأطفال والرضع", "🍼"),
    Category("مستلزمات الغسيل والمنظفات", "🧺"),
    Category("أدوات التنظيف", "🧹"),
    Category("مستلزمات المطبخ", "🍽️"),
    Category("مستلزمات المنزل", "🏠"),
    Category("التبغ", "🚬")
)

class CartLine(val product: Product, var qty: Int, var note: String = "")

class Order(
    val no: Int,
    val name: String,
    val phone: String,
    val address: String,
    val lines: List<String>,
    val total: Int,
    var status: String,
    val time: Long
)

class Store(context: Context) {

    private val prefs = context.getSharedPreferences("grocery_store", Context.MODE_PRIVATE)

    val products = mutableListOf<Product>()
    val orders = mutableListOf<Order>()
    val cart = mutableListOf<CartLine>()

    val statuses = listOf("جديد", "قيد التجهيز", "بالطريق", "تم التسليم")

    var pin: String
        get() = prefs.getString("pin", "1234") ?: "1234"
        set(value) {
            prefs.edit().putString("pin", value).apply()
        }

    init {
        loadProducts()
        loadOrders()
    }

    // ---------- السلة ----------

    fun cartCount(): Int = cart.sumOf { it.qty }

    fun cartTotal(): Int = cart.sumOf { it.product.price * it.qty }

    fun addToCart(p: Product) {
        val line = cart.firstOrNull { it.product.id == p.id }
        if (line != null) line.qty += 1 else cart.add(CartLine(p, 1))
    }

    fun qtyOf(p: Product): Int = cart.firstOrNull { it.product.id == p.id }?.qty ?: 0

    fun lineOf(p: Product): CartLine? = cart.firstOrNull { it.product.id == p.id }

    fun setQty(p: Product, q: Int) {
        val line = lineOf(p)
        if (q <= 0) {
            if (line != null) cart.remove(line)
        } else if (line != null) line.qty = q else cart.add(CartLine(p, q))
    }

    // عنوان افتراضي محفوظ
    var savedName: String
        get() = prefs.getString("saved_name", "") ?: ""
        set(v) { prefs.edit().putString("saved_name", v).apply() }
    var savedPhone: String
        get() = prefs.getString("saved_phone", "") ?: ""
        set(v) { prefs.edit().putString("saved_phone", v).apply() }
    var savedAddress: String
        get() = prefs.getString("saved_address", "") ?: ""
        set(v) { prefs.edit().putString("saved_address", v).apply() }

    fun changeQty(line: CartLine, delta: Int) {
        line.qty += delta
        if (line.qty <= 0) cart.remove(line)
    }

    // ---------- الطلبات ----------

    fun placeOrder(name: String, phone: String, address: String) {
        val no = (orders.maxOfOrNull { it.no } ?: 0) + 1
        val lines = cart.map { "${it.product.name} × ${it.qty}" + (if (it.note.isNotBlank()) " (${it.note})" else "") }
        orders.add(Order(no, name, phone, address, lines, cartTotal(), statuses[0], System.currentTimeMillis()))
        cart.clear()
        saveOrders()
    }

    fun saveOrders() {
        val arr = JSONArray()
        for (o in orders) {
            val j = JSONObject()
            j.put("no", o.no)
            j.put("name", o.name)
            j.put("phone", o.phone)
            j.put("address", o.address)
            j.put("lines", JSONArray(o.lines))
            j.put("total", o.total)
            j.put("status", o.status)
            j.put("time", o.time)
            arr.put(j)
        }
        prefs.edit().putString("orders", arr.toString()).apply()
    }

    private fun loadOrders() {
        orders.clear()
        val s = prefs.getString("orders", null) ?: return
        val arr = JSONArray(s)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val l = o.getJSONArray("lines")
            val lines = mutableListOf<String>()
            for (k in 0 until l.length()) lines.add(l.getString(k))
            orders.add(
                Order(
                    o.getInt("no"),
                    o.getString("name"),
                    o.getString("phone"),
                    o.getString("address"),
                    lines,
                    o.getInt("total"),
                    o.getString("status"),
                    o.getLong("time")
                )
            )
        }
    }

    // ---------- المنتجات ----------

    fun saveProduct(existing: Product?, name: String, price: Int, category: String) {
        if (existing == null) {
            val id = (products.maxOfOrNull { it.id } ?: 0) + 1
            products.add(Product(id, name, price, category))
        } else {
            existing.name = name
            existing.price = price
            existing.category = category
        }
        saveProducts()
    }

    fun deleteProduct(p: Product) {
        products.remove(p)
        cart.removeAll { it.product.id == p.id }
        saveProducts()
    }

    private fun saveProducts() {
        val arr = JSONArray()
        for (p in products) {
            val j = JSONObject()
            j.put("id", p.id)
            j.put("name", p.name)
            j.put("price", p.price)
            j.put("category", p.category)
            arr.put(j)
        }
        prefs.edit().putString("products_v2", arr.toString()).apply()
    }

    private fun loadProducts() {
        products.clear()
        val s = prefs.getString("products_v2", null)
        if (s == null) {
            seedProducts()
            saveProducts()
            return
        }
        val arr = JSONArray(s)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            products.add(Product(o.getInt("id"), o.getString("name"), o.getInt("price"), o.getString("category")))
        }
        // حذف منتجات الأقسام المحذوفة
        val valid = CATEGORIES.map { it.name }.toSet()
        if (products.removeAll { it.category !in valid }) saveProducts()
    }

    // منتجات تجريبية: صاحب المتجر يعدّلها من داخل التطبيق
    private fun seedProducts() {
        var id = 1
        fun add(name: String, price: Int, cat: String) {
            products.add(Product(id++, name, price, cat))
        }
        add("طماطم 1 كغم", 1500, "بقالة")
        add("خيار 1 كغم", 1250, "بقالة")
        add("بطاطا 1 كغم", 1000, "بقالة")
        add("موز 1 كغم", 2500, "بقالة")
        add("تفاح 1 كغم", 3000, "بقالة")
        add("سكر 1 كغم", 1250, "بقالة")
        add("صمون", 500, "مخبوزات")
        add("حليب 1 لتر", 1500, "منتجات الألبان والبيض")
        add("لبن 1 لتر", 1250, "منتجات الألبان والبيض")
        add("جبن أبيض 500 غم", 4000, "منتجات الألبان والبيض")
        add("بيض 30 حبة", 5500, "منتجات الألبان والبيض")
        add("شاي 400 غم", 3500, "القهوة والشاي")
        add("زيت طبخ 1.5 لتر", 4500, "حبوب ومنتجات الدهن")
        add("رز عنبر 5 كغم", 8000, "الباستا والطعام المعلب")
        add("معكرونة 500 غم", 1000, "الباستا والطعام المعلب")
        add("عصير 1 لتر", 1750, "المشروبات")
        add("بيبسي 2.25 لتر", 1500, "المشروبات")
        add("ماء 1.5 لتر", 500, "المياه")
        add("صابون سائل", 4000, "العناية الشخصية")
        add("مسحوق غسيل 2 كغم", 5500, "مستلزمات الغسيل والمنظفات")
        add("مناديل ورقية", 1500, "مستلزمات المنزل")
    }
}
