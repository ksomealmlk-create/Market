package com.grocery.app

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.graphics.drawable.ColorDrawable
import android.view.Window
import android.widget.CheckBox
import android.widget.FrameLayout
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var store: Store
    private var screen = "home"
    private var cartLabel: TextView? = null
    private var cartPill: TextView? = null
    private val expanded = mutableSetOf<Int>()

    private val green = Color.parseColor("#2E7D32")
    private val red = Color.parseColor("#C62828")
    private val gray = Color.parseColor("#757575")
    private val dark = Color.parseColor("#212121")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        window.statusBarColor = green
        home()
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (screen == "home") super.onBackPressed() else home()
    }

    // =====================================================
    //  شاشات الزبون
    // =====================================================

    private fun home() {
        screen = "home"
        val col = column()

        val search = input("ابحث عن منتج")
        col.addView(search)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        col.addView(box)

        fun render(q: String) {
            box.removeAllViews()
            if (q.isBlank()) {
                box.addView(text("الأقسام", 20f, true))
                box.addView(space(10))
                box.addView(categoryGrid())
                box.addView(space(8))
                box.addView(categoryStrips())
            } else {
                val found = store.products.filter { it.name.contains(q.trim(), ignoreCase = true) }
                if (found.isEmpty()) box.addView(text("ما لقينا منتج بهذا الاسم", 16f, false, gray))
                for (p in found) box.addView(productRow(p) { home() })
            }
        }
        render("")

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                render(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        val owner = text("⚙️", 20f, false, Color.WHITE)
        owner.setPadding(dp(10), dp(4), dp(10), dp(4))
        owner.setOnClickListener { ownerLogin() }

        page("متجري", null, listOf(cartAction(), owner), scroll(col), null, true)
    }

    // أقسام بشريط منتجات أفقي (اسم القسم + سهم + منتجاته)
    private fun categoryStrips(): LinearLayout {
        val all = LinearLayout(this)
        all.orientation = LinearLayout.VERTICAL
        for (c in CATEGORIES) {
            val items = store.products.filter { it.category == c.name }
            if (items.isEmpty()) continue

            val header = LinearLayout(this)
            header.orientation = LinearLayout.HORIZONTAL
            header.gravity = Gravity.CENTER_VERTICAL
            header.setPadding(dp(4), dp(14), dp(4), dp(6))
            header.addView(text(c.icon + " " + c.name, 18f, true), LinearLayout.LayoutParams(0, WRAP, 1f))
            val arrow = text("←", 18f, true, green)
            arrow.setPadding(dp(12), dp(2), dp(12), dp(2))
            header.addView(arrow)
            header.setOnClickListener { categoryScreen(c.name) }
            all.addView(header)

            val hs = HorizontalScrollView(this)
            hs.isHorizontalScrollBarEnabled = false
            val strip = LinearLayout(this)
            strip.orientation = LinearLayout.HORIZONTAL
            for (p in items) strip.addView(stripCard(p, dp(140)) { productScreen(p) { home() } })
            hs.addView(strip)
            all.addView(hs, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        return all
    }

    // ---------- عناصر مشتركة للمنتجات ----------

    private fun iconOf(p: Product): String =
        CATEGORIES.firstOrNull { it.name == p.category }?.icon ?: "🛒"

    private fun outline(bg: Int, radius: Int, stroke: Int, strokeDp: Int = 1): GradientDrawable {
        val g = round(bg, radius)
        g.setStroke(dp(strokeDp), stroke)
        return g
    }

    private fun thumb(p: Product, w: Int, h: Int, font: Float): TextView {
        val t = TextView(this)
        t.text = iconOf(p)
        t.textSize = font
        t.gravity = Gravity.CENTER
        t.background = round(Color.parseColor("#F1F3F4"), 12)
        t.layoutParams = LinearLayout.LayoutParams(w, h)
        return t
    }

    private fun circle(label: String, bg: Int, fg: Int, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 17f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(fg)
        t.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(bg)
        g.setStroke(dp(1), Color.parseColor("#DDDDDD"))
        t.background = g
        t.elevation = dp(2).toFloat()
        t.layoutParams = FrameLayout.LayoutParams(dp(38), dp(38))
        t.setOnClickListener { onClick() }
        return t
    }

    // عدّاد: (حذف/−) كمية (+)
    private fun stepper(q: Int, trash: Boolean, onMinus: () -> Unit, onPlus: () -> Unit, onQty: (() -> Unit)? = null): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER_VERTICAL
        b.background = outline(Color.WHITE, 22, Color.parseColor("#DDDDDD"))
        b.elevation = dp(2).toFloat()
        fun cell(s: String, c: Int, f: () -> Unit): TextView {
            val t = text(s, 18f, true, c)
            t.textAlignment = View.TEXT_ALIGNMENT_CENTER
            t.setPadding(dp(11), dp(6), dp(11), dp(6))
            t.setOnClickListener { f() }
            return t
        }
        b.addView(cell(if (q <= 1 && trash) "🗑" else "−", if (q <= 1 && trash) red else green, onMinus))
        val qt = text("$q", 17f, true)
        qt.textAlignment = View.TEXT_ALIGNMENT_CENTER
        qt.setPadding(dp(4), dp(6), dp(4), dp(6))
        if (onQty != null) qt.setOnClickListener { onQty() }
        b.addView(qt)
        b.addView(cell("+", green, onPlus))
        return b
    }

    // زر الإضافة: ➕ → عدّاد → دائرة بالعدد
    private fun addControl(p: Product): View {
        val box = FrameLayout(this)
        fun render() {
            box.removeAllViews()
            val q = store.qtyOf(p)
            if (q == 0) {
                box.addView(circle("+", Color.WHITE, green) {
                    store.setQty(p, 1)
                    expanded.add(p.id)
                    updateCartLabel()
                    render()
                })
            } else if (p.id !in expanded) {
                box.addView(circle("$q", green, Color.WHITE) {
                    expanded.add(p.id)
                    render()
                })
            } else {
                box.addView(stepper(q, true, {
                    store.setQty(p, q - 1)
                    if (q - 1 <= 0) expanded.remove(p.id)
                    updateCartLabel()
                    render()
                }, {
                    store.setQty(p, q + 1)
                    updateCartLabel()
                    render()
                }, {
                    expanded.remove(p.id)
                    render()
                }), FrameLayout.LayoutParams(WRAP, WRAP))
            }
        }
        render()
        return box
    }

    private fun stripCard(p: Product, widthPx: Int, onOpen: (() -> Unit)?): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(8), dp(8), dp(8), dp(8))
        card.background = round(Color.WHITE, 14)
        val lp = LinearLayout.LayoutParams(widthPx, WRAP)
        lp.setMargins(dp(4), dp(2), dp(4), dp(6))
        card.layoutParams = lp

        val img = FrameLayout(this)
        val th = thumb(p, MATCH, dp(96), 44f)
        th.layoutParams = FrameLayout.LayoutParams(MATCH, dp(96))
        img.addView(th)
        val clp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.LEFT or Gravity.BOTTOM)
        clp.setMargins(dp(4), dp(4), dp(4), dp(4))
        img.addView(addControl(p), clp)
        card.addView(img, LinearLayout.LayoutParams(MATCH, dp(96)))

        card.addView(text(money(p.price), 14f, true, green))
        val name = text(p.name, 13f, false)
        name.minLines = 2
        name.maxLines = 2
        card.addView(name)
        if (onOpen != null) card.setOnClickListener { onOpen() }
        return card
    }

    // ---------- صفحة المنتج ----------

    private fun productScreen(p: Product, back: () -> Unit) {
        screen = "product"
        val existing = store.lineOf(p)
        var qty = existing?.qty ?: 1
        var note = existing?.note ?: ""

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val img = thumb(p, MATCH, dp(220), 90f)
        img.background = round(Color.WHITE, 0)
        img.layoutParams = LinearLayout.LayoutParams(MATCH, dp(220))
        col.addView(img)

        val info = column()
        info.addView(text(p.name, 22f, true))
        info.addView(text(money(p.price), 20f, true, green))
        info.addView(space(6))
        val chip = text("${iconOf(p)}  ${p.category}", 14f, false, green)
        chip.setPadding(dp(12), dp(6), dp(12), dp(6))
        chip.background = round(Color.parseColor("#E8F5E9"), 16)
        chip.setOnClickListener { categoryScreen(p.category) }
        val chipLp = LinearLayout.LayoutParams(WRAP, WRAP)
        chipLp.topMargin = dp(4)
        info.addView(chip, chipLp)
        info.addView(space(10))

        // تعليمات خاصة
        val notesCard = card()
        val nh = LinearLayout(this)
        nh.orientation = LinearLayout.HORIZONTAL
        nh.gravity = Gravity.CENTER_VERTICAL
        nh.addView(text("أي تعليمات خاصة؟", 16f, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val chev = text("⌄", 20f, true, gray)
        nh.addView(chev)
        notesCard.addView(nh)
        val noteInput = input("مثال: بدون أكياس، أنضج، قطّع...")
        noteInput.setText(note)
        noteInput.visibility = if (note.isBlank()) View.GONE else View.VISIBLE
        notesCard.addView(full(noteInput, 8))
        nh.setOnClickListener {
            noteInput.visibility = if (noteInput.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        info.addView(notesCard)

        // منتجات مشابهة
        val similar = store.products.filter { it.category == p.category && it.id != p.id }.take(12)
        if (similar.isNotEmpty()) {
            info.addView(space(6))
            info.addView(text("منتجات مشابهة", 18f, true))
            val hs = HorizontalScrollView(this)
            hs.isHorizontalScrollBarEnabled = false
            val strip = LinearLayout(this)
            strip.orientation = LinearLayout.HORIZONTAL
            for (q in similar) strip.addView(stripCard(q, dp(140)) { productScreen(q) { productScreen(p, back) } })
            hs.addView(strip)
            info.addView(hs)
        }
        col.addView(info)

        // الشريط السفلي: العدّاد + زر السلة
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setBackgroundColor(Color.WHITE)
        bottom.setPadding(dp(14), dp(10), dp(14), dp(12))
        bottom.elevation = dp(8).toFloat()
        val stepRow = LinearLayout(this)
        stepRow.gravity = Gravity.CENTER
        bottom.addView(stepRow, LinearLayout.LayoutParams(MATCH, WRAP))
        val addBtn = button("", green) {
            store.setQty(p, qty)
            store.lineOf(p)?.note = noteInput.text.toString().trim()
            updateCartLabel()
            back()
        }
        bottom.addView(full(addBtn, 8))

        fun refresh() {
            stepRow.removeAllViews()
            stepRow.addView(stepper(qty, false, {
                if (qty > 1) { qty--; refresh() }
            }, {
                qty++
                refresh()
            }))
            val label = if (existing != null) "تحديث السلة" else "داخل السلة"
            addBtn.text = "$label   •   ${money(p.price * qty)}"
        }
        refresh()

        page(p.name, back, listOf(cartAction()), scroll(col), bottom)
    }

    private fun categoryScreen(name: String) {
        screen = "category"
        val col = column()
        val items = store.products.filter { it.category == name }
        if (items.isEmpty()) col.addView(text("لا توجد منتجات بهذا القسم بعد", 17f, false, gray))
        for (p in items) col.addView(productRow(p) { categoryScreen(name) })
        page(name, { home() }, listOf(cartAction()), scroll(col), null, true)
    }

    private fun categoryGrid(onClick: (Category) -> Unit = { categoryScreen(it.name) }, showCount: Boolean = false): LinearLayout {
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        for (chunk in CATEGORIES.chunked(3)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (i in 0 until 3) {
                if (i < chunk.size) {
                    row.addView(categoryTile(chunk[i], onClick, showCount), LinearLayout.LayoutParams(0, WRAP, 1f))
                } else {
                    row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                }
            }
            grid.addView(row)
        }
        return grid
    }

    private fun categoryTile(c: Category, onClick: (Category) -> Unit, showCount: Boolean): View {
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.setPadding(dp(4), dp(6), dp(4), dp(10))

        val iconBox = TextView(this)
        iconBox.text = c.icon
        iconBox.textSize = 38f
        iconBox.gravity = Gravity.CENTER
        iconBox.background = round(Color.parseColor("#E9E9EE"), 18)
        tile.addView(iconBox, LinearLayout.LayoutParams(MATCH, dp(92)))

        val name = text(c.name, 13f, true)
        name.textAlignment = View.TEXT_ALIGNMENT_CENTER
        name.minLines = 2
        name.maxLines = 2
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(6)
        tile.addView(name, lp)

        if (showCount) {
            val n = store.products.count { it.category == c.name }
            val cnt = text("$n منتج", 12f, false, gray)
            cnt.textAlignment = View.TEXT_ALIGNMENT_CENTER
            tile.addView(cnt)
        }

        tile.setOnClickListener { onClick(c) }
        return tile
    }

    private fun productRow(p: Product, back: () -> Unit): View {
        val card = card()
        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL

        line.addView(thumb(p, dp(64), dp(64), 28f))

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.setPadding(dp(12), 0, dp(8), 0)
        info.addView(text(p.name, 16f, true))
        info.addView(text(money(p.price), 14f, true, green))
        line.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))

        line.addView(addControl(p))
        card.addView(line)
        card.setOnClickListener { productScreen(p, back) }
        return card
    }

    private fun cartAction(): TextView {
        val cart = text("🛒 ${store.cartCount()}", 18f, true, Color.WHITE)
        cart.setPadding(dp(10), dp(4), dp(10), dp(4))
        cart.setOnClickListener { cartScreen() }
        cartLabel = cart
        return cart
    }

    private fun updateCartLabel() {
        cartLabel?.text = "🛒 ${store.cartCount()}"
        val pill = cartPill
        if (pill != null) {
            pill.visibility = if (store.cartCount() == 0) View.GONE else View.VISIBLE
            pill.text = "🛒  ${store.cartCount()} عناصر   •   ${money(store.cartTotal())}   ‹"
        }
    }

    private fun cartScreen() {
        screen = "cart"
        val col = column()

        if (store.cart.isEmpty()) {
            col.addView(text("السلة فارغة", 18f, false, gray))
            page("سلتي", { home() }, emptyList(), scroll(col))
            return
        }

        val box = card()
        for ((i, l) in store.cart.toList().withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))

            row.addView(thumb(l.product, dp(56), dp(56), 26f))

            val info = LinearLayout(this)
            info.orientation = LinearLayout.VERTICAL
            info.setPadding(dp(10), 0, dp(8), 0)
            info.addView(text(l.product.name, 15f, true))
            info.addView(text(money(l.product.price * l.qty), 14f, true, green))
            if (l.note.isNotBlank()) info.addView(text("📝 ${l.note}", 12f, false, gray))
            row.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))

            row.addView(stepper(l.qty, true, {
                store.changeQty(l, -1)
                cartScreen()
            }, {
                store.changeQty(l, 1)
                cartScreen()
            }))
            box.addView(row)
            if (i < store.cart.size - 1) {
                val div = View(this)
                div.setBackgroundColor(Color.parseColor("#EEEEEE"))
                box.addView(div, LinearLayout.LayoutParams(MATCH, dp(1)))
            }
        }
        col.addView(box)

        val sub = LinearLayout(this)
        sub.orientation = LinearLayout.HORIZONTAL
        sub.setPadding(dp(6), dp(8), dp(6), dp(8))
        sub.addView(text("المجموع الجزئي", 16f, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        sub.addView(text(money(store.cartTotal()), 16f, true))
        col.addView(sub)

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setBackgroundColor(Color.WHITE)
        bottom.setPadding(dp(12), dp(10), dp(12), dp(12))
        bottom.elevation = dp(8).toFloat()

        val more = button("أضف المزيد", Color.WHITE) { home() }
        more.setTextColor(green)
        more.background = outline(Color.WHITE, 12, Color.parseColor("#DDDDDD"))
        bottom.addView(more, LinearLayout.LayoutParams(WRAP, dp(52)))

        val go = button("إتمام الشراء   •   ${money(store.cartTotal())}", green) {
            suggestionsDialog { checkoutScreen() }
        }
        val glp = LinearLayout.LayoutParams(0, dp(52), 1f)
        glp.leftMargin = dp(8)
        glp.rightMargin = dp(8)
        bottom.addView(go, glp)

        page("سلتي", { home() }, emptyList(), scroll(col), bottom)
    }

    // نافذة "قد يعجبك أيضاً" قبل إتمام الشراء
    private fun suggestionsDialog(onDone: () -> Unit) {
        val inCart = store.cart.map { it.product.id }.toSet()
        val cats = store.cart.map { it.product.category }.toSet()
        var sug = store.products.filter { it.id !in inCart && it.category in cats }.shuffled().take(6)
        if (sug.isEmpty()) sug = store.products.filter { it.id !in inCart }.shuffled().take(6)
        if (sug.isEmpty()) {
            onDone()
            return
        }

        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setPadding(dp(12), dp(14), dp(12), dp(14))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#F5F5F5"))
        val r = dp(22).toFloat()
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        root.background = bg

        val title = text("قد يعجبك أيضاً", 18f, true)
        title.textAlignment = View.TEXT_ALIGNMENT_CENTER
        root.addView(title)
        root.addView(space(8))

        val w = (resources.displayMetrics.widthPixels - dp(24 + 24)) / 3
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        for (chunk in sug.chunked(3)) {
            val rowL = LinearLayout(this)
            rowL.orientation = LinearLayout.HORIZONTAL
            for (p in chunk) rowL.addView(stripCard(p, w, null))
            grid.addView(rowL)
        }
        val sc = ScrollView(this)
        sc.addView(grid)
        root.addView(sc, LinearLayout.LayoutParams(MATCH, WRAP))

        root.addView(full(button("إتمام الشراء", green) {
            d.dismiss()
            onDone()
        }, 10))

        d.setContentView(root)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout(MATCH, WRAP)
        d.window?.setGravity(Gravity.BOTTOM)
        d.show()
    }

    private fun checkoutScreen() {
        screen = "checkout"
        val col = column()
        var now = true
        val picked = mutableSetOf<String>()

        // وقت التوصيل
        val timeCard = card()
        timeCard.addView(text("وقت التوصيل", 17f, true))
        val timeRow = LinearLayout(this)
        timeRow.orientation = LinearLayout.HORIZONTAL
        val laterInput = input("متى تريد الاستلام؟ مثال: الساعة 6 مساءً")
        laterInput.visibility = View.GONE
        fun renderTime() {
            timeRow.removeAllViews()
            fun opt(t1: String, t2: String, sel: Boolean, f: () -> Unit): View {
                val o = LinearLayout(this)
                o.orientation = LinearLayout.VERTICAL
                o.gravity = Gravity.CENTER
                o.setPadding(dp(8), dp(12), dp(8), dp(12))
                o.background = if (sel) outline(Color.parseColor("#E8F5E9"), 12, green, 2)
                               else round(Color.parseColor("#F1F3F4"), 12)
                val a1 = text(t1, 15f, true, if (sel) green else dark)
                a1.textAlignment = View.TEXT_ALIGNMENT_CENTER
                val a2 = text(t2, 13f, false, gray)
                a2.textAlignment = View.TEXT_ALIGNMENT_CENTER
                o.addView(a1)
                o.addView(a2)
                o.setOnClickListener { f() }
                return o
            }
            val lp1 = LinearLayout.LayoutParams(0, WRAP, 1f)
            lp1.setMargins(dp(4), dp(8), dp(4), 0)
            timeRow.addView(opt("الآن", "10 - 20 د", now) { now = true; renderTime() }, lp1)
            timeRow.addView(opt("اطلب لوقت لاحق", "اختر الوقت", !now) { now = false; renderTime() }, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.setMargins(dp(4), dp(8), dp(4), 0) })
            laterInput.visibility = if (now) View.GONE else View.VISIBLE
        }
        renderTime()
        timeCard.addView(timeRow)
        timeCard.addView(full(laterInput, 8))
        col.addView(timeCard)

        // عنوان التوصيل
        val addrCard = card()
        addrCard.addView(text("عنوان التوصيل", 17f, true))
        addrCard.addView(space(8))
        val name = input("الاسم")
        val phone = input("رقم الهاتف", InputType.TYPE_CLASS_PHONE)
        val address = input("العنوان (المنطقة، الشارع، أقرب نقطة دالة)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
        name.setText(store.savedName)
        phone.setText(store.savedPhone)
        address.setText(store.savedAddress)
        addrCard.addView(name)
        addrCard.addView(phone)
        addrCard.addView(address)
        col.addView(addrCard)

        // تعليمات التوصيل
        val insCard = card()
        insCard.addView(text("تعليمات التوصيل", 17f, true))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        for ((ic, label) in listOf("📞" to "الرجاء الاتصال عند الوصول", "🔕" to "لا ترن الجرس", "🚪" to "اتركه عند الباب")) {
            val c = text("$ic  $label", 14f, false)
            c.setPadding(dp(14), dp(12), dp(14), dp(12))
            c.background = outline(Color.WHITE, 12, Color.parseColor("#DDDDDD"))
            c.setOnClickListener {
                if (label in picked) {
                    picked.remove(label)
                    c.background = outline(Color.WHITE, 12, Color.parseColor("#DDDDDD"))
                } else {
                    picked.add(label)
                    c.background = outline(Color.parseColor("#E8F5E9"), 12, green, 2)
                }
            }
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.setMargins(dp(4), dp(8), dp(4), dp(8))
            chips.addView(c, lp)
        }
        hs.addView(chips)
        insCard.addView(hs)
        val saveDef = CheckBox(this)
        saveDef.text = "حفظ كعنوان افتراضي"
        saveDef.isChecked = store.savedAddress.isNotBlank()
        insCard.addView(saveDef)
        col.addView(insCard)

        // الدفع
        val payCard = card()
        payCard.addView(text("طريقة الدفع", 17f, true))
        payCard.addView(text("💵 الدفع نقداً عند الاستلام", 15f, false, gray))
        col.addView(payCard)

        // الشريط السفلي
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setBackgroundColor(Color.WHITE)
        bottom.setPadding(dp(14), dp(10), dp(14), dp(12))
        bottom.elevation = dp(8).toFloat()

        val tot = LinearLayout(this)
        tot.orientation = LinearLayout.VERTICAL
        tot.addView(text("المبلغ الإجمالي", 13f, false, gray))
        tot.addView(text(money(store.cartTotal()), 18f, true))
        bottom.addView(tot, LinearLayout.LayoutParams(0, WRAP, 1f))

        bottom.addView(button("إتمام الطلب", green) {
            val n = name.text.toString().trim()
            val ph = phone.text.toString().trim()
            val ad = address.text.toString().trim()
            if (n.isEmpty() || ph.isEmpty() || ad.isEmpty()) {
                toast("عبّي كل الحقول")
                return@button
            }
            if (store.cart.isEmpty()) {
                toast("السلة فارغة")
                return@button
            }
            if (saveDef.isChecked) {
                store.savedName = n
                store.savedPhone = ph
                store.savedAddress = ad
            }
            var full = ad
            full += if (now) "\nالوقت: الآن" else "\nالوقت: " + laterInput.text.toString().trim().ifEmpty { "لاحقاً" }
            if (picked.isNotEmpty()) full += "\nتعليمات: " + picked.joinToString("، ")
            store.placeOrder(n, ph, full)
            toast("تم إرسال الطلب ✅")
            home()
        }, LinearLayout.LayoutParams(dp(150), dp(52)))

        page("إتمام الشراء", { cartScreen() }, emptyList(), scroll(col), bottom)
    }

    // =====================================================
    //  شاشات صاحب المتجر
    // =====================================================

    private fun ownerLogin() {
        screen = "ownerLogin"
        val col = column()
        col.addView(text("دخول صاحب المتجر", 18f, true))
        col.addView(space(8))
        val pin = input("الرمز السري", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        col.addView(pin)
        col.addView(text("الرمز الافتراضي: 1234 (غيّره بعد الدخول)", 13f, false, gray))
        col.addView(space(8))
        col.addView(button("دخول", green) {
            if (pin.text.toString() == store.pin) ownerOrders() else toast("الرمز غير صحيح")
        })
        page("صاحب المتجر", { home() }, emptyList(), scroll(col))
    }

    private fun ownerTabs(col: LinearLayout, active: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL

        val items = listOf("orders" to "الطلبات", "products" to "المنتجات", "pin" to "🔑 الرمز")
        for ((key, label) in items) {
            val selected = key == active
            val chip = text(label, 15f, true, if (selected) Color.WHITE else green)
            chip.background = round(if (selected) green else Color.WHITE, 20)
            chip.setPadding(dp(16), dp(8), dp(16), dp(8))
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.marginEnd = dp(8)
            chip.layoutParams = lp
            chip.setOnClickListener {
                when (key) {
                    "orders" -> ownerOrders()
                    "products" -> ownerProducts()
                    else -> changePinDialog()
                }
            }
            row.addView(chip)
        }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(12)
        col.addView(row, lp)
    }

    private fun ownerOrders() {
        screen = "owner"
        val col = column()
        ownerTabs(col, "orders")

        if (store.orders.isEmpty()) col.addView(text("لا توجد طلبات بعد", 17f, false, gray))

        for (o in store.orders.reversed()) {
            val c = card()
            c.addView(text("طلب #${o.no}  •  ${formatTime(o.time)}", 16f, true))
            c.addView(text("👤 ${o.name}", 15f))
            c.addView(text("📞 ${o.phone}", 15f))
            c.addView(text("📍 ${o.address}", 15f))
            c.addView(space(6))
            for (ln in o.lines) c.addView(text("• $ln", 15f))
            c.addView(space(6))
            c.addView(text("المجموع: ${money(o.total)}", 16f, true))
            c.addView(text("الحالة: ${o.status}", 16f, true, statusColor(o.status)))

            val idx = store.statuses.indexOf(o.status)
            if (idx >= 0 && idx < store.statuses.size - 1) {
                val next = store.statuses[idx + 1]
                c.addView(full(button("تحويل إلى: $next", green) {
                    o.status = next
                    store.saveOrders()
                    ownerOrders()
                }, 8))
            }
            c.addView(full(button("حذف الطلب", red) {
                AlertDialog.Builder(this)
                    .setMessage("حذف الطلب #${o.no}؟")
                    .setPositiveButton("حذف") { _, _ ->
                        store.orders.remove(o)
                        store.saveOrders()
                        ownerOrders()
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            }, 6))
            col.addView(c)
        }

        page("لوحة صاحب المتجر", { home() }, emptyList(), scroll(col))
    }

    private fun ownerProducts() {
        screen = "owner"
        val col = column()
        ownerTabs(col, "products")

        col.addView(button("+ إضافة منتج", green) { productDialog(null, null) { ownerProducts() } })
        col.addView(space(10))
        col.addView(text("اختر القسم", 18f, true))
        col.addView(space(8))
        col.addView(categoryGrid({ c -> ownerCategory(c.name) }, true))

        page("لوحة صاحب المتجر", { home() }, emptyList(), scroll(col))
    }

    private fun ownerCategory(cat: String) {
        screen = "owner"
        val col = column()
        val refresh = { ownerCategory(cat) }

        col.addView(button("+ إضافة منتج إلى $cat", green) { productDialog(null, cat, refresh) })
        col.addView(space(10))

        val items = store.products.filter { it.category == cat }
        if (items.isEmpty()) col.addView(text("لا توجد منتجات بهذا القسم بعد", 17f, false, gray))

        for (p in items) {
            val c = card()
            c.addView(text(p.name, 17f, true))
            c.addView(text(money(p.price), 14f, false, gray))

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(smallButton("تعديل", green) { productDialog(p, null, refresh) })
            row.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
            row.addView(smallButton("حذف", red) {
                AlertDialog.Builder(this)
                    .setMessage("حذف ${p.name}؟")
                    .setPositiveButton("حذف") { _, _ ->
                        store.deleteProduct(p)
                        refresh()
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            })
            c.addView(full(row, 8))
            col.addView(c)
        }

        page(cat, { ownerProducts() }, emptyList(), scroll(col))
    }

    private fun productDialog(p: Product?, defaultCat: String?, after: () -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(10), dp(20), 0)

        val name = input("اسم المنتج")
        val price = input("السعر (دينار)", InputType.TYPE_CLASS_NUMBER)
        var chosen = p?.category ?: defaultCat ?: CATEGORIES[0].name
        if (p != null) {
            name.setText(p.name)
            price.setText(p.price.toString())
        }
        val catBtn = button("القسم: $chosen", Color.parseColor("#455A64")) {}
        catBtn.setOnClickListener {
            val names = CATEGORIES.map { it.name }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("اختر القسم")
                .setItems(names) { _, i ->
                    chosen = names[i]
                    catBtn.text = "القسم: $chosen"
                }
                .show()
        }
        box.addView(name)
        box.addView(price)
        box.addView(catBtn)

        AlertDialog.Builder(this)
            .setTitle(if (p == null) "إضافة منتج" else "تعديل المنتج")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim()
                val pr = price.text.toString().trim().toIntOrNull()
                if (n.isEmpty() || pr == null) {
                    toast("البيانات ناقصة")
                } else {
                    store.saveProduct(p, n, pr, chosen)
                    after()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun changePinDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        val pin = input("الرمز الجديد (4 أرقام أو أكثر)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        box.addView(pin)

        AlertDialog.Builder(this)
            .setTitle("تغيير الرمز السري")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val v = pin.text.toString()
                if (v.length < 4) {
                    toast("الرمز قصير")
                } else {
                    store.pin = v
                    toast("تم تغيير الرمز")
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // =====================================================
    //  أدوات مساعدة للواجهة
    // =====================================================

    private fun page(
        title: String,
        back: (() -> Unit)?,
        actions: List<View>,
        content: View,
        bottom: View? = null,
        floatCart: Boolean = false
    ) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(Color.parseColor("#F5F5F5"))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(green)
        bar.setPadding(dp(12), dp(12), dp(12), dp(12))

        if (back != null) {
            val b = text("→", 24f, true, Color.WHITE)
            b.setPadding(dp(8), 0, dp(16), 0)
            b.setOnClickListener { back() }
            bar.addView(b)
        }
        bar.addView(text(title, 20f, true, Color.WHITE), LinearLayout.LayoutParams(0, WRAP, 1f))
        for (a in actions) bar.addView(a)

        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))

        cartPill = null
        if (floatCart) {
            content.setPadding(0, 0, 0, dp(80))
            (content as? ScrollView)?.clipToPadding = false
            val fl = FrameLayout(this)
            fl.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
            val pill = TextView(this)
            pill.textSize = 16f
            pill.setTypeface(null, Typeface.BOLD)
            pill.setTextColor(Color.WHITE)
            pill.setPadding(dp(22), dp(14), dp(22), dp(14))
            pill.background = round(Color.parseColor("#00A86B"), 30)
            pill.elevation = dp(8).toFloat()
            pill.setOnClickListener { cartScreen() }
            val plp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM)
            plp.bottomMargin = dp(16)
            fl.addView(pill, plp)
            cartPill = pill
            root.addView(fl, LinearLayout.LayoutParams(MATCH, 0, 1f))
        } else {
            root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        if (bottom != null) root.addView(bottom, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        updateCartLabel()
    }

    private fun column(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(12), dp(12), dp(12), dp(24))
        return c
    }

    private fun scroll(content: View): ScrollView {
        val s = ScrollView(this)
        s.addView(content)
        return s
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        c.background = round(Color.WHITE, 14)
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(10)
        c.layoutParams = lp
        return c
    }

    private fun text(s: String, size: Float = 16f, bold: Boolean = false, color: Int = dark): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        t.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        return t
    }

    private fun button(s: String, bg: Int = green, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setTextColor(Color.WHITE)
        b.isAllCaps = false
        b.textSize = 16f
        b.background = round(bg, 12)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun smallButton(s: String, bg: Int = green, onClick: () -> Unit): Button {
        val b = button(s, bg, onClick)
        b.minWidth = 0
        b.minimumWidth = dp(56)
        b.minHeight = 0
        b.minimumHeight = dp(40)
        return b
    }

    private fun input(hint: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
        val e = EditText(this)
        e.hint = hint
        e.inputType = type
        e.setTextColor(dark)
        e.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        e.background = round(Color.parseColor("#EEEEEE"), 10)
        e.setPadding(dp(12), dp(12), dp(12), dp(12))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(10)
        e.layoutParams = lp
        return e
    }

    private fun space(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(MATCH, dp(h))
        return v
    }

    private fun <T : View> full(v: T, top: Int = 8): T {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(top)
        v.layoutParams = lp
        return v
    }

    private fun round(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun money(n: Int): String = String.format(Locale.US, "%,d", n) + " د.ع"

    private fun formatTime(t: Long): String =
        SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(t))

    private fun statusColor(status: String): Int = when (status) {
        "جديد" -> Color.parseColor("#E65100")
        "قيد التجهيز" -> Color.parseColor("#1565C0")
        "بالطريق" -> Color.parseColor("#6A1B9A")
        else -> green
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}
