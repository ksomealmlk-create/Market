import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'cart.dart';
import 'category.dart';
import 'models.dart';
import 'owner.dart';
import 'product_sheet.dart';
import 'store.dart';
import 'theme.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _ctl = TextEditingController();
  String _q = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _askLocationPermission());
  }

  // يطلب صلاحية الموقع أول ما يفتح الزبون التطبيق
  Future<void> _askLocationPermission() async {
    try {
      final p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) await Geolocator.requestPermission();
    } catch (_) {}
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  void _openCategory(Category c) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryScreen(category: c)));
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final q = _q.trim();
    final found = q.isEmpty
        ? <Product>[]
        : store.products.where((p) => p.name.toLowerCase().contains(q.toLowerCase())).toList();

    return Scaffold(
      body: Stack(
        children: [
          CustomScrollView(
            slivers: [
              _header(store),
              if (q.isEmpty) ..._browse(store) else ..._results(found),
              const SliverToBoxAdapter(child: SizedBox(height: 110)),
            ],
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: CartBar(onTap: () => openCart(context)),
          ),
        ],
      ),
    );
  }

  Widget _header(Store store) {
    return SliverAppBar(
      pinned: true,
      expandedHeight: 190,
      backgroundColor: kGreen,
      foregroundColor: Colors.white,
      title: const Text('متجري'),
      actions: [
        IconButton(
          tooltip: 'صاحب المتجر',
          icon: const Icon(Icons.storefront_outlined),
          onPressed: () => showOwnerLogin(context),
        ),
        IconButton(
          tooltip: 'السلة',
          icon: Badge(
            isLabelVisible: store.cartCount > 0,
            label: Text('${store.cartCount}'),
            child: const Icon(Icons.shopping_bag_outlined),
          ),
          onPressed: () => openCart(context),
        ),
        const SizedBox(width: 4),
      ],
      flexibleSpace: FlexibleSpaceBar(
        collapseMode: CollapseMode.parallax,
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [kMint, kGreen],
            ),
          ),
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 78),
          alignment: AlignmentDirectional.bottomStart,
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('أهلاً بيك 👋', style: TextStyle(color: Colors.white70, fontSize: 14)),
              SizedBox(height: 2),
              Text(
                'شنو تحب تطلب اليوم؟',
                style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(68),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: TextField(
            controller: _ctl,
            onChanged: (v) => setState(() => _q = v),
            decoration: InputDecoration(
              hintText: 'ابحث عن منتج',
              fillColor: Colors.white,
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: _q.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () {
                        _ctl.clear();
                        setState(() => _q = '');
                      },
                    ),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _browse(Store store) {
    final out = <Widget>[
      const SliverToBoxAdapter(
        child: Padding(
          padding: EdgeInsets.fromLTRB(16, 18, 16, 10),
          child: Text('الأقسام', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ),
      ),
      SliverToBoxAdapter(
        child: SizedBox(
          height: 112,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: kCategories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) => _CategoryTile(category: kCategories[i], onTap: () => _openCategory(kCategories[i])),
          ),
        ),
      ),
    ];

    var idx = 0;
    for (final c in kCategories) {
      final items = store.products.where((p) => p.category == c.name).toList();
      if (items.isEmpty) continue;
      out.add(SliverToBoxAdapter(
        child: FadeSlideIn(
          index: idx++,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InkWell(
                onTap: () => _openCategory(c),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text('${c.icon} ${c.name}',
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      ),
                      const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: kGreen),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 206,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (ctx, i) => ProductCard(
                    product: items[i],
                    width: 144,
                    onTap: () => showProductSheet(ctx, items[i]),
                  ),
                ),
              ),
            ],
          ),
        ),
      ));
    }
    return out;
  }

  List<Widget> _results(List<Product> found) {
    if (found.isEmpty) {
      return const [
        SliverFillRemaining(
          hasScrollBody: false,
          child: EmptyState(emoji: '😕', text: 'ما لقينا منتج بهذا الاسم'),
        ),
      ];
    }
    return [
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
        sliver: SliverList(
          delegate: SliverChildBuilderDelegate(
            (ctx, i) => FadeSlideIn(
              index: i,
              child: ProductRow(product: found[i], onTap: () => showProductSheet(ctx, found[i])),
            ),
            childCount: found.length,
          ),
        ),
      ),
    ];
  }
}

class _CategoryTile extends StatelessWidget {
  const _CategoryTile({required this.category, required this.onTap});
  final Category category;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: SizedBox(
        width: 78,
        child: Column(
          children: [
            Container(
              width: 68,
              height: 68,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: categoryTint(category.name),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Text(category.icon, style: const TextStyle(fontSize: 32)),
            ),
            const SizedBox(height: 6),
            Text(
              category.name,
              maxLines: 2,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, height: 1.2),
            ),
          ],
        ),
      ),
    );
  }
}
