import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'models.dart';
import 'store.dart';
import 'theme.dart';
import 'widgets.dart';

// =====================================================
//  دخول صاحب المتجر (bottom sheet)
// =====================================================

void showOwnerLogin(BuildContext context) {
  final ctl = TextEditingController();
  String? error;
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Container(
          decoration: const BoxDecoration(color: kBg, borderRadius: kSheetRadius),
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SheetHandle(),
                const Text('🔐', style: TextStyle(fontSize: 40)),
                const SizedBox(height: 6),
                const Text('دخول صاحب المتجر', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 14),
                TextField(
                  controller: ctl,
                  autofocus: true,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(hintText: 'الرمز السري', errorText: error),
                ),
                const SizedBox(height: 6),
                const Text('الرمز الافتراضي: 1234 (غيّره بعد الدخول)',
                    style: TextStyle(fontSize: 13, color: kGray)),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () {
                      if (ctl.text == ctx.read<Store>().pin) {
                        Navigator.pop(ctx);
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const OwnerScreen()));
                      } else {
                        setS(() => error = 'الرمز غير صحيح');
                      }
                    },
                    child: const Text('دخول'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  ).whenComplete(ctl.dispose);
}

// =====================================================
//  لوحة صاحب المتجر
// =====================================================

class OwnerScreen extends StatelessWidget {
  const OwnerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('لوحة صاحب المتجر'),
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            tabs: [Tab(text: 'الطلبات'), Tab(text: 'المنتجات'), Tab(text: '🔑 الرمز')],
          ),
        ),
        body: const TabBarView(children: [_OrdersTab(), _ProductsTab(), _PinTab()]),
      ),
    );
  }
}

// ---------- الطلبات ----------

class _OrdersTab extends StatelessWidget {
  const _OrdersTab();

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final list = store.orders.reversed.toList();
    if (list.isEmpty) return const EmptyState(emoji: '📭', text: 'لا توجد طلبات بعد');
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: list.length,
      itemBuilder: (_, i) => FadeSlideIn(index: i, child: _OrderCard(order: list[i])),
    );
  }
}

class _OrderCard extends StatelessWidget {
  const _OrderCard({required this.order});
  final Order order;

  Future<void> _delete(BuildContext context) async {
    final store = context.read<Store>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('حذف الطلب #${order.no}؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف', style: TextStyle(color: kRed)),
          ),
        ],
      ),
    );
    if (ok == true) store.deleteOrder(order);
  }

  @override
  Widget build(BuildContext context) {
    final store = context.read<Store>();
    final o = order;
    final idx = Store.statuses.indexOf(o.status);
    final color = statusColor(o.status);
    final next = (idx >= 0 && idx < Store.statuses.length - 1) ? Store.statuses[idx + 1] : null;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text('طلب #${o.no}  •  ${formatTime(o.time)}',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(o.status, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: (idx + 1) / Store.statuses.length,
              minHeight: 6,
              color: color,
              backgroundColor: const Color(0xFFEAEAEA),
            ),
          ),
          const SizedBox(height: 12),
          Text('👤 ${o.name}', style: const TextStyle(fontSize: 15)),
          Row(
            children: [
              Expanded(child: Text('📞 ${o.phone}', style: const TextStyle(fontSize: 15))),
              IconButton(
                visualDensity: VisualDensity.compact,
                tooltip: 'نسخ الرقم',
                icon: const Icon(Icons.copy_rounded, size: 18, color: kGray),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: o.phone));
                  ScaffoldMessenger.of(context)
                    ..hideCurrentSnackBar()
                    ..showSnackBar(const SnackBar(content: Text('تم نسخ الرقم')));
                },
              ),
            ],
          ),
          Text('📍 ${o.address}', style: const TextStyle(fontSize: 15, height: 1.4)),
          if (o.lat != null && o.lng != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size(64, 44)),
                icon: const Icon(Icons.map_outlined),
                label: const Text('فتح موقع الزبون بالخريطة'),
                onPressed: () async {
                  final uri = Uri.parse(
                      'https://www.google.com/maps/search/?api=1&query=${o.lat},${o.lng}');
                  final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
                  if (!ok && context.mounted) {
                    ScaffoldMessenger.of(context)
                        .showSnackBar(const SnackBar(content: Text('تعذر فتح الخريطة')));
                  }
                },
              ),
            ),
          const Divider(height: 24),
          for (final l in o.lines)
            Padding(padding: const EdgeInsets.only(bottom: 2), child: Text('• $l', style: const TextStyle(fontSize: 15))),
          const SizedBox(height: 8),
          Text('المجموع: ${money(o.total)}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Row(
            children: [
              if (next != null)
                Expanded(
                  child: FilledButton(
                    style: FilledButton.styleFrom(minimumSize: const Size(64, 44)),
                    onPressed: () => store.setOrderStatus(o, next),
                    child: Text('تحويل إلى: $next'),
                  ),
                )
              else
                const Expanded(child: SizedBox()),
              const SizedBox(width: 8),
              IconButton.filled(
                style: IconButton.styleFrom(backgroundColor: kRed, foregroundColor: Colors.white),
                tooltip: 'حذف الطلب',
                icon: const Icon(Icons.delete_outline_rounded),
                onPressed: () => _delete(context),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ---------- المنتجات ----------

class _ProductsTab extends StatelessWidget {
  const _ProductsTab();

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => showProductEditor(context),
                icon: const Icon(Icons.add_rounded),
                label: const Text('إضافة منتج'),
              ),
            ),
          ),
        ),
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Text('اختر القسم', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.82,
            ),
            delegate: SliverChildBuilderDelegate(
              (ctx, i) {
                final c = kCategories[i];
                final n = store.products.where((p) => p.category == c.name).length;
                return InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => Navigator.push(
                    ctx,
                    MaterialPageRoute(builder: (_) => OwnerCategoryScreen(category: c)),
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(color: categoryTint(c.name), borderRadius: BorderRadius.circular(18)),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(c.icon, style: const TextStyle(fontSize: 32)),
                        const SizedBox(height: 6),
                        Text(c.name,
                            maxLines: 2,
                            textAlign: TextAlign.center,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                        Text('$n منتج', style: const TextStyle(fontSize: 11, color: kGray)),
                      ],
                    ),
                  ),
                );
              },
              childCount: kCategories.length,
            ),
          ),
        ),
      ],
    );
  }
}

class OwnerCategoryScreen extends StatelessWidget {
  const OwnerCategoryScreen({super.key, required this.category});
  final Category category;

  Future<void> _delete(BuildContext context, Product p) async {
    final store = context.read<Store>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('حذف ${p.name}؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف', style: TextStyle(color: kRed)),
          ),
        ],
      ),
    );
    if (ok == true) store.deleteProduct(p);
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final items = store.products.where((p) => p.category == category.name).toList();
    return Scaffold(
      appBar: AppBar(title: Text('${category.icon}  ${category.name}')),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: kGreen,
        foregroundColor: Colors.white,
        onPressed: () => showProductEditor(context, defaultCat: category.name),
        icon: const Icon(Icons.add_rounded),
        label: const Text('إضافة منتج'),
      ),
      body: items.isEmpty
          ? const EmptyState(emoji: '🫙', text: 'لا توجد منتجات بهذا القسم بعد')
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
              itemCount: items.length,
              itemBuilder: (ctx, i) {
                final p = items[i];
                return FadeSlideIn(
                  index: i,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
                    child: Row(
                      children: [
                        ProductThumb(product: p, width: 52, height: 52, fontSize: 24, radius: 14),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                              Text(money(p.price), style: const TextStyle(fontSize: 14, color: kGray)),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.edit_outlined, color: kGreen),
                          onPressed: () => showProductEditor(ctx, product: p),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline_rounded, color: kRed),
                          onPressed: () => _delete(ctx, p),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

/// إضافة / تعديل منتج (bottom sheet)
void showProductEditor(BuildContext context, {Product? product, String? defaultCat}) {
  final name = TextEditingController(text: product?.name ?? '');
  final price = TextEditingController(text: product?.price.toString() ?? '');
  var chosen = product?.category ?? defaultCat ?? kCategories.first.name;
  String? error;

  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Container(
          decoration: const BoxDecoration(color: kBg, borderRadius: kSheetRadius),
          child: SafeArea(
            top: false,
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Center(child: SheetHandle()),
                  Text(product == null ? 'إضافة منتج' : 'تعديل المنتج',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 14),
                  TextField(controller: name, decoration: const InputDecoration(hintText: 'اسم المنتج')),
                  const SizedBox(height: 10),
                  TextField(
                    controller: price,
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    decoration: const InputDecoration(hintText: 'السعر (دينار)'),
                  ),
                  const SizedBox(height: 14),
                  const Text('القسم', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      for (final c in kCategories)
                        ChoiceChip(
                          label: Text('${c.icon} ${c.name}'),
                          selected: chosen == c.name,
                          showCheckmark: false,
                          selectedColor: const Color(0xFFD7EFD9),
                          onSelected: (_) => setS(() => chosen = c.name),
                        ),
                    ],
                  ),
                  if (error != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Text(error!, style: const TextStyle(color: kRed)),
                    ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () {
                        final n = name.text.trim();
                        final pr = int.tryParse(price.text.trim());
                        if (n.isEmpty || pr == null) {
                          setS(() => error = 'البيانات ناقصة');
                          return;
                        }
                        context.read<Store>().saveProduct(product, n, pr, chosen);
                        Navigator.pop(ctx);
                      },
                      child: const Text('حفظ'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    ),
  ).whenComplete(() {
    name.dispose();
    price.dispose();
  });
}

// ---------- تغيير الرمز ----------

class _PinTab extends StatefulWidget {
  const _PinTab();

  @override
  State<_PinTab> createState() => _PinTabState();
}

class _PinTabState extends State<_PinTab> {
  final _pin = TextEditingController();

  @override
  void dispose() {
    _pin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('تغيير الرمز السري', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              TextField(
                controller: _pin,
                obscureText: true,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(hintText: 'الرمز الجديد (4 أرقام أو أكثر)'),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () {
                    final m = ScaffoldMessenger.of(context)..hideCurrentSnackBar();
                    if (_pin.text.length < 4) {
                      m.showSnackBar(const SnackBar(content: Text('الرمز قصير')));
                    } else {
                      context.read<Store>().pin = _pin.text;
                      _pin.clear();
                      m.showSnackBar(const SnackBar(content: Text('تم تغيير الرمز ✅')));
                    }
                  },
                  child: const Text('حفظ'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
