package com.grocery.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var store: Store
    private var screen = "home"
    private var cartLabel: TextView? = null

    private val green = Color.parseColor("#2E7D32")
    private val red = Color.parseColor("#C62828")
    private val gray = Color.parseColor("#757575")
    private val dark = Color.parseColor("#212121")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        window.statusBarColor = green
        home()
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (screen == "home") super.onBackPressed() else home()
    }

    // =====================================================
    //  شاشات الزبون
    // =====================================================

    private fun home() {
        screen = "home"
        val col = column()

        val search = input("ابحث عن منتج")
        col.addView(search)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        col.addView(box)

        fun render(q: String) {
            box.removeAllViews()
            if (q.isBlank()) {
                box.addView(text("الأقسام", 20f, true))
                box.addView(space(10))
                box.addView(categoryGrid())
                box.addView(space(8))
                box.addView(categoryStrips())
            } else {
                val found = store.products.filter { it.name.contains(q.trim(), ignoreCase = true) }
                if (found.isEmpty()) box.addView(text("ما لقينا منتج بهذا الاسم", 16f, false, gray))
                for (p in found) box.addView(productRow(p))
            }
        }
        render("")

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                render(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        val owner = text("⚙️", 20f, false, Color.WHITE)
        owner.setPadding(dp(10), dp(4), dp(10), dp(4))
        owner.setOnClickListener { ownerLogin() }

        page("متجري", null, listOf(cartAction(), owner), scroll(col))
    }

    // أقسام بشريط منتجات أفقي (اسم القسم + سهم + منتجاته)
    private fun categoryStrips(): LinearLayout {
        val all = LinearLayout(this)
        all.orientation = LinearLayout.VERTICAL
        for (c in CATEGORIES) {
            val items = store.products.filter { it.category == c.name }
            if (items.isEmpty()) continue

            val header = LinearLayout(this)
            header.orientation = LinearLayout.HORIZONTAL
            header.gravity = Gravity.CENTER_VERTICAL
            header.setPadding(dp(4), dp(14), dp(4), dp(6))
            header.addView(text(c.icon + " " + c.name, 18f, true), LinearLayout.LayoutParams(0, WRAP, 1f))
            val arrow = text("←", 18f, true, green)
            arrow.setPadding(dp(12), dp(2), dp(12), dp(2))
            header.addView(arrow)
            header.setOnClickListener { categoryScreen(c.name) }
            all.addView(header)

            val hs = HorizontalScrollView(this)
            hs.isHorizontalScrollBarEnabled = false
            val strip = LinearLayout(this)
            strip.orientation = LinearLayout.HORIZONTAL
            for (p in items) strip.addView(stripCard(p))
            hs.addView(strip)
            all.addView(hs, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        return all
    }

    private fun stripCard(p: Product): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(10), dp(10), dp(10), dp(10))
        card.background = round(Color.WHITE, 14)
        val lp = LinearLayout.LayoutParams(dp(130), WRAP)
        lp.setMargins(dp(4), dp(2), dp(4), dp(6))
        card.layoutParams = lp

        val name = text(p.name, 14f, true)
        name.minLines = 2
        name.maxLines = 2
        card.addView(name)
        card.addView(text(money(p.price), 13f, false, gray))

        val add = smallButton("+ أضف", green) {
            store.addToCart(p)
            updateCartLabel()
            toast("أضيفت: ${p.name}")
        }
        card.addView(full(add, 8))
        return card
    }

    private fun categoryScreen(name: String) {
        screen = "category"
        val col = column()
        val items = store.products.filter { it.category == name }
        if (items.isEmpty()) col.addView(text("لا توجد منتجات بهذا القسم بعد", 17f, false, gray))
        for (p in items) col.addView(productRow(p))
        page(name, { home() }, listOf(cartAction()), scroll(col))
    }

    private fun categoryGrid(onClick: (Category) -> Unit = { categoryScreen(it.name) }, showCount: Boolean = false): LinearLayout {
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        for (chunk in CATEGORIES.chunked(3)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (i in 0 until 3) {
                if (i < chunk.size) {
                    row.addView(categoryTile(chunk[i], onClick, showCount), LinearLayout.LayoutParams(0, WRAP, 1f))
                } else {
                    row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                }
            }
            grid.addView(row)
        }
        return grid
    }

    private fun categoryTile(c: Category, onClick: (Category) -> Unit, showCount: Boolean): View {
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.setPadding(dp(4), dp(6), dp(4), dp(10))

        val iconBox = TextView(this)
        iconBox.text = c.icon
        iconBox.textSize = 38f
        iconBox.gravity = Gravity.CENTER
        iconBox.background = round(Color.parseColor("#E9E9EE"), 18)
        tile.addView(iconBox, LinearLayout.LayoutParams(MATCH, dp(92)))

        val name = text(c.name, 13f, true)
        name.textAlignment = View.TEXT_ALIGNMENT_CENTER
        name.minLines = 2
        name.maxLines = 2
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(6)
        tile.addView(name, lp)

        if (showCount) {
            val n = store.products.count { it.category == c.name }
            val cnt = text("$n منتج", 12f, false, gray)
            cnt.textAlignment = View.TEXT_ALIGNMENT_CENTER
            tile.addView(cnt)
        }

        tile.setOnClickListener { onClick(c) }
        return tile
    }

    private fun productRow(p: Product): View {
        val card = card()
        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.addView(text(p.name, 17f, true))
        info.addView(text(money(p.price), 14f, false, gray))
        line.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))

        line.addView(smallButton("+ أضف", green) {
            store.addToCart(p)
            updateCartLabel()
            toast("أضيفت: ${p.name}")
        })
        card.addView(line)
        return card
    }

    private fun cartAction(): TextView {
        val cart = text("🛒 ${store.cartCount()}", 18f, true, Color.WHITE)
        cart.setPadding(dp(10), dp(4), dp(10), dp(4))
        cart.setOnClickListener { cartScreen() }
        cartLabel = cart
        return cart
    }

    private fun updateCartLabel() {
        cartLabel?.text = "🛒 ${store.cartCount()}"
    }

    private fun cartScreen() {
        screen = "cart"
        val col = column()

        if (store.cart.isEmpty()) {
            col.addView(text("السلة فارغة", 18f, false, gray))
        } else {
            for (l in store.cart.toList()) {
                val card = card()
                card.addView(text(l.product.name, 17f, true))
                card.addView(text(money(l.product.price * l.qty), 14f, false, gray))

                val ctr = LinearLayout(this)
                ctr.orientation = LinearLayout.HORIZONTAL
                ctr.gravity = Gravity.CENTER_VERTICAL
                ctr.addView(smallButton("−", green) {
                    store.changeQty(l, -1)
                    cartScreen()
                })
                val q = text("${l.qty}", 18f, true)
                q.setPadding(dp(16), 0, dp(16), 0)
                ctr.addView(q)
                ctr.addView(smallButton("+", green) {
                    store.changeQty(l, 1)
                    cartScreen()
                })
                card.addView(full(ctr, 8))
                col.addView(card)
            }

            val totalCard = card()
            totalCard.addView(text("المجموع: ${money(store.cartTotal())}", 20f, true, green))
            col.addView(totalCard)
            col.addView(button("متابعة الطلب", green) { checkoutScreen() })
        }

        page("السلة", { home() }, emptyList(), scroll(col))
    }

    private fun checkoutScreen() {
        screen = "checkout"
        val col = column()

        col.addView(text("معلومات التوصيل", 18f, true))
        col.addView(space(8))
        val name = input("الاسم")
        val phone = input("رقم الهاتف", InputType.TYPE_CLASS_PHONE)
        val address = input("العنوان (المنطقة، الشارع، أقرب نقطة دالة)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
        col.addView(name)
        col.addView(phone)
        col.addView(address)

        col.addView(text("المجموع: ${money(store.cartTotal())}", 18f, true, green))
        col.addView(text("الدفع عند الاستلام", 15f, false, gray))
        col.addView(space(12))

        col.addView(button("إرسال الطلب", green) {
            val n = name.text.toString().trim()
            val ph = phone.text.toString().trim()
            val ad = address.text.toString().trim()
            if (n.isEmpty() || ph.isEmpty() || ad.isEmpty()) {
                toast("عبّي كل الحقول")
                return@button
            }
            if (store.cart.isEmpty()) {
                toast("السلة فارغة")
                return@button
            }
            store.placeOrder(n, ph, ad)
            toast("تم إرسال الطلب ✅")
            home()
        })

        page("إتمام الطلب", { cartScreen() }, emptyList(), scroll(col))
    }

    // =====================================================
    //  شاشات صاحب المتجر
    // =====================================================

    private fun ownerLogin() {
        screen = "ownerLogin"
        val col = column()
        col.addView(text("دخول صاحب المتجر", 18f, true))
        col.addView(space(8))
        val pin = input("الرمز السري", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        col.addView(pin)
        col.addView(text("الرمز الافتراضي: 1234 (غيّره بعد الدخول)", 13f, false, gray))
        col.addView(space(8))
        col.addView(button("دخول", green) {
            if (pin.text.toString() == store.pin) ownerOrders() else toast("الرمز غير صحيح")
        })
        page("صاحب المتجر", { home() }, emptyList(), scroll(col))
    }

    private fun ownerTabs(col: LinearLayout, active: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL

        val items = listOf("orders" to "الطلبات", "products" to "المنتجات", "pin" to "🔑 الرمز")
        for ((key, label) in items) {
            val selected = key == active
            val chip = text(label, 15f, true, if (selected) Color.WHITE else green)
            chip.background = round(if (selected) green else Color.WHITE, 20)
            chip.setPadding(dp(16), dp(8), dp(16), dp(8))
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.marginEnd = dp(8)
            chip.layoutParams = lp
            chip.setOnClickListener {
                when (key) {
                    "orders" -> ownerOrders()
                    "products" -> ownerProducts()
                    else -> changePinDialog()
                }
            }
            row.addView(chip)
        }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(12)
        col.addView(row, lp)
    }

    private fun ownerOrders() {
        screen = "owner"
        val col = column()
        ownerTabs(col, "orders")

        if (store.orders.isEmpty()) col.addView(text("لا توجد طلبات بعد", 17f, false, gray))

        for (o in store.orders.reversed()) {
            val c = card()
            c.addView(text("طلب #${o.no}  •  ${formatTime(o.time)}", 16f, true))
            c.addView(text("👤 ${o.name}", 15f))
            c.addView(text("📞 ${o.phone}", 15f))
            c.addView(text("📍 ${o.address}", 15f))
            c.addView(space(6))
            for (ln in o.lines) c.addView(text("• $ln", 15f))
            c.addView(space(6))
            c.addView(text("المجموع: ${money(o.total)}", 16f, true))
            c.addView(text("الحالة: ${o.status}", 16f, true, statusColor(o.status)))

            val idx = store.statuses.indexOf(o.status)
            if (idx >= 0 && idx < store.statuses.size - 1) {
                val next = store.statuses[idx + 1]
                c.addView(full(button("تحويل إلى: $next", green) {
                    o.status = next
                    store.saveOrders()
                    ownerOrders()
                }, 8))
            }
            c.addView(full(button("حذف الطلب", red) {
                AlertDialog.Builder(this)
                    .setMessage("حذف الطلب #${o.no}؟")
                    .setPositiveButton("حذف") { _, _ ->
                        store.orders.remove(o)
                        store.saveOrders()
                        ownerOrders()
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            }, 6))
            col.addView(c)
        }

        page("لوحة صاحب المتجر", { home() }, emptyList(), scroll(col))
    }

    private fun ownerProducts() {
        screen = "owner"
        val col = column()
        ownerTabs(col, "products")

        col.addView(button("+ إضافة منتج", green) { productDialog(null, null) { ownerProducts() } })
        col.addView(space(10))
        col.addView(text("اختر القسم", 18f, true))
        col.addView(space(8))
        col.addView(categoryGrid({ c -> ownerCategory(c.name) }, true))

        page("لوحة صاحب المتجر", { home() }, emptyList(), scroll(col))
    }

    private fun ownerCategory(cat: String) {
        screen = "owner"
        val col = column()
        val refresh = { ownerCategory(cat) }

        col.addView(button("+ إضافة منتج إلى $cat", green) { productDialog(null, cat, refresh) })
        col.addView(space(10))

        val items = store.products.filter { it.category == cat }
        if (items.isEmpty()) col.addView(text("لا توجد منتجات بهذا القسم بعد", 17f, false, gray))

        for (p in items) {
            val c = card()
            c.addView(text(p.name, 17f, true))
            c.addView(text(money(p.price), 14f, false, gray))

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(smallButton("تعديل", green) { productDialog(p, null, refresh) })
            row.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
            row.addView(smallButton("حذف", red) {
                AlertDialog.Builder(this)
                    .setMessage("حذف ${p.name}؟")
                    .setPositiveButton("حذف") { _, _ ->
                        store.deleteProduct(p)
                        refresh()
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            })
            c.addView(full(row, 8))
            col.addView(c)
        }

        page(cat, { ownerProducts() }, emptyList(), scroll(col))
    }

    private fun productDialog(p: Product?, defaultCat: String?, after: () -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(10), dp(20), 0)

        val name = input("اسم المنتج")
        val price = input("السعر (دينار)", InputType.TYPE_CLASS_NUMBER)
        var chosen = p?.category ?: defaultCat ?: CATEGORIES[0].name
        if (p != null) {
            name.setText(p.name)
            price.setText(p.price.toString())
        }
        val catBtn = button("القسم: $chosen", Color.parseColor("#455A64")) {}
        catBtn.setOnClickListener {
            val names = CATEGORIES.map { it.name }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("اختر القسم")
                .setItems(names) { _, i ->
                    chosen = names[i]
                    catBtn.text = "القسم: $chosen"
                }
                .show()
        }
        box.addView(name)
        box.addView(price)
        box.addView(catBtn)

        AlertDialog.Builder(this)
            .setTitle(if (p == null) "إضافة منتج" else "تعديل المنتج")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim()
                val pr = price.text.toString().trim().toIntOrNull()
                if (n.isEmpty() || pr == null) {
                    toast("البيانات ناقصة")
                } else {
                    store.saveProduct(p, n, pr, chosen)
                    after()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun changePinDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        val pin = input("الرمز الجديد (4 أرقام أو أكثر)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        box.addView(pin)

        AlertDialog.Builder(this)
            .setTitle("تغيير الرمز السري")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val v = pin.text.toString()
                if (v.length < 4) {
                    toast("الرمز قصير")
                } else {
                    store.pin = v
                    toast("تم تغيير الرمز")
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // =====================================================
    //  أدوات مساعدة للواجهة
    // =====================================================

    private fun page(title: String, back: (() -> Unit)?, actions: List<View>, content: View) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(Color.parseColor("#F5F5F5"))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(green)
        bar.setPadding(dp(12), dp(12), dp(12), dp(12))

        if (back != null) {
            val b = text("→", 24f, true, Color.WHITE)
            b.setPadding(dp(8), 0, dp(16), 0)
            b.setOnClickListener { back() }
            bar.addView(b)
        }
        bar.addView(text(title, 20f, true, Color.WHITE), LinearLayout.LayoutParams(0, WRAP, 1f))
        for (a in actions) bar.addView(a)

        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun column(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(12), dp(12), dp(12), dp(24))
        return c
    }

    private fun scroll(content: View): ScrollView {
        val s = ScrollView(this)
        s.addView(content)
        return s
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        c.background = round(Color.WHITE, 14)
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(10)
        c.layoutParams = lp
        return c
    }

    private fun text(s: String, size: Float = 16f, bold: Boolean = false, color: Int = dark): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        t.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        return t
    }

    private fun button(s: String, bg: Int = green, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setTextColor(Color.WHITE)
        b.isAllCaps = false
        b.textSize = 16f
        b.background = round(bg, 12)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun smallButton(s: String, bg: Int = green, onClick: () -> Unit): Button {
        val b = button(s, bg, onClick)
        b.minWidth = 0
        b.minimumWidth = dp(56)
        b.minHeight = 0
        b.minimumHeight = dp(40)
        return b
    }

    private fun input(hint: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
        val e = EditText(this)
        e.hint = hint
        e.inputType = type
        e.setTextColor(dark)
        e.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        e.background = round(Color.parseColor("#EEEEEE"), 10)
        e.setPadding(dp(12), dp(12), dp(12), dp(12))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(10)
        e.layoutParams = lp
        return e
    }

    private fun space(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(MATCH, dp(h))
        return v
    }

    private fun <T : View> full(v: T, top: Int = 8): T {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(top)
        v.layoutParams = lp
        return v
    }

    private fun round(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun money(n: Int): String = String.format(Locale.US, "%,d", n) + " د.ع"

    private fun formatTime(t: Long): String =
        SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(t))

    private fun statusColor(status: String): Int = when (status) {
        "جديد" -> Color.parseColor("#E65100")
        "قيد التجهيز" -> Color.parseColor("#1565C0")
        "بالطريق" -> Color.parseColor("#6A1B9A")
        else -> green
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}
