import 'features.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'models.dart';
import 'store.dart';
import 'theme.dart';
import 'widgets.dart';

void openCart(BuildContext context) {
  Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen()));
}

// =====================================================
//  السلة
// =====================================================

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  Future<void> _confirmClear(BuildContext context) async {
    final store = context.read<Store>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تفريغ السلة؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('تفريغ', style: TextStyle(color: kRed)),
          ),
        ],
      ),
    );
    if (ok == true) store.clearCart();
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    final lines = store.cart.toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('سلتي'),
        actions: [
          if (lines.isNotEmpty)
            IconButton(
              tooltip: 'تفريغ السلة',
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: () => _confirmClear(context),
            ),
        ],
      ),
      body: lines.isEmpty
          ? Column(
              children: [
                const Expanded(child: EmptyState(emoji: '🛒', text: 'السلة فارغة')),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SafeArea(
                    top: false,
                    child: SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('تصفّح المنتجات'),
                      ),
                    ),
                  ),
                ),
              ],
            )
          : Column(
              children: [
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      for (var i = 0; i < lines.length; i++)
                        FadeSlideIn(index: i, child: _CartItem(line: lines[i])),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text('المجموع الجزئي',
                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                            ),
                            AnimatedSwitcher(
                              duration: const Duration(milliseconds: 200),
                              transitionBuilder: (c, a) => FadeTransition(opacity: a, child: c),
                              child: Text(
                                money(store.cartTotal),
                                key: ValueKey(store.cartTotal),
                                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Material(
                  color: Colors.white,
                  elevation: 10,
                  child: SafeArea(
                    top: false,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                      child: Row(
                        children: [
                          OutlinedButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('أضف المزيد'),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: FilledButton(
                              onPressed: () async {
                                final go = await showSuggestions(context);
                                if (!context.mounted || !go || store.cart.isEmpty) return;
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) => const CheckoutScreen()),
                                );
                              },
                              child: Text('إتمام الشراء   •   ${money(store.cartTotal)}'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class _CartItem extends StatelessWidget {
  const _CartItem({required this.line});
  final CartLine line;

  @override
  Widget build(BuildContext context) {
    final store = context.read<Store>();
    final p = line.product;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Dismissible(
        key: ValueKey('cart${p.id}'),
        direction: DismissDirection.horizontal,
        onDismissed: (_) => store.setQty(p, 0),
        background: Container(
          decoration: BoxDecoration(color: kRed, borderRadius: BorderRadius.circular(18)),
          alignment: Alignment.center,
          child: const Icon(Icons.delete_outline_rounded, color: Colors.white, size: 28),
        ),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
          child: Row(
            children: [
              ProductThumb(product: p, width: 60, height: 60, fontSize: 28, radius: 14),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(p.name, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    Text(
                      money(p.price * line.qty),
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: kGreen),
                    ),
                    if (line.note.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Text('📝 ${line.note}', style: const TextStyle(fontSize: 12, color: kGray)),
                      ),
                  ],
                ),
              ),
              QtyStepper(
                qty: line.qty,
                trash: true,
                onMinus: () => store.changeQty(line, -1),
                onPlus: () => store.changeQty(line, 1),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// =====================================================
//  نافذة "قد يعجبك أيضاً" (bottom sheet)
// =====================================================

/// ترجع true إذا ضغط الزبون "إتمام الشراء"
Future<bool> showSuggestions(BuildContext context) async {
  final store = context.read<Store>();
  final inCart = store.cart.map((l) => l.product.id).toSet();
  final cats = store.cart.map((l) => l.product.category).toSet();
  var sug = store.products.where((p) => !inCart.contains(p.id) && cats.contains(p.category)).toList()
    ..shuffle();
  if (sug.isEmpty) {
    sug = store.products.where((p) => !inCart.contains(p.id)).toList()..shuffle();
  }
  sug = sug.take(8).toList();
  if (sug.isEmpty) return true;

  final r = await showModalBottomSheet<bool>(
    context: context,
    backgroundColor: Colors.transparent,
    builder: (ctx) => Container(
      decoration: const BoxDecoration(color: kBg, borderRadius: kSheetRadius),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SheetHandle(),
            const Text('قد يعجبك أيضاً ✨', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            SizedBox(
              height: 206,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: sug.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (_, i) => ProductCard(product: sug[i], width: 144),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text('إتمام الشراء'),
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
  return r ?? false;
}

// =====================================================
//  إتمام الشراء
// =====================================================

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  static const _instructions = {
    'الرجاء الاتصال عند الوصول': '📞',
    'لا ترن الجرس': '🔕',
    'اتركه عند الباب': '🚪',
  };

  late final TextEditingController _name;
  late final TextEditingController _phone;
  late final TextEditingController _address;
  final _later = TextEditingController();
  final _picked = <String>{};
  bool _now = true;
  late bool _saveDefault;
  double? _lat;
  double? _lng;
  bool _locLoading = false;
  String? _locError;

  @override
  void initState() {
    super.initState();
    _autoLocate();
    final s = context.read<Store>();
    _name = TextEditingController(text: s.savedName);
    _phone = TextEditingController(text: s.savedPhone);
    _address = TextEditingController(text: s.savedAddress);
    _saveDefault = s.savedAddress.isNotEmpty;
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _address.dispose();
    _later.dispose();
    super.dispose();
  }

  // إذا الصلاحية معطاة من قبل، يحدد الموقع تلقائياً
  Future<void> _autoLocate() async {
    try {
      final perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.always || perm == LocationPermission.whileInUse) {
        await _locate();
      }
    } catch (_) {}
  }

  Future<void> _locate() async {
    setState(() {
      _locLoading = true;
      _locError = null;
    });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw 'شغّل الـ GPS من إعدادات التلفون';
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied) throw 'ما انعطت صلاحية الموقع';
      if (perm == LocationPermission.deniedForever) {
        throw 'الصلاحية مرفوضة، فعّلها من إعدادات التطبيق';
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 20),
        ),
      );
      if (!mounted) return;
      setState(() {
        _lat = pos.latitude;
        _lng = pos.longitude;
        _locLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _locLoading = false;
        _locError = e is String ? e : 'تعذر تحديد الموقع، حاول مرة ثانية';
      });
    }
  }

  void _submit() {
    final store = context.read<Store>();
    final messenger = ScaffoldMessenger.of(context);
    final n = _name.text.trim();
    final ph = _phone.text.trim();
    final ad = _address.text.trim();
    if (n.isEmpty || ph.isEmpty || ad.isEmpty) {
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('عبّي كل الحقول')));
      return;
    }
    if (store.cart.isEmpty) return;
    if (_saveDefault) {
      store.savedName = n;
      store.savedPhone = ph;
      store.savedAddress = ad;
    }
    var full = ad;
    full += _now ? '\nالوقت: الآن' : '\nالوقت: ${_later.text.trim().isEmpty ? 'لاحقاً' : _later.text.trim()}';
    if (_picked.isNotEmpty) full += '\nتعليمات: ${_picked.join('، ')}';

    HapticFeedback.heavyImpact();
    final nav = Navigator.of(context);
    final order = store.placeOrder(n, ph, full, lat: _lat, lng: _lng);
    nav.popUntil((r) => r.isFirst);
    showOrderSuccess(nav.context, order.no);
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<Store>();
    return Scaffold(
      appBar: AppBar(title: const Text('إتمام الشراء')),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _Section(
                  title: 'وقت التوصيل',
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: _TimeOption(
                              title: 'الآن',
                              sub: '10 - 20 د',
                              selected: _now,
                              onTap: () => setState(() => _now = true),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _TimeOption(
                              title: 'لوقت لاحق',
                              sub: 'اختر الوقت',
                              selected: !_now,
                              onTap: () => setState(() => _now = false),
                            ),
                          ),
                        ],
                      ),
                      AnimatedSize(
                        duration: const Duration(milliseconds: 250),
                        curve: Curves.easeOut,
                        alignment: Alignment.topCenter,
                        child: _now
                            ? const SizedBox(width: double.infinity)
                            : Padding(
                                padding: const EdgeInsets.only(top: 12),
                                child: TextField(
                                  controller: _later,
                                  decoration: const InputDecoration(
                                    hintText: 'متى تريد الاستلام؟ مثال: الساعة 6 مساءً',
                                    prefixIcon: Icon(Icons.schedule_rounded),
                                  ),
                                ),
                              ),
                      ),
                    ],
                  ),
                ),
                _Section(
                  title: 'عنوان التوصيل',
                  child: Column(
                    children: [
                      TextField(
                        controller: _name,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          hintText: 'الاسم',
                          prefixIcon: Icon(Icons.person_outline_rounded),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _phone,
                        keyboardType: TextInputType.phone,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          hintText: 'رقم الهاتف',
                          prefixIcon: Icon(Icons.phone_outlined),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _address,
                        minLines: 2,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          hintText: 'العنوان (المنطقة، الشارع، أقرب نقطة دالة)',
                          prefixIcon: Icon(Icons.location_on_outlined),
                        ),
                      ),
                    ],
                  ),
                ),
                _Section(
                  title: 'موقعك على الخريطة',
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 250),
                        child: _lat != null
                            ? Container(
                                key: const ValueKey('ok'),
                                width: double.infinity,
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFE3F2E4),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.check_circle_rounded, color: kGreen),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        'تم تحديد موقعك ✅\n${_lat!.toStringAsFixed(5)} , ${_lng!.toStringAsFixed(5)}',
                                        style: const TextStyle(height: 1.4),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : const SizedBox.shrink(key: ValueKey('none')),
                      ),
                      if (_locError != null)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Text(_locError!, style: const TextStyle(color: kRed)),
                        ),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: _locLoading ? null : _locate,
                          icon: _locLoading
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.my_location_rounded),
                          label: Text(_lat == null ? 'تحديد موقعي' : 'تحديث موقعي'),
                        ),
                      ),
                    ],
                  ),
                ),
                _Section(
                  title: 'تعليمات التوصيل',
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: [
                          for (final e in _instructions.entries)
                            FilterChip(
                              label: Text('${e.value}  ${e.key}'),
                              selected: _picked.contains(e.key),
                              showCheckmark: false,
                              selectedColor: const Color(0xFFD7EFD9),
                              side: BorderSide(
                                color: _picked.contains(e.key) ? kGreen : const Color(0xFFDDDDDD),
                              ),
                              onSelected: (v) => setState(() {
                                if (v) {
                                  _picked.add(e.key);
                                } else {
                                  _picked.remove(e.key);
                                }
                              }),
                            ),
                        ],
                      ),
                      CheckboxListTile(
                        value: _saveDefault,
                        onChanged: (v) => setState(() => _saveDefault = v ?? false),
                        contentPadding: EdgeInsets.zero,
                        controlAffinity: ListTileControlAffinity.leading,
                        activeColor: kGreen,
                        title: const Text('حفظ كعنوان افتراضي'),
                      ),
                    ],
                  ),
                ),
                const _Section(
                  title: 'طريقة الدفع',
                  child: Row(
                    children: [
                      Icon(Icons.payments_outlined, color: kGreen),
                      SizedBox(width: 10),
                      Text('الدفع نقداً عند الاستلام', style: TextStyle(fontSize: 15, color: kGray)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Material(
            color: Colors.white,
            elevation: 10,
            child: SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text('المبلغ الإجمالي', style: TextStyle(fontSize: 13, color: kGray)),
                          Text(
                            money(store.cartTotal),
                            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 170,
                      child: FilledButton(onPressed: _submit, child: const Text('إتمام الطلب')),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _TimeOption extends StatelessWidget {
  const _TimeOption({required this.title, required this.sub, required this.selected, required this.onTap});
  final String title;
  final String sub;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFE3F2E4) : const Color(0xFFF1F3F1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? kGreen : Colors.transparent, width: 2),
        ),
        child: Column(
          children: [
            Text(title,
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: selected ? kGreen : kDark)),
            const SizedBox(height: 2),
            Text(sub, style: const TextStyle(fontSize: 13, color: kGray)),
          ],
        ),
      ),
    );
  }
}

// =====================================================
//  نجاح الطلب
// =====================================================

void showOrderSuccess(BuildContext context, int orderNo) {
  showDialog<void>(
    context: context,
    builder: (ctx) => Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 28, 24, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: 1),
              duration: const Duration(milliseconds: 700),
              curve: Curves.elasticOut,
              builder: (_, v, child) => Transform.scale(scale: v, child: child),
              child: Container(
                width: 84,
                height: 84,
                decoration: const BoxDecoration(shape: BoxShape.circle, color: kMint),
                child: const Icon(Icons.check_rounded, color: Colors.white, size: 52),
              ),
            ),
            const SizedBox(height: 18),
            const Text('تم إرسال طلبك ✅', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('رقم الطلب #$orderNo', style: const TextStyle(fontSize: 15, color: kGray)),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  openMyOrders(context);
                },
                child: const Text('تتبع الطلب'),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(onPressed: () => Navigator.pop(ctx), child: const Text('تمام')),
            ),
          ],
        ),
      ),
    ),
  );
}
