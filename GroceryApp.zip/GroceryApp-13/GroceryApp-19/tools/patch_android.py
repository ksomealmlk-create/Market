"""يعدّل مشروع الأندرويد المولّد: الاسم، المعرّف، والتوقيع الثابت."""
import pathlib
import re
import shutil

app = pathlib.Path("android/app")
shutil.copy("tools/grocery.keystore", app / "grocery.keystore")

# اسم التطبيق
manifest = app / "src/main/AndroidManifest.xml"
m = manifest.read_text(encoding="utf-8")
m = re.sub(r'android:label="[^"]*"', 'android:label="ماركت حراير"', m, count=1)
perms = ('<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>\n'
         '    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>\n'
         '    <application')
if "ACCESS_FINE_LOCATION" not in m:
    m = m.replace("<application", perms, 1)
manifest.write_text(m, encoding="utf-8")


# صلاحيات الإنترنت والتتبع (خدمة الموقع تشتغل والشاشة مقفلة)
m = manifest.read_text(encoding="utf-8")
extra = ""
for n in ["INTERNET", "FOREGROUND_SERVICE", "FOREGROUND_SERVICE_LOCATION", "POST_NOTIFICATIONS", "WAKE_LOCK"]:
    if f'android.permission.{n}"' not in m:
        extra += f'<uses-permission android:name="android.permission.{n}"/>\n    '
if extra:
    m = m.replace("<application", extra + "<application", 1)
    manifest.write_text(m, encoding="utf-8")

kts = app / "build.gradle.kts"
groovy = app / "build.gradle"

if kts.exists():
    s = kts.read_text(encoding="utf-8")
    s = re.sub(r'applicationId\s*=\s*"[^"]*"', 'applicationId = "com.grocery.app"', s)
    s = re.sub(r'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 23', s)
    s = re.sub(r'minSdk\s*=\s*\d+', 'minSdk = 23', s)
    signing = '''    signingConfigs {
        create("fixed") {
            storeFile = file("grocery.keystore")
            storePassword = "grocery123"
            keyAlias = "grocery"
            keyPassword = "grocery123"
        }
    }

'''
    s = s.replace("    buildTypes {", signing + "    buildTypes {", 1)
    s = re.sub(r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)',
               'signingConfig = signingConfigs.getByName("fixed")', s)
    assert 'getByName("fixed")' in s, "لم يتم ضبط التوقيع"
    kts.write_text(s, encoding="utf-8")
elif groovy.exists():
    s = groovy.read_text(encoding="utf-8")
    s = re.sub(r'applicationId\s*=?\s*"[^"]*"', 'applicationId "com.grocery.app"', s)
    s = re.sub(r'minSdkVersion\s+flutter\.minSdkVersion', 'minSdkVersion 23', s)
    s = re.sub(r'minSdkVersion\s+\d+', 'minSdkVersion 23', s)
    signing = '''    signingConfigs {
        fixed {
            storeFile file("grocery.keystore")
            storePassword "grocery123"
            keyAlias "grocery"
            keyPassword "grocery123"
        }
    }

'''
    s = s.replace("    buildTypes {", signing + "    buildTypes {", 1)
    s = s.replace("signingConfig signingConfigs.debug", "signingConfig signingConfigs.fixed")
    assert "signingConfigs.fixed" in s, "لم يتم ضبط التوقيع"
    groovy.write_text(s, encoding="utf-8")
else:
    raise SystemExit("ما لقيت build.gradle")


# إيقاف تصغير الكود (R8) لأنه يسبب خطأ NoSuchMethodError في shared_preferences
if kts.exists():
    s = kts.read_text(encoding="utf-8")
    if "isMinifyEnabled" not in s:
        s = s.replace('signingConfig = signingConfigs.getByName("fixed")',
            'signingConfig = signingConfigs.getByName("fixed")\n            isMinifyEnabled = false\n            isShrinkResources = false', 1)
    kts.write_text(s, encoding="utf-8")
elif groovy.exists():
    s = groovy.read_text(encoding="utf-8")
    if "minifyEnabled" not in s:
        s = s.replace("signingConfig signingConfigs.fixed",
            "signingConfig signingConfigs.fixed\n            minifyEnabled false\n            shrinkResources false", 1)
    groovy.write_text(s, encoding="utf-8")


# أيقونة التطبيق (تحل محل أيقونة فلاتر الافتراضية)
icons = pathlib.Path("tools/icons/res")
if icons.exists():
    shutil.copytree(icons, app / "src/main/res", dirs_exist_ok=True)
    print("Icons copied")

print("Android configured OK")
